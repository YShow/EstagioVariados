-- MySQL dump 10.16  Distrib 10.2.25-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: gerenciamento_estoque
-- ------------------------------------------------------
-- Server version	10.2.25-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caixa`
--

DROP TABLE IF EXISTS `caixa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caixa` (
  `data_venda` datetime DEFAULT NULL,
  `cod_caixa` int(11) NOT NULL AUTO_INCREMENT,
  `valor_total_venda` decimal(12,2) DEFAULT NULL,
  `cod_funcionario` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_caixa`),
  KEY `cod_funcionario` (`cod_funcionario`),
  CONSTRAINT `caixa_ibfk_1` FOREIGN KEY (`cod_funcionario`) REFERENCES `funcionario` (`cod_funcionario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `status` tinyint(1) DEFAULT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `cod_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `cod_endereco` int(11) DEFAULT NULL,
  `cpf` char(11) NOT NULL,
  PRIMARY KEY (`cod_cliente`),
  KEY `cod_endereco` (`cod_endereco`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`cod_endereco`) REFERENCES `endereco` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `endereco` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `bairro` varchar(60) NOT NULL,
  `cep` varchar(14) DEFAULT NULL,
  `rua` varchar(60) DEFAULT NULL,
  `complemento` varchar(60) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `numero_rua` int(11) NOT NULL,
  `cidade` varchar(60) NOT NULL,
  `estado` varchar(60) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrada_mercadoria`
--

DROP TABLE IF EXISTS `entrada_mercadoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada_mercadoria` (
  `data_entrega` date NOT NULL,
  `quantidade_produto` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `codigo_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `cod_fornecedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo_entrada`),
  KEY `cod_fornecedor` (`cod_fornecedor`),
  CONSTRAINT `entrada_mercadoria_ibfk_1` FOREIGN KEY (`cod_fornecedor`) REFERENCES `fornecedor` (`cod_fornecedor`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fornecedor`
--

DROP TABLE IF EXISTS `fornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fornecedor` (
  `cod_fornecedor` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) DEFAULT NULL,
  `nome_cidade` varchar(60) DEFAULT NULL,
  `produto` varchar(60) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`cod_fornecedor`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionario` (
  `nome_usuario` varchar(60) NOT NULL,
  `acesso_adm` tinyint(1) DEFAULT NULL,
  `chave_acesso` varchar(60) DEFAULT NULL,
  `funcao` varchar(60) DEFAULT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `cod_funcionario` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`cod_funcionario`),
  UNIQUE KEY `nome_usuario` (`nome_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `itens_entrada`
--

DROP TABLE IF EXISTS `itens_entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itens_entrada` (
  `cod_entrada` int(11) DEFAULT NULL,
  `cod_produto` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  KEY `cod_entrada` (`cod_entrada`),
  KEY `cod_produto` (`cod_produto`),
  CONSTRAINT `itens_entrada_ibfk_1` FOREIGN KEY (`cod_entrada`) REFERENCES `entrada_mercadoria` (`codigo_entrada`),
  CONSTRAINT `itens_entrada_ibfk_2` FOREIGN KEY (`cod_produto`) REFERENCES `produto` (`cod_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `itens_venda`
--

DROP TABLE IF EXISTS `itens_venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itens_venda` (
  `cod_venda` int(11) DEFAULT NULL,
  `cod_produto` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  KEY `cod_venda` (`cod_venda`),
  KEY `cod_produto` (`cod_produto`),
  CONSTRAINT `itens_venda_ibfk_1` FOREIGN KEY (`cod_venda`) REFERENCES `venda` (`cod_venda`),
  CONSTRAINT `itens_venda_ibfk_2` FOREIGN KEY (`cod_produto`) REFERENCES `produto` (`cod_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produto` (
  `cod_produto` int(11) NOT NULL AUTO_INCREMENT,
  `quantidade_produto` int(11) DEFAULT NULL,
  `preco_custo` decimal(12,2) DEFAULT NULL,
  `preco_venda` decimal(12,2) DEFAULT NULL,
  `nome_produto` varchar(60) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `preco_casco` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`cod_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recebe`
--

DROP TABLE IF EXISTS `recebe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recebe` (
  `cod_funcionario` int(11) DEFAULT NULL,
  `cod_mercadoria` int(11) DEFAULT NULL,
  KEY `cod_funcionario` (`cod_funcionario`),
  KEY `cod_mercadoria` (`cod_mercadoria`),
  CONSTRAINT `recebe_ibfk_1` FOREIGN KEY (`cod_funcionario`) REFERENCES `funcionario` (`cod_funcionario`),
  CONSTRAINT `recebe_ibfk_2` FOREIGN KEY (`cod_mercadoria`) REFERENCES `entrada_mercadoria` (`codigo_entrada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `telefone`
--

DROP TABLE IF EXISTS `telefone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telefone` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `ddd` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `cod_cliente` int(11) DEFAULT NULL,
  `num_telefone` int(11) NOT NULL,
  `cod_fornecedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `cod_cliente` (`cod_cliente`),
  KEY `telefone_FK` (`cod_fornecedor`),
  CONSTRAINT `telefone_FK` FOREIGN KEY (`cod_fornecedor`) REFERENCES `fornecedor` (`cod_fornecedor`),
  CONSTRAINT `telefone_ibfk_1` FOREIGN KEY (`cod_cliente`) REFERENCES `cliente` (`cod_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=1048 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `venda`
--

DROP TABLE IF EXISTS `venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venda` (
  `status` tinyint(1) DEFAULT NULL,
  `cod_venda` int(11) NOT NULL AUTO_INCREMENT,
  `data_venda` varchar(60) DEFAULT NULL,
  `cod_cliente` int(11) DEFAULT NULL,
  `cod_funcionario` int(11) DEFAULT NULL,
  `cod_caixa` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_venda`),
  KEY `cod_cliente` (`cod_cliente`),
  KEY `cod_funcionario` (`cod_funcionario`),
  KEY `cod_caixa` (`cod_caixa`),
  CONSTRAINT `venda_ibfk_1` FOREIGN KEY (`cod_cliente`) REFERENCES `cliente` (`cod_cliente`),
  CONSTRAINT `venda_ibfk_2` FOREIGN KEY (`cod_funcionario`) REFERENCES `funcionario` (`cod_funcionario`),
  CONSTRAINT `venda_ibfk_3` FOREIGN KEY (`cod_caixa`) REFERENCES `caixa` (`cod_caixa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'gerenciamento_estoque'
--
/*!50003 DROP PROCEDURE IF EXISTS `spCadastraCliente` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spCadastraCliente`(bairro varchar(50),cep varchar(50),rua varchar(50),complemento varchar(50)
,cliNome varchar(50),cliCPF varchar(30)
)
BEGIN
	
	INSERT INTO gerenciamento_estoque.endereco
	(bairro, cep, rua, complemento, status) 
	    	VALUES(bairro, cep, rua, complemento, true);
	    
	set @idEndereco := LAST_INSERT_ID();

	INSERT INTO gerenciamento_estoque.cliente (status, nome, cod_endereco, cpf)
			VALUES(true, cliNome, @idEndereco, cliCPF);

	 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-03 17:26:08
