package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.AcessoBD;
import objeto.Funcionario;
import utilidade.EFuncoesFuncionario;

public class NegFuncionario {
    private final AcessoBD conexao = new AcessoBD();

    private static final String SQL_EXCLUIR = "UPDATE gerenciamento_estoque.funcionario\n"
	    + " SET status = false WHERE cod_funcionario= ?;";
    private static final String SQL_ALTERAR = "UPDATE gerenciamento_estoque.funcionario\n"
	    + "SET nome_usuario=?, acesso_adm=?,chave_acesso=COALESCE(?,chave_acesso), funcao=?, nome= ?\n"
	    + ", status=? WHERE cod_funcionario = ?;";
    private static final String SQL_INSERIR = "INSERT INTO gerenciamento_estoque.funcionario\n"
	    + "(nome_usuario, acesso_adm, chave_acesso, funcao, nome, status) \n" + "VALUES(?, ?, ?, ?, ?, ?);";
    private static final String SQL_SEARCH = "SELECT nome_usuario, acesso_adm, funcao, nome, cod_funcionario, status\n"
	    + "FROM gerenciamento_estoque.funcionario where nome like ? and status = true;";

    public boolean inserir(final Funcionario funcionario) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERIR);

	try (con; comando;) {
	    /*
	     * (nome_usuario, acesso_adm, chave_acesso, funcao, nome, status)
	     */
	    comando.setString(1, funcionario.getNomeUsuario());
	    comando.setBoolean(2, funcionario.isAcessoAdmin());
	    comando.setString(3, funcionario.getChaveAcesso());
	    comando.setString(4, funcionario.getFuncao().toString());
	    comando.setString(5, funcionario.getNome());
	    comando.setBoolean(6, funcionario.isStatus());

	    return comando.executeUpdate() >= 1;
	}

    }

    public List<Funcionario> consultar(final String nome) throws SQLException {

	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_SEARCH);

	try (con; comando;) {

	    comando.setString(1, nome + '%');

	    final var resultado = comando.executeQuery();
	    final var listaFun = new ArrayList<Funcionario>();
	    while (resultado.next()) {
		/* nome_usuario, acesso_adm, funcao, nome, cod_funcionario, status */
		final var funcionario = new Funcionario();
		funcionario.setNomeUsuario(resultado.getString("nome_usuario"));
		funcionario.setAcessoAdmin(resultado.getBoolean("acesso_adm"));
		funcionario.setFuncao(EFuncoesFuncionario.valueOf(resultado.getString("funcao").toUpperCase()));
		funcionario.setNome(resultado.getString("nome"));
		funcionario.setCodigoFuncionario(resultado.getInt("cod_funcionario"));
		funcionario.setStatus(resultado.getBoolean("status"));
		listaFun.add(funcionario);

	    }

	    return listaFun;
	}

    }

    public boolean alterar(final Funcionario funcionario) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_ALTERAR);

	try (con; comando;) {

	    /*
	     * nome_usuario=?, acesso_adm=?, chave_acesso=?, funcao=?, nome=NULL?\n" + ",
	     * status=?
	     */
	    comando.setString(1, funcionario.getNomeUsuario());
	    comando.setBoolean(2, funcionario.isAcessoAdmin());
	    if(funcionario.getChaveAcesso().isBlank())
	    {
		  comando.setString(3, null);
	    }else
	    {
	    comando.setString(3, funcionario.getChaveAcesso());
	    }
	    comando.setString(4, funcionario.getFuncao().toString());
	    comando.setString(5, funcionario.getNome());
	    comando.setBoolean(6, funcionario.isStatus());
	    comando.setInt(7, funcionario.getCodigoFuncionario());

	    return comando.executeUpdate() >= 1;
	}
    }

    public boolean desativar(final int id) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_EXCLUIR);

	try (con; comando;) {
	    comando.setInt(1, id);
	    return comando.executeUpdate() >= 1;
	}

    }
}
