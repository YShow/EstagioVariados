package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.AcessoBD;
import objeto.Caixa;
import objeto.Cliente;
import objeto.Funcionario;
import objeto.Produto;
import objeto.Venda;

public class NegVenda {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "";
    private static final String SQL_SEARCH = "SELECT ve.cod_caixa,cli.nome,fun.nome,pro.nome_produto,cai.valor_total_venda from venda ve\n"
	    + "JOIN cliente cli on cli.cod_cliente = ve.cod_cliente\n"
	    + "JOIN funcionario fun on fun.cod_funcionario = ve.cod_funcionario\n"
	    + "JOIN itens_venda iv on iv.cod_venda = ve.cod_venda\n"
	    + "JOIN produto pro on pro.cod_produto = iv.cod_produto\n"
	    + "JOIN caixa cai on cai.cod_caixa = ve.cod_caixa\n" + "WHERE cli.nome LIKE ?";
    private static final String SQL_UPDATE = "";
    private static final String SQL_DELETE = "";

    public boolean inserir(final Venda vendas) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT);
	try (con; comando;) {

	    return false;

	}
    }

    public List<Venda> consultar(final String metodo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, metodo);
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<Venda>();
	    while (result.next()) {
		final var venda = new Venda();
		var cliente = new Cliente();
		var funcionario = new Funcionario();
		var produto = new Produto();
		var caixa = new Caixa();
		/*SELECT ve.cod_caixa,cli.nome,fun.nome,pro.nome_produto,cai.valor_total_venda */
		caixa.setCodCaixa(result.getInt("ve.cod_caixa"));
		cliente.setNome(result.getString("cli.nome"));
		funcionario.setNome(result.getString("fun.nome"));
		produto.setNomeProduto(result.getString("pro.nome_produto"));
		caixa.setValorTotalVenda(result.getBigDecimal("cai.valor_total_venda"));
		
		venda.setCaixa(caixa);
		venda.setCliente(cliente);
		venda.setProduto(produto);
		venda.setFuncionario(funcionario);
		lista.add(venda);
	    }
	    return lista;
	}
    }

    public boolean alterar(final Venda vendas) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_UPDATE)) {
	    return false;
	}
    }

    public boolean excluir(final int id) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    return false;
	}
    }
}
