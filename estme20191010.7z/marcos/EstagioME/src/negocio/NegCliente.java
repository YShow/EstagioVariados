package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import acessoBD.AcessoBD;
import objeto.Cliente;
import objeto.Endereco;
import objeto.Telefone;
import utilidade.ETelefone;

public class NegCliente {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "INSERT INTO gerenciamento_estoque.cliente\n"
	    + "(status, nome, cod_endereco, cpf)\n" + "VALUES(?, ?, ?, ?);";
    private static final String SQL_INSERT_ENDERECO = "INSERT INTO gerenciamento_estoque.endereco\n"
	    + "(bairro, cep, rua, complemento, status, numero_rua,cidade,estado) " + "VALUES(?, ?, ?, ?, ?, ?,?,?);";
    private static final String SQL_INSERT_TELEFONE = "INSERT INTO gerenciamento_estoque.telefone\n"
	    + "(ddd, status, tipo, cod_cliente, num_telefone)\n" + "VALUES(?, ?, ?, ?, ?);";

    private static final String SQL_SEARCH = "SELECT cli.status, cli.nome, cli.cod_cliente, cli.cod_endereco, cli.cpf,\n"
	    + "endereco.bairro,endereco.rua,endereco.numero_rua,cli.status,endereco.cidade\n"
	    + "FROM gerenciamento_estoque.cliente cli\n"
	    + "JOIN gerenciamento_estoque.endereco endereco on endereco.numero = cli.cod_endereco\n"
	    + "LEFT join gerenciamento_estoque.telefone tel on tel.cod_cliente = cli.cod_cliente\n"
	    + "WHERE cli.nome like ? and cli.status = true" + " GROUP by cli.cod_cliente;";

    private static final String SQL_DELETE = "UPDATE gerenciamento_estoque.cliente\n"
	    + "SET status=false WHERE cod_cliente= ?;";

    private static final String SQL_PEGA_CLIENTE_ENDERECO = "SELECT  cli.cod_cliente,cli.cod_endereco,cli.cpf,cli.nome,cli.status,\n"
	    + "ende.bairro,ende.cep,ende.complemento,ende.numero_rua,ende.rua,ende.numero,ende.cidade,ende.estado\n"
	    + "from cliente cli\n" + "JOIN endereco ende on ende.numero = cli.cod_endereco"
	    + " WHERE cli.cod_cliente = ?";

    private static final String SQL_PEGA_CLIENTE_TELEFONE = "SELECT ddd,tipo,numero,num_telefone" + " from telefone\n"
	    + "where cod_cliente = ?";

    public boolean inserir(final Cliente cliente, final List<Telefone> telefone) throws SQLException {

	// FAZ A INSERÇÃO DE CLIENTE
	try (final var comando = conexao.getConexao();) {

	    // NAO COMITA TUDO AGORA
	    comando.setAutoCommit(false);

	    // FAZ O PREPARED STATEMENT E PEDE PARA RETORNAR A CHAVE PRIMARIA DE ENDERECO
	    final var pegaEndereco = comando.prepareStatement(SQL_INSERT_ENDERECO, Statement.RETURN_GENERATED_KEYS);
	    // PEGA O CODIGO DO ENDERECO
	    pegaEndereco.setString(1, cliente.getEndereco().getBairro());
	    pegaEndereco.setString(2, cliente.getEndereco().getCep());
	    pegaEndereco.setString(3, cliente.getEndereco().getRua());
	    pegaEndereco.setString(4, cliente.getEndereco().getComplemento());
	    pegaEndereco.setBoolean(5, true);
	    pegaEndereco.setInt(6, cliente.getEndereco().getNumeroRua());
	    pegaEndereco.setString(7, cliente.getEndereco().getCidade());
	    pegaEndereco.setString(8, cliente.getEndereco().getEstado());

	    // FAZ A INSERÇÃO DO ENDERECO
	    pegaEndereco.executeUpdate();

	    // PEGA A CHAVE PRIMARIA DO ENDEREÇO
	    final var retornaEndereco = pegaEndereco.getGeneratedKeys();
	    var idEndereco = 0;
	    if (retornaEndereco.next()) {
		idEndereco = retornaEndereco.getInt(1);
		// TERMINA A INSERCAO DO ENDERECO E RETORNA O ID
	    }

	    // INSERE CLIENTE E RETORNA O ID
	    final var pegaCliente = comando.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
	    pegaCliente.setBoolean(1, true);
	    pegaCliente.setString(2, cliente.getNome());
	    pegaCliente.setInt(3, idEndereco);
	    pegaCliente.setString(4, cliente.getCpf());

	    // FAZ A INSERÇÃO DE CLIENTE
	    pegaCliente.executeUpdate();
	    // PEGA A PRIMARY KEY DO CLIENTE
	    final var resultado = pegaCliente.getGeneratedKeys();
	    int idCliente = 0;
	    if (resultado.next()) {
		idCliente = resultado.getInt(1);
		// TERMINA A INSERCAO DE CLIENTE E PEGA O ID
	    }

	    // INSERE TELEFONE COM O ID DO CLIENTE
	    final var pegaTelefone = comando.prepareStatement(SQL_INSERT_TELEFONE);
	    for (final var tel : telefone) {

		// ISTO IRA ITERAR SOBRE TODOS OS TELEFONES E COLOCA TODOS EM UM BATCH PARA
		// EXECUTALOS DE UMA VEZ
		pegaTelefone.setInt(1, tel.getDdd());
		pegaTelefone.setBoolean(2, true);
		pegaTelefone.setString(3, tel.getTipo().toString());
		pegaTelefone.setInt(4, idCliente);
		pegaTelefone.setInt(5, tel.getNumTelefone());
		pegaTelefone.addBatch();
	    }

	    // FAZ A INSERÇÃO DE TODOS OS TELEFONES
	    final var quantidadeTelefone = pegaTelefone.executeBatch();

	    // REALIZA TODAS AS INSERÇÕES NO BANCO AGORA
	    comando.commit();

	    return quantidadeTelefone.length >= 1;

	}
    }

    public List<Cliente> consultar(final String nome) throws SQLException {// FAZ A CONSULTA DO CLIENTE
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {

	    // SETA O NOME PELO QUAL VAI PESQUISAR O CLIENTE
	    comando.setString(1, '%' + nome + '%');
	    // EXECUTA A QUERY NO BANCO
	    final var result = comando.executeQuery();

	    // CRIA A LISTA DE CLIENTES
	    final var lista = new ArrayList<Cliente>();
	    // CRIA A LISTA DE TELEFONE

	    while (result.next()) {
		// PARA CADA RESULTADO CRIAR UM OBJETO DE CLIENTE, ENDERECO E TELEFONE
		final var cliente = new Cliente();
		final var endereco = new Endereco();

		// PEGA RESULTADO DE CLIENTE E COLOCA EM CLIENTE
		cliente.setCodCliente(result.getInt("cli.cod_cliente"));
		cliente.setCpf(result.getString("cli.cpf"));
		cliente.setNome(result.getString("cli.nome"));
		cliente.setStatus(result.getBoolean("cli.status"));

		// PEGA RESULTADO DE ENDERECO E COLOCA EM ENDERECO
		endereco.setBairro(result.getString("endereco.bairro"));
		endereco.setRua(result.getString("endereco.rua"));
		endereco.setCodEndereco(result.getInt("cli.cod_endereco"));
		endereco.setNumeroRua(result.getInt("endereco.numero_rua"));
		endereco.setCidade(result.getString("endereco.cidade"));

		// ADICIONAR EM CLIENTE O ENDERECO
		cliente.setEndereco(endereco);
		// COLOCA O OBJETO CLIENTE NA LISTA
		lista.add(cliente);
	    }
	    return lista;
	}
    }

    public boolean alterar(final Cliente cliente) throws Exception {

	// QUERY QUE FAZ O UPDATE DO CLIENTE
	final String SQL_UPDATE = "UPDATE gerenciamento_estoque.cliente "
		+ "SET status=?, nome=?, cpf=? WHERE cod_cliente = ? ;";
	// QUERY QUE FAZ O UPDATE DO ENDEREÇO
	final String SQL_UPDATE_ENDERECO = "UPDATE endereco ende"
		+ " INNER join cliente cli on cli.cod_endereco = ende.numero "
		+ "SET ende.bairro=?, ende.cep=?, ende.rua=?, ende.complemento=?, ende.status=?,ende.numero_rua = ?,"
		+ " ende.cidade = ?,ende.estado = ? " + "where cli.cod_cliente = ?;";

	// FAZ A CONEXÃO COM O BANCO DE DADOS
	final var con = conexao.getConexao();

	// CRIA O STATEMENT PARA UPDATE CLIENTE
	final var updateCliente = con.prepareStatement(SQL_UPDATE);
	// CRIA O STATEMENT PARA UPDATE ENDERECO
	final var updateEndereco = con.prepareStatement(SQL_UPDATE_ENDERECO);

	// DEVIDO AO TAMANHO DAS ALTERAÇÕES NÃO IREI COMITAR A CADA ALTERAÇÃO E SIM UMA
	// VEZ SO NO FINAL
	con.setAutoCommit(false);
	// QUERY PARA RETIRAR TODOS OS TELEFONES
	// ISO É UM WORKAROUND ATÉ DESCOBRIR UMA FORMA MELHOR DE FAZER ISSO
	final var excluiTelefone = con
		.prepareStatement("DELETE FROM gerenciamento_estoque.telefone WHERE cod_cliente = ?;");
	// QUERY PARA INSERIR OS TELEFONES
	final var insereTelefone = con.prepareStatement("INSERT INTO gerenciamento_estoque.telefone"
		+ " (ddd, status, tipo, cod_cliente,num_telefone)" + " VALUES(?, ?, ?, ?, ?);");
	try (con; updateCliente; excluiTelefone; insereTelefone) {

	    // COMEÇO ALTERA CLIENTE
	    // PEGA AS INFORMAÇÕES DO CLIENTE
	    updateCliente.setBoolean(1, cliente.getStatus());
	    updateCliente.setString(2, cliente.getNome());
	    updateCliente.setString(3, cliente.getCpf());
	    updateCliente.setInt(4, cliente.getCodCliente());
	    // FAZ A ALTERAÇÃO DE CLIENTE
	    updateCliente.executeUpdate();
	    // FIM ALTERA CLIENTE

	    // COMEÇO ALTERA ENDERECO
	    // PEGA AS INFORMAÇOES DE ENDERECO

	    updateEndereco.setString(1, cliente.getEndereco().getBairro());

	    updateEndereco.setString(2, cliente.getEndereco().getCep());

	    updateEndereco.setString(3, cliente.getEndereco().getRua());

	    updateEndereco.setString(4, cliente.getEndereco().getComplemento());

	    updateEndereco.setBoolean(5, true);
	    updateEndereco.setInt(6, cliente.getEndereco().getNumeroRua());
	    updateEndereco.setString(7, cliente.getEndereco().getCidade());
	    updateEndereco.setString(8, cliente.getEndereco().getEstado());

	    updateEndereco.setInt(9, cliente.getCodCliente());

	    // FAZ A ALTERAÇÃO DE ENDERECO
	    updateEndereco.executeUpdate();

	    // FIM ALTERA ENDERECO

	    // COMEÇO EXLCUIR TELEFONE
	    // FAZ A EXCLUSAO DE TODOS OS TELEFONES BASEADO NO ID DO CLIENTE
	    excluiTelefone.setInt(1, cliente.getCodCliente());
	    // EXCLUI OS TELEFONE
	    excluiTelefone.executeUpdate();
	    // FIM EXCLUIR TELEFONE

	    // COMEÇO INSERE TELEFONE
	    // CRIA UM INSERT PARA CADA TELEFONE
	    for (final var tel : cliente.getTelefone()) {
		insereTelefone.setInt(1, tel.getDdd());
		insereTelefone.setBoolean(2, true);
		insereTelefone.setString(3, tel.getTipo().toString());
		insereTelefone.setInt(4, cliente.getCodCliente());
		insereTelefone.setInt(5, tel.getNumTelefone());

		insereTelefone.addBatch();
	    }
	    // EXECUTA O INSERT DE TODOS OS TELEFONES
	    final var alterou = insereTelefone.executeBatch();
	    // FIM INSERE TELEFONE

	    con.commit();
	    return alterou.length >= 1;
	}
    }

    public boolean excluir(final int id) throws SQLException {// DESATIVA O CLIENTE BASEADO NO CODIGO DELE
	final var con = conexao.getConexao();

	// QUERY PARA DESATIVAR CLIENTE
	final var comando = con.prepareStatement(SQL_DELETE);
	try (con; comando;) {
	    // PEGA O ID DO CLIENTE
	    comando.setInt(1, id);

	    // DESATIVA O CLIENTE E RETORNA VERDADEIRO
	    return comando.executeUpdate() >= 1;
	}
    }

    public Cliente pegaTudoCliente(final int id) throws SQLException {// PEGA TODAS AS INFORMAÇÕES DO CLIENTE BASEADO NO
								      // CODIGO DO CLIENTE

	// CRIA UM OBJETO CLIENTE
	final var cliente = new Cliente();
	// CRIA UM OBJETO ENDERECO
	final var endereco = new Endereco();
	// PEGA A CONEXÃO DO BANCO
	final var con = conexao.getConexao();

	// QUERY PARA PEGAR O ENDERECO
	final var comando = con.prepareStatement(SQL_PEGA_CLIENTE_ENDERECO);
	// QUERY PARA PEGAR O TELEFONE
	final var comandoTelefone = con.prepareStatement(SQL_PEGA_CLIENTE_TELEFONE);
	try (con; comando; comandoTelefone) {

	    // COLOCA O ID DO CLIENTE
	    comando.setInt(1, id);

	    // PESQUISA O CLIENTE
	    final var cli = comando.executeQuery();
	    // SE O CLIENTE EXISTIR PREENCHE AS INFORMAÇÕES
	    if (cli.next()) {
		cliente.setCodCliente(cli.getInt("cli.cod_cliente"));
		cliente.setCpf(cli.getString("cli.cpf"));
		cliente.setNome(cli.getString("cli.nome"));
		cliente.setStatus(cli.getBoolean("cli.status"));
		endereco.setBairro(cli.getString("ende.bairro"));
		endereco.setCep(cli.getString("ende.cep"));
		endereco.setComplemento(cli.getString("ende.complemento"));
		endereco.setRua(cli.getString("ende.rua"));
		endereco.setCodEndereco(cli.getInt("ende.numero"));
		endereco.setNumeroRua(cli.getInt("ende.numero_rua"));
		endereco.setCidade(cli.getString("ende.cidade"));
		endereco.setEstado(cli.getString("ende.estado"));
		cliente.setEndereco(endereco);

	    }
	    // SE O ID DO CLIENTE PARA PESQUISAR TELEFONE
	    comandoTelefone.setInt(1, id);

	    // PEGA O RESULTADO DA PESQUISA
	    final var resultadoTel = comandoTelefone.executeQuery();

	    // SE NAO EXISTIR TELEFONE NÃO IRA FAZER NADA
	    if (resultadoTel != null) {
		// SE EXISITR IRA CRIAR UMA LISTA COM OS TELEFONE
		final var telefone = new ArrayList<Telefone>();
		// ITERA SOBRE TODOS OS TELEFONES
		while (resultadoTel.next()) {
		    final var tel = new Telefone();

		    tel.setDdd(resultadoTel.getInt("ddd"));
		    tel.setTipo(ETelefone.valueOf(resultadoTel.getString("tipo").toUpperCase()));
		    tel.setNumero(resultadoTel.getInt("numero"));
		    tel.setNumTelefone(resultadoTel.getInt("num_telefone"));

		    telefone.add(tel);
		}
		// COLOCA EM CLIENTE A LISTA DE TELEFONES
		cliente.setTelefone(telefone);
	    }

	}
	return cliente;
    }
}
