package negocio;

import java.sql.SQLException;

import acessoBD.AcessoBD;
import objeto.Funcionario;

public class NegLogin {
    private static final String SQL_SEARCH = "SELECT cod_funcionario,nome_usuario, acesso_adm, chave_acesso "
	    + "FROM gerenciamento_estoque.funcionario\n" + "WHERE nome_usuario = ? and chave_acesso = ?";
    private final AcessoBD conexao = new AcessoBD();

    public Boolean consultar(final Funcionario funcionario) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, funcionario.getNome());
	    comando.setString(2, funcionario.getChaveAcesso());

	    final var resultado = comando.executeQuery();
	    if (resultado.next()) {
		final var funcionarioPadrao = new Funcionario();
		funcionarioPadrao.setAcessoAdmin(resultado.getBoolean("acesso_adm"));
		funcionarioPadrao.setCodigoFuncionario(resultado.getInt("cod_funcionario"));
		Funcionario.setFuncionario(funcionarioPadrao);

		return true;
	    } else {
		return false;
	    }

	}
    }
}
