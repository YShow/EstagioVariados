package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import acessoBD.AcessoBD;
import objeto.Fornecedor;
import objeto.Telefone;
import utilidade.ETelefone;

public class NegFornecedor {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_ALTERAR = "UPDATE gerenciamento_estoque.fornecedor\n"
	    + "SET nome=?, nome_cidade=?, produto=?, status=?\n" + "WHERE cod_fornecedor= ?;\n";
    private static final String SQL_INSERIR = "INSERT INTO fornecedor(nome,nome_cidade,produto,status)\n"
	    + "VALUES(?,?,?,?);";
    private static final String SQL_SEARCH = "SELECT cod_fornecedor,nome,nome_cidade,produto,status"
	    + " from fornecedor where nome like ? and status = true ";

 
    public String consultaProdutoNome(final int id) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement("SELECT produto from fornecedor where cod_fornecedor = ?");

	try (con; comando;) {
	    comando.setInt(1, id);
	    final var resultado = comando.executeQuery();
	    String produto = null;
	    if (resultado.next()) {
		produto = resultado.getString("produto");
	    }
	    return produto;
	}

    }

    public boolean Inserir(final Fornecedor fornecedor, final List<Telefone> telefones) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERIR, Statement.RETURN_GENERATED_KEYS);
	final var inserirTelefone = con.prepareStatement("INSERT INTO gerenciamento_estoque.telefone"
		+ " (ddd, status, tipo, num_telefone, cod_fornecedor)\n" + "VALUES(?, ?, ?, ?, ?);");
	int inseriu[] = null;
	try (con; comando; inserirTelefone;) {
	    /*
	     * "INSERT INTO fornecedor(nome,nome_cidade,produto,status)\n" +
	     * "VALUES(?,?,?,?);";
	     */

	    comando.setString(1, fornecedor.getNome());
	    comando.setString(2, fornecedor.getNomeCidade());
	    comando.setString(3, fornecedor.getProduto());
	    comando.setBoolean(4, true);

	    comando.executeUpdate();
	    final var chave = comando.getGeneratedKeys();

	    if (chave.next()) {
		final int id = chave.getInt(1);
		for (final var telefone : telefones) {
		    /*
		     * INSERT INTO gerenciamento_estoque.telefone" + " (ddd, status, tipo,
		     * num_telefone, cod_fornecedor)
		     */
		    inserirTelefone.setInt(1, telefone.getDdd());
		    inserirTelefone.setBoolean(2, true);
		    inserirTelefone.setString(3, telefone.getTipo().toString());
		    inserirTelefone.setInt(4, telefone.getNumTelefone());
		    inserirTelefone.setInt(5, id);

		    inserirTelefone.addBatch();
		}
		inseriu = inserirTelefone.executeBatch();
	    }

	    return inseriu.length >= 1;
	}

    }

    public boolean Alerar(final Fornecedor fornecedor, final List<Telefone> telefones) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_ALTERAR);
	
	final var excluiTelefone = con
		.prepareStatement("DELETE FROM gerenciamento_estoque.telefone WHERE cod_fornecedor = ?;");
	final var insereTelefone = con.prepareStatement("INSERT INTO gerenciamento_estoque.telefone"
		+ " (ddd, status, tipo, cod_fornecedor,num_telefone)" + " VALUES(?, ?, ?, ?, ?);");
	try (con; comando; excluiTelefone;insereTelefone;) {
	    /*"UPDATE gerenciamento_estoque.fornecedor\n"
	    + "SET nome=?, nome_cidade=?,  produto=?
	    , status=?\n" + "WHERE cod_fornecedor= ?;\n*/
	    comando.setString(1, fornecedor.getNome());
	    comando.setString(2, fornecedor.getNomeCidade());
	    comando.setString(3, fornecedor.getProduto());
	    comando.setBoolean(4, fornecedor.isStatus());
	    comando.setInt(5, fornecedor.getCodFornecedor());
	    
	    comando.executeUpdate();
	    
	    excluiTelefone.setInt(1, fornecedor.getCodFornecedor());
	    excluiTelefone.executeUpdate();
	    
	    for (final var tel : telefones) {
		insereTelefone.setInt(1, tel.getDdd());
		insereTelefone.setBoolean(2, true);
		insereTelefone.setString(3, tel.getTipo().toString());
		insereTelefone.setInt(4, fornecedor.getCodFornecedor());
		insereTelefone.setInt(5, tel.getNumTelefone());

		insereTelefone.addBatch();
	    }
	    // EXECUTA O INSERT DE TODOS OS TELEFONES
	    final var alterou = insereTelefone.executeBatch();
	 
	    return alterou.length > 0;
	}
	
    }

    public List<Fornecedor> Consultar(final String nomeFornecedor) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_SEARCH);

	try (con; comando;) {
	    comando.setString(1, '%' + nomeFornecedor + '%');
	    final var resultado = comando.executeQuery();
	    final var listFornecedor = new ArrayList<Fornecedor>();
	    while (resultado.next()) {

		final var fornecedor = new Fornecedor();
		/*
		 * SELECT cod_fornecedor,nome,nome_cidade,produto" + " from fornecedor where
		 * nome = ?
		 */

		fornecedor.setCodFornecedor(resultado.getInt("cod_fornecedor"));
		fornecedor.setNome(resultado.getString("nome"));
		fornecedor.setNomeCidade(resultado.getString("nome_cidade"));
		fornecedor.setProduto(resultado.getString("produto"));
		fornecedor.setStatus(resultado.getBoolean("status"));

		listFornecedor.add(fornecedor);
	    }

	    return listFornecedor;
	}

    }

    public List<Telefone> pegaTelefonesFornecedor(final int id) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con
		.prepareStatement("SELECT telefone.ddd,telefone.num_telefone,telefone.tipo from telefone\n"
			+ "JOIN fornecedor on fornecedor.cod_fornecedor = telefone.cod_fornecedor\n"
			+ "where fornecedor.cod_fornecedor = ?");

	try (con; comando;) {
	    comando.setInt(1, id);
	    final var resultado = comando.executeQuery();
	    final var telefones = new ArrayList<Telefone>();
	    while (resultado.next()) {
		final var telefone = new Telefone();
		telefone.setDdd(resultado.getInt("telefone.ddd"));
		telefone.setNumTelefone(resultado.getInt("telefone.num_telefone"));
		telefone.setTipo(ETelefone.valueOf(resultado.getString("telefone.tipo").toUpperCase()));

		telefones.add(telefone);
	    }
	    return telefones;
	}

    }

    public boolean remover(final int id) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con
		.prepareStatement("UPDATE gerenciamento_estoque.fornecedor status=false WHERE cod_fornecedor= ?;");

	try (con; comando;) {
	    comando.setInt(1, id);
	    return comando.executeUpdate() >= 1;
	}

    }

}
