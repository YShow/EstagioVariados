package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import acessoBD.AcessoBD;
import objeto.EntradaMercadoria;
import objeto.Funcionario;

public class NegMercadoria {
    private final AcessoBD conexao = new AcessoBD();

    private static final String SQL_INSERT = "INSERT INTO entrada_mercadoria(data_entrega,quantidade_produto,status,cod_fornecedor)\n"
	    + "values(?,?,?,?);";
    private static final String SQL_ALTER = "UPDATE entrada_mercadoria set data_entrega = ?"
	    + ", quantidade_produto = ?" + ", status = ?, cod_fornecedor = ?\n" + "WHERE codigo_entrada = ?;";

    private static final String SQL_SEARCH = "SELECT codigo_entrada,data_entrega,quantidade_produto,"
	    + "status,cod_fornecedor from entrada_mercadoria\n" + "WHERE data_entrega = ?";

    private static final String SQL_EXCLUIR = "update entrada_mercadoria SET status = false where codigo_entrada = ?";

    public boolean Inserir(final EntradaMercadoria entrada) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
	final var insereTabelaNxN = con
		.prepareStatement("INSERT into recebe(cod_funcionario,cod_mercadoria) VALUES (?,?)");
	try (con; comando;) {
	    con.setAutoCommit(false);
	    comando.setObject(1, entrada.getDataEntrega());
	    comando.setInt(2, entrada.getQuantidadeProduto());
	    comando.setBoolean(3, entrada.isStatus());
	    comando.setInt(4, entrada.getCodigoFornecedor());

	    final var inseriu = comando.executeUpdate() >= 1;

	    final var resultado = comando.getGeneratedKeys();
	    int idMercadoria;
	    if (resultado.next()) {
		idMercadoria = resultado.getInt(1);

		insereTabelaNxN.setInt(1, Funcionario.getFuncionario().getCodigoFuncionario());
		insereTabelaNxN.setInt(2, idMercadoria);
		insereTabelaNxN.executeUpdate();

	    }

	    con.commit();
	    return inseriu;
	}

    }

    public List<EntradaMercadoria> Consulta(final LocalDate data) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_SEARCH);
	try (con; comando;) {
	    comando.setObject(1, data);
	    final var resultado = comando.executeQuery();
	    final var listMercadoria = new ArrayList<EntradaMercadoria>();
	    while (resultado.next()) {
		/*
		 * SELECT codigo_entrada,data_entrega,quantidade_produto," +
		 * "status,cod_fornecedor from entrada_mercadoria\n
		 */
		final var mercadoria = new EntradaMercadoria();
		mercadoria.setCodigoEntrada(resultado.getInt("codigo_entrada"));
		mercadoria.setCodigoFornecedor(resultado.getInt("cod_fornecedor"));
		mercadoria.setDataEntrega(resultado.getObject("data_entrega", LocalDate.class));
		mercadoria.setQuantidadeProduto(resultado.getInt("quantidade_produto"));
		mercadoria.setStatus(resultado.getBoolean("status"));
		listMercadoria.add(mercadoria);
	    }

	    return listMercadoria;
	}

    }

    public boolean Alterar(final EntradaMercadoria mercadoria) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_ALTER);
	try (con; comando;) {
	    /*
	     * "UPDATE entrada_mercadoria set data_entrega = ?" +
	     * ", set quantidade_produto = ?" + ", status = ?, cod_fornecedor =
	     * ?\n" + "WHERE codigo_entrada = ?;";
	     */
	    comando.setObject(1, mercadoria.getDataEntrega());
	    comando.setInt(2, mercadoria.getQuantidadeProduto());
	    comando.setBoolean(3, mercadoria.isStatus());
	    comando.setInt(4, mercadoria.getCodigoFornecedor());
	    comando.setInt(5, mercadoria.getCodigoEntrada());

	    return comando.executeUpdate() >= 1;
	}
    }

    public boolean Remover(final int id) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_EXCLUIR);
	try (con; comando;) {
	    comando.setInt(1, id);

	    return comando.executeUpdate() >= 1;
	}
    }
}
