package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.AcessoBD;
import objeto.Produto;

public class NegProduto {
    private final AcessoBD conexao = new AcessoBD();

    private static final String SQL_EXCLUIR = "UPDATE gerenciamento_estoque.produto \n"
	    + "SET status=? WHERE cod_produto= ?;";
    private static final String SQL_ALTERAR = "UPDATE gerenciamento_estoque.produto "
	    + "SET quantidade_produto=?, preco_custo=?, preco_venda=?,"
	    + " nome_produto=?, status=?, preco_casco=? WHERE cod_produto= ?;\n";
    private static final String SQL_INSERIR = "INSERT INTO gerenciamento_estoque.produto "
	    + "(quantidade_produto, preco_custo, preco_venda, nome_produto, status, preco_casco)"
	    + " VALUES(?, ?, ?, ?, ?, ?);\n";
    private static final String SQL_SEARCH = "SELECT cod_produto, quantidade_produto, preco_custo, preco_venda,"
	    + " nome_produto, preco_casco " + " FROM gerenciamento_estoque.produto WHERE nome_produto like ?;";

    public boolean inserir(final Produto produto) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERIR);
	try (con; comando;) {
	    comando.setInt(1, produto.getQuantidadeProduto());
	    comando.setBigDecimal(2, produto.getPrecoCusto());
	    comando.setBigDecimal(3, produto.getPrecoVenda());
	    comando.setString(4, produto.getNomeProduto());
	    comando.setBoolean(5, produto.isStatus());
	    comando.setBigDecimal(6, produto.getPrecoCasco());

	    return comando.executeUpdate() >= 1;

	}
    }

    public List<Produto> consultar(final String metodo) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_SEARCH);
	try (con; comando;) {
	    comando.setString(1, metodo + '%');
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<Produto>();
	    while (result.next()) {
		final var produto = new Produto();

		/*
		 * cod_produto, quantidade_produto, preco_custo, preco_venda," + " nome_produto,
		 * preco_casco
		 */
		produto.setCodProduto(result.getInt("cod_produto"));
		produto.setQuantidadeProduto(result.getInt("quantidade_produto"));
		produto.setPrecoCusto(result.getBigDecimal("preco_custo"));
		produto.setPrecoVenda(result.getBigDecimal("preco_venda"));
		produto.setNomeProduto(result.getString("nome_produto"));
		produto.setPrecoCasco(result.getBigDecimal("preco_casco"));

		lista.add(produto);
	    }
	    return lista;
	}
    }

    public boolean alterar(final Produto produto) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_ALTERAR);
	try (con; comando;) {

	    /*
	     * quantidade_produto=?, preco_custo=?, preco_venda=?," + " nome_produto=?,
	     * status=?, preco_casco=? WHERE cod_produto= ?
	     */
	    comando.setInt(1, produto.getQuantidadeProduto());
	    comando.setBigDecimal(2, produto.getPrecoCusto());
	    comando.setBigDecimal(3, produto.getPrecoVenda());
	    comando.setString(4, produto.getNomeProduto());
	    comando.setBoolean(5, produto.isStatus());
	    comando.setBigDecimal(6, produto.getPrecoCasco());
	    comando.setInt(7, produto.getCodProduto());

	    return comando.executeUpdate() >= 1;
	}
    }

    public boolean excluir(final int id) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_EXCLUIR);
	try (con; comando;) {
	    /*
	     * UPDATE gerenciamento_estoque.produto \n" + "SET status=? WHERE cod_produto= ?
	     */
	    comando.setBoolean(1, false);
	    comando.setInt(2, id);

	    return comando.executeUpdate() >= 1;
	}
    }
}
