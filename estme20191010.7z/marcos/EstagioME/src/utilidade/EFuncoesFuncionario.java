package utilidade;

public enum EFuncoesFuncionario {
    ADMINISTRADOR("Administrador"),
    ATENDENTE("Atendente"),
    MOTOBOY("Motoboy");

    private String funcao;

    EFuncoesFuncionario(String funcao) {
        this.funcao = funcao;
    }

    @Override
    public String toString() {
        return funcao;
    }
}
