package utilidade;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.StageStyle;

public class Alerta {

    private Alerta() {
	throw new IllegalStateException("Utility");
    }

    public static Alert alertaSucesso() {
	final var alerta = new Alert(Alert.AlertType.INFORMATION);
	alerta.initStyle(StageStyle.TRANSPARENT);
	alerta.setTitle("Sucesso");
	alerta.setHeaderText("Função realizada com sucesso");
	alerta.setHeight(300);
	alerta.setWidth(300);
	return alerta;

    }

    public static Alert alertaErro(final String erro) {
	final var alerta = new Alert(Alert.AlertType.ERROR);

	alerta.setTitle("Ocorreu um problema");
	alerta.setHeaderText("Verifique os campos e informe o erro ao desenvolvedor");
	alerta.setContentText("Erro: " + erro);
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	return alerta;

    }

    public static Alert alertaCampoNulo() {
	final var alerta = new Alert(Alert.AlertType.INFORMATION);
	alerta.setHeaderText("Verifique os campos");
	alerta.setContentText("Por favor verifique se todos os campos foram preenchidos");
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	return alerta;
    }

    public static Alert alertaClienteEmCaixa() {
	final var alerta = new Alert(Alert.AlertType.WARNING);
	alerta.setHeaderText("Cliente possui caixa");
	alerta.setContentText("Não é possivel desativar este cliente ele ja possui um caixa");
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	return alerta;
    }
    
    public static Alert alertaSenhaNaoBate() {
	final var alerta = new Alert(Alert.AlertType.WARNING);
	alerta.setHeaderText("Senha inserida invalida");
	alerta.setContentText("A senha inserida não é igual a senha de confirmação");
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	return alerta;
    }
}
