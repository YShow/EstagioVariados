package utilidade;

public enum ETelefone {
 
        FIXO("FIXO"),
        MOVEL("MOVEL");

        private String label;

        ETelefone(String label) {
            this.label = label;
        }

        @Override
	public String toString() {
            return label;
        }
    
}
