package apresentacao.Mercadoria;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import apresentacao.Fornecedor.ControladorConsultarFornecedor;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegMercadoria;
import objeto.EntradaMercadoria;
import utilidade.Alerta;

public class ControladorCadastrarMercadoria {

    @FXML
    private TextField txtDataEntrega;

    @FXML
    private TextField txtQuantidade;

    @FXML
    private TextField txtNomeProduto;

    @FXML
    private TextField txtCodFornecedor;

    @FXML
    private Button btnBuscarFornecedor;

    @FXML
    private Button btnConcluir;

    @FXML
    private Button btnCancelarCadastro;
    private static int idFornecedor;
    private final DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public void abreTelaCadastrarMercadoria() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Mercadoria/CadastrarMercadoria.fxml"));
	    root = loader.load();
	    final var controler = (ControladorCadastrarMercadoria) loader.getController();
	    controler.txtDataEntrega.setText(LocalDate.now().format(formato));
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
    void BuscarFornecedor(final ActionEvent event) {
	// TODO TELA FORNECEDOR
	final var telaFornecedor = new ControladorConsultarFornecedor();
	final var fornecedor = telaFornecedor.abreTelaConsultaFornecedorPegaValor();
	idFornecedor = fornecedor.getCodFornecedor();
	txtCodFornecedor.setText(String.valueOf(idFornecedor));
    }

    @FXML
    void CancelarCadastro(final ActionEvent event) {
	btnCancelarCadastro.getScene().getWindow().hide();
    }

    @FXML
    void ConcluirCadastro(final ActionEvent event) {
	final var negMercadoria = new NegMercadoria();
	final var mercadoria = new EntradaMercadoria();
	mercadoria.setCodigoFornecedor(idFornecedor);
	mercadoria.setDataEntrega(LocalDate.parse(txtDataEntrega.getText(), formato));
	mercadoria.setQuantidadeProduto(Integer.valueOf(txtQuantidade.getText()));
	mercadoria.setStatus(true);
	try {
	    if (negMercadoria.Inserir(mercadoria)) {
		Alerta.alertaSucesso().show();
		btnConcluir.getScene().getWindow().hide();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }
}
