package apresentacao.Mercadoria;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import apresentacao.Fornecedor.ControladorConsultarFornecedor;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFornecedor;
import negocio.NegMercadoria;
import objeto.EntradaMercadoria;
import utilidade.Alerta;

public class ControladorAlterarMercadoria {
    @FXML
    private TextField txtQuantidade;

    @FXML
    private TextField txtNomeProduto;

    @FXML
    private TextField txtCodFornecedor;

    @FXML
    private Button btnBuscarFornecedor;

    @FXML
    private Button btnConcluir;

    @FXML
    private Button btnCancelar;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private TextField txtDataEntrega;
    @FXML
    private Label txtcodMerc;

    private static int idFornecedor;

    public void abreTelaAlteraMercadoria(final EntradaMercadoria mercadoria) {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Mercadoria/AlterarMercadoria.fxml"));
	    root = loader.load();
	    final var controler = (ControladorAlterarMercadoria) loader.getController();
	    controler.txtCodFornecedor.setText(String.valueOf(mercadoria.getCodigoFornecedor()));
	    controler.txtDataEntrega.setText(mercadoria.getDataEntrega().toString());
	    controler.txtQuantidade.setText(String.valueOf(mercadoria.getQuantidadeProduto()));
	    controler.chkAtivo.setSelected(mercadoria.isStatus());
	    controler.txtcodMerc.setText(String.valueOf(mercadoria.getCodigoEntrada()));
	    final var negForn = new NegFornecedor();
	    controler.txtNomeProduto.setText(negForn.consultaProdutoNome(mercadoria.getCodigoFornecedor()));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException | SQLException e) {
	   Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
    void BuscarFornecedor(final ActionEvent event) {
	final var telaFornecedor = new ControladorConsultarFornecedor();
	final var fornecedor = telaFornecedor.abreTelaConsultaFornecedorPegaValor();
	idFornecedor = fornecedor.getCodFornecedor();
	txtNomeProduto.setText(fornecedor.getProduto());
	txtCodFornecedor.setText(String.valueOf(idFornecedor));
    }

    @FXML
    void CancelarAlteracao(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void ConcluirAlteracao(final ActionEvent event) {
	final var mercadoria = new EntradaMercadoria();
	mercadoria.setCodigoFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
	mercadoria.setDataEntrega(LocalDate.now());
	mercadoria.setQuantidadeProduto(Integer.parseInt(txtQuantidade.getText()));
	mercadoria.setStatus(chkAtivo.isSelected());
	mercadoria.setCodigoEntrada(Integer.parseInt(txtcodMerc.getText()));

	final var negMerc = new NegMercadoria();
	try {
	    if (negMerc.Alterar(mercadoria)) {
		Alerta.alertaSucesso().show();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }
}
