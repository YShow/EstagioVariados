package apresentacao.Mercadoria;

import java.io.IOException;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;

import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegMercadoria;
import objeto.EntradaMercadoria;
import utilidade.Alerta;

public class ControladorConsultarMercadoria {

    @FXML
    private Button btnConsultar;

    @FXML
    private Button btnInativar;

    @FXML
    private Button btnAlterar;

    @FXML
    private Button btnCadastrar;
    @FXML
    private DatePicker dpData;

    @FXML
    private TableView<EntradaMercadoria> tblMercadoria;

    @FXML
    private TableColumn<EntradaMercadoria, Integer> tcCodigo;

    @FXML
    private TableColumn<EntradaMercadoria, String> tcData;

    @FXML
    private TableColumn<EntradaMercadoria, Integer> tcQuantidade;

    @FXML
    private TableColumn<EntradaMercadoria, Boolean> tcStatus;

    @FXML
    private TableColumn<EntradaMercadoria, Integer> tcFornecedor;

    public void abreTelaConsultaMercadoria() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Mercadoria/ConsultarMercadoria.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	   Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
    void AlterarMercadoria(final ActionEvent event) {
	final var mercadoria = tblMercadoria.getSelectionModel().getSelectedItem();
	final var alteraMercadoria = new ControladorAlterarMercadoria();
	alteraMercadoria.abreTelaAlteraMercadoria(mercadoria);
    }

    @FXML
    void CadastrarMercadoria(final ActionEvent event) {
	final var cadastraMercadoria = new ControladorCadastrarMercadoria();
	cadastraMercadoria.abreTelaCadastrarMercadoria();
    }

    @FXML
    void ConsultarMercadoria(final ActionEvent event) {
	final var negMercadoria = new NegMercadoria();

	try {
	    final var mercadorias = negMercadoria.Consulta(dpData.getValue());
	    final var data = FXCollections.observableList(mercadorias);
	    tblMercadoria.setItems(data);

	    tcCodigo.setCellValueFactory(
		    codigo -> new ReadOnlyIntegerWrapper(codigo.getValue().getCodigoEntrada()).asObject());
	    tcData.setCellValueFactory(dataMerc -> new ReadOnlyStringWrapper(
		    dataMerc.getValue().getDataEntrega().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))));
	    tcFornecedor.setCellValueFactory(
		    forn -> new ReadOnlyIntegerWrapper(forn.getValue().getCodigoFornecedor()).asObject());
	    tcQuantidade.setCellValueFactory(
		    quantidade -> new ReadOnlyIntegerWrapper(quantidade.getValue().getQuantidadeProduto()).asObject());
	    tcStatus.setCellValueFactory(status -> new ReadOnlyBooleanWrapper(status.getValue().isStatus()));

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }

    @FXML
    void InativarMercadoria(final ActionEvent event) {
	final var mercadoria = tblMercadoria.getSelectionModel().getSelectedItem();
	final var negMercadoria = new NegMercadoria();
	try {
	    if (negMercadoria.Remover(mercadoria.getCodigoEntrada())) {
		tblMercadoria.getItems().remove(mercadoria);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }
}
