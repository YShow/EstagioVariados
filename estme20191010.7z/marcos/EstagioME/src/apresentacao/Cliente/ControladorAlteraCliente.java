package apresentacao.Cliente;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import negocio.NegCliente;
import objeto.Cliente;
import objeto.Endereco;
import objeto.Telefone;
import utilidade.Alerta;
import utilidade.ETelefone;

public class ControladorAlteraCliente {
    @FXML
    private TextField txtNomeCliente;

    @FXML
    private TextField txtRuaCliente;

    @FXML
    private TextField txtCpfCliente;

    @FXML
    private TextField txtEndNumCliente;

    @FXML
    private TextField txtCompCliente;

    @FXML
    private TextField txtBairroCliente;

    @FXML
    private TextField txtCepCliente;

    @FXML
    private Button btnAddNumLista;

    @FXML
    private TableView<Telefone> tblTelefone;

    @FXML
    private Button btnAlterarCliente;

    @FXML
    private Button btnCancelaAlteracao;

    @FXML
    private Button btnExcluirNumTel;

    @FXML
    private TextField txtCidade;

    @FXML
    private TextField txtNumTelefone;

    @FXML
    private TextField txtDDD;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private TableColumn<Telefone, Integer> tcDDD;

    @FXML
    private TableColumn<Telefone, Integer> tcNumero;

    @FXML
    private TableColumn<Telefone, ETelefone> tcTipo;

    private static int codCli;
    private ControladorAlteraCliente controlador;
    @FXML
    private ChoiceBox<ETelefone> cbTipoTel;

    @FXML
    private TextField txtEstado;

    void abreTelaAlteraCliente(final int codCliente) {// FUNCAO QUE INSTANCIA A TELA DE ALTERAR CLIENTE

	codCli = codCliente;

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Cliente/AlterarCliente.fxml"));
	    root = loader.load();

	    controlador = (ControladorAlteraCliente) loader.getController();
	    controlador.cbTipoTel.setItems(FXCollections.observableArrayList(ETelefone.values()));
	    formataCampo();
	    preencheTela(codCliente);
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    private void preencheTela(final int idcliente) {
	// PEGA O ID DO CLIENTE E CONSULTA TODAS AS INFORMAÇÕES
	// DEPOIS COLOCA TODAS AS INFORMAÇÕES NOS CAMPOS DESTA TELA
	final var negCliente = new NegCliente();
	try {

	    final var cliente = negCliente.pegaTudoCliente(idcliente);
	    controlador.txtNomeCliente.setText(cliente.getNome());
	    controlador.txtCpfCliente.setText(cliente.getCpf());
	    controlador.txtCepCliente.setText(cliente.getEndereco().getCep());
	    controlador.txtCompCliente.setText(cliente.getEndereco().getComplemento());
	    controlador.txtRuaCliente.setText(cliente.getEndereco().getRua());
	    controlador.txtEndNumCliente.setText(String.valueOf(cliente.getEndereco().getNumeroRua()));
	    controlador.txtBairroCliente.setText(cliente.getEndereco().getBairro());
	    controlador.txtCidade.setText(cliente.getEndereco().getCidade());
	    controlador.txtEstado.setText(cliente.getEndereco().getEstado());
	    controlador.chkAtivo.setSelected(true);
	    final var data = FXCollections.observableList(cliente.getTelefone());
	    controlador.tblTelefone.setItems(data);

	    controlador.tcDDD
		    .setCellValueFactory(tel -> new ReadOnlyIntegerWrapper(tel.getValue().getDdd()).asObject());

	    controlador.tcNumero
		    .setCellValueFactory(tel -> new ReadOnlyIntegerWrapper(tel.getValue().getNumTelefone()).asObject());
	    controlador.tcTipo.setCellValueFactory(new PropertyValueFactory<Telefone,ETelefone>("Tipo"));

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void AddNumLista(final ActionEvent event) {// ADICIONA UM NUMERO A TABLE VIEW DE TELEFONES
	tcDDD.setCellValueFactory(ddd -> new ReadOnlyIntegerWrapper(ddd.getValue().getDdd()).asObject());

	tcNumero.setCellValueFactory(
		numero -> new ReadOnlyIntegerWrapper(numero.getValue().getNumTelefone()).asObject());
	tcTipo.setCellValueFactory(new PropertyValueFactory<Telefone,ETelefone>("Tipo"));

	final var telefone = new Telefone();
	telefone.setDdd(Integer.valueOf(txtDDD.getText().trim()));

	telefone.setNumTelefone(Integer.valueOf(txtNumTelefone.getText().trim()));
	telefone.setTipo(cbTipoTel.getValue());

	tblTelefone.getItems().add(telefone);
    }

    @FXML
    void AlterarCliente(final ActionEvent event) {
	// PEGA AS ALTERAÇÕES DO CLIENTE E PASSA PARA A CAMADA DE NEGOCIO PARA ALTERAR
	final var negCliente = new NegCliente();

	try {

	    if (negCliente.alterar(pegaCliente())) {
		System.out.println("alterou");
		final var alerta = Alerta.alertaSucesso();
		final var botao = alerta.showAndWait();
		if (botao.isPresent() && botao.get().equals(ButtonType.OK)) {
		    btnAlterarCliente.getScene().getWindow().hide();
		}
	    }
	} catch (final Exception e) {

	    Alerta.alertaErro(e.toString()).show();
	}

    }

    private Cliente pegaCliente() { // FUNCAO QUE PEGA TODOS OS DADOS DE CLIENTE E COLOCA EM UM CLIENTE
	final var cliente = new Cliente();
	final var endereco = new Endereco();

	endereco.setBairro(txtBairroCliente.getText().trim());
	endereco.setCep(txtCepCliente.getText().trim());
	endereco.setComplemento(txtCompCliente.getText().trim());
	endereco.setRua(txtRuaCliente.getText().trim());
	endereco.setNumeroRua(Integer.valueOf(txtEndNumCliente.getText().trim()));
	endereco.setStatus(true);
	endereco.setEstado(txtEstado.getText().trim());
	endereco.setCidade(txtCidade.getText().trim());

	cliente.setCpf(txtCpfCliente.getText());
	cliente.setEndereco(endereco);
	cliente.setNome(txtNomeCliente.getText());
	cliente.setCodCliente(codCli);
	cliente.setStatus(chkAtivo.isSelected());

	final var tel = new ArrayList<Telefone>();
	for (final var telefone : tblTelefone.getItems()) {
	    tel.add(telefone);

	}
	cliente.setTelefone(tel);

	return cliente;
    }

    @FXML
    void CancelaAlteracaoCliente(final ActionEvent event) {// FEXA A TELA DE ALTERAR
	btnCancelaAlteracao.getScene().getWindow().hide();
    }

    @FXML
    void ExcluirNumeroTel(final ActionEvent event) {// ECLUI O TELEFONE DA TABLE VIEW DE TELEFONE
	final var telExcluir = tblTelefone.getSelectionModel().getSelectedItem();
	tblTelefone.getItems().remove(telExcluir);
	tblTelefone.refresh();
    }

    private void formataCampo() {
	final var incompleto = "#F5757E";
	final var errado = "#F24B4B";
	final var NUMERO = "[0-9]*";
	this.controlador.btnAlterarCliente.setDisable(true);

	this.controlador.txtCpfCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 11 && change.getControlNewText().matches(NUMERO)) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("CPF menor que 11 numeros");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() == 11) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Valores numericos apenas");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 11 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO

		return null;
	    }
	}));

	this.controlador.txtCepCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 14 && change.getControlNewText().matches(NUMERO)) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("CEP menor que 14 numeros");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() == 14) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Valores numericos apenas");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtEndNumCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 20 && change.getControlNewText().matches(NUMERO)) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("Pelo menos um numero de endereco");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 1) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Valores numericos apenas");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtNomeCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("O nome é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 10) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Nome maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtRuaCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("A rua é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 6) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Rua maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtBairroCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 30) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("O bairro é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 4) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Nome maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtCidade.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("A cidade é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 4) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Cidade maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtEstado.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("O estado é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 4) {
		    this.controlador.btnAlterarCliente.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Estado maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnAlterarCliente.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

    }
}
