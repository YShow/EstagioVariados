package apresentacao.Cliente;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegCliente;
import objeto.Cliente;
import objeto.Funcionario;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorConsultaCliente {
    @FXML
    private TextField txtCliente;

    @FXML
    private Button btnConsultaCliente;

    @FXML
    private Button btnInativarCliente;

    @FXML
    private Button btnAlterarCliente;

    @FXML
    private Button btnCadastraCliente;

    @FXML
    private TableView<Cliente> tvCliente;

    @FXML
    private TableColumn<Cliente, Integer> tcCodigo;

    @FXML
    private TableColumn<Cliente, String> tcNome;

    @FXML
    private TableColumn<Cliente, String> tcCidade;

    @FXML
    private TableColumn<Cliente, String> tcRua;

    @FXML
    private TableColumn<Cliente, Integer> tcNumero;

    @FXML
    private TableColumn<Cliente, String> tcBairro;
    @FXML
    private TableColumn<Cliente, Integer> tcCodEnd;
 

    public void abrirTelaCliente(final TIPO_TELA tipo_tela) { // FUNCAO QUE INSTANCIA A TELA DE CONSULTA

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Cliente/ConsultarCliente.fxml"));
	    root = loader.load();
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);
	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());

	    stage.setScene(scene);
	    if (tipo_tela.equals(TIPO_TELA.CONSULTA)) {

	    }
	    if (!Funcionario.getFuncionario().isAcessoAdmin()) {

	    }
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }
    
    public Cliente abrirTelaClienteSelecionar() { 

   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);
   
   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Cliente/ConsultarCliente.fxml"));
   	    root = loader.load();
   	    ControladorConsultaCliente control = loader.getController();
   	    control.btnAlterarCliente.setDisable(true);
   	    control.btnCadastraCliente.setDisable(true);
   	
   	    control.btnInativarCliente.setOnAction(e -> {
   	     control.btnInativarCliente.getScene().getWindow().hide();
   	    });
   	    
   	    final var scene = new Scene(root);
   	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());

   	    stage.setScene(scene);
   	    stage.showAndWait();
   	 return control.pegaCliente();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage());
   	}
	return null;
	
   	
       }
    
    private Cliente pegaCliente() {
	return tvCliente.getSelectionModel().getSelectedItem();
    }

    @FXML
    void AlterarCliente(final ActionEvent event) { // CHAMA A TELA DE ALTERAR CLIENTE
	final var telaAltera = new ControladorAlteraCliente();
	final var cliente = tvCliente.getSelectionModel().getSelectedItem();
	telaAltera.abreTelaAlteraCliente(cliente.getCodCliente());

    }

    @FXML
    void CadastraCliente(final ActionEvent event) { // CHAMA A TELA DE CADASTRAR CLIENTE
	final var telaCadastro = new ControladorCadastraCliente();
	telaCadastro.abreTelaCadastroCliente();
    }

    @FXML
    void ConsultaCliente(final ActionEvent event) { // FAZ A CONSULTA PELO NOME DO CLIENTE E COLOCA O RETORNO NA TABELA
	tvCliente.getItems().clear();
	final var negCliente = new NegCliente();
	try {
	    final List<Cliente> cliente = negCliente.consultar(txtCliente.getText());
	    if (cliente.isEmpty()) {
		Alerta.alertaErro("Nenhum cliente encontrado");
	    } else {
		tvCliente.getItems().clear();
		final var data = FXCollections.observableList(cliente);
		tvCliente.setItems(data);
		tcCodigo.setCellValueFactory(new PropertyValueFactory("codCliente"));
		tcBairro.setCellValueFactory(
			bairro -> new ReadOnlyStringWrapper(bairro.getValue().getEndereco().getBairro()));

		tcCidade.setCellValueFactory(
			cidade -> new ReadOnlyStringWrapper(cidade.getValue().getEndereco().getCidade()));

		tcNome.setCellValueFactory(new PropertyValueFactory("nome"));
		tcNumero.setCellValueFactory(
			numero -> new ReadOnlyIntegerWrapper(numero.getValue().getEndereco().getNumeroRua())
				.asObject());
		tcRua.setCellValueFactory(rua -> new ReadOnlyStringWrapper(rua.getValue().getEndereco().getRua()));
		tcCodEnd.setCellValueFactory(
			codEnd -> new ReadOnlyIntegerWrapper(codEnd.getValue().getEndereco().getCodEndereco())
				.asObject());
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void InativarCliente(final ActionEvent event) {
	final var cliente = tvCliente.getSelectionModel().getSelectedItem();// PEGA CLIENTE SELECIONADO NA TELA
	final var negCliente = new NegCliente();// INSTANCIA A CAMADA DE NEGOCIO
	try {

	    if (negCliente.excluir(cliente.getCodCliente()))// SE RETORNAR VERDADEIRO O CLIENTE FOI EXCLUIDO
	    {
		Alerta.alertaSucesso().show(); // ALERTA QUE FOI EXCLUIDO
		tvCliente.getItems().remove(cliente);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
