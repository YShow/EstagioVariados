package apresentacao.Cliente;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import negocio.NegCliente;
import objeto.Cliente;
import objeto.Endereco;
import objeto.Telefone;
import utilidade.Alerta;
import utilidade.ETelefone;

public class ControladorCadastraCliente {
    @FXML
    private TextField txtNomeCliente;

    @FXML
    private TextField txtRuaCliente;

    @FXML
    private TextField txtCpfCliente;

    @FXML
    private TextField txtEndNumCliente;

    @FXML
    private TextField txtCompCliente;

    @FXML
    private TextField txtBairroCliente;

    @FXML
    private TextField txtCidade;

    @FXML
    private TextField txtCepCliente;

    @FXML
    private TextField txtNumTelefone;

    @FXML
    private TextField txtDDD;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnCancelCadastro;

    @FXML
    private Button btnAddNumLista;

    @FXML
    private TableView<Telefone> tblTelefone;

    @FXML
    private TableColumn<Telefone, Integer> tcDDD;

    @FXML
    private TableColumn<Telefone, Integer> tcNumero;

    @FXML
    private TableColumn<Telefone, ETelefone> tcTipo;

    @FXML
    private ChoiceBox<ETelefone> cbTipoTel;
    @FXML
    private TextField txtEstado;

    private ControladorCadastraCliente controlador;

    void abreTelaCadastroCliente() { // INSTANCIA A TELA DE CADASTRO DE CLIENTE
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Cliente/CadastrarCliente.fxml"));
	    root = loader.load();

	    this.controlador = (ControladorCadastraCliente) loader.getController();
	    controlador.cbTipoTel.getItems().setAll(ETelefone.values());
	    formataCampo();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);
	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void AddNumLista(final ActionEvent event) { // ADICIONA O NUMERO NA TABLE VIEW
	tcDDD.setCellValueFactory(new PropertyValueFactory("Ddd"));

	tcNumero.setCellValueFactory(new PropertyValueFactory("NumTelefone"));
	tcTipo.setCellValueFactory(new PropertyValueFactory<Telefone,ETelefone>("Tipo"));

	final var telefone = new Telefone();
	telefone.setDdd(Integer.valueOf(txtDDD.getText()));

	telefone.setNumTelefone(Integer.valueOf(txtNumTelefone.getText()));
	telefone.setTipo(cbTipoTel.getValue());
	System.out.println(cbTipoTel.getValue().toString());

	tblTelefone.getItems().add(telefone);

    }

    @FXML
    private void Cadastrar(final ActionEvent event) { // FUNCAO QUE CADASTRA O CLIENTE
	final var negCadastra = new NegCliente();
	try {

	    if (checaTelefone() && negCadastra.inserir(pegaCliente(), pegaTelefone())) {
		final var alerta = Alerta.alertaSucesso();
		final var botao = alerta.showAndWait();
		if (botao.isPresent() && botao.get().equals(ButtonType.OK)) {
		    btnCadastrar.getScene().getWindow().hide();
		}
	    }

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();

	}

    }

    @FXML
    void CancelCadastro(final ActionEvent event) { // FEXA A TELA DE CADASTRO
	btnCancelCadastro.getScene().getWindow().hide();
    }

    private Cliente pegaCliente() // FUNCAO QUE PEGA TODOS OS DADOS E COLOCA EM UM OBJETO CLIENTE
    {
	final var cliente = new Cliente();
	final var endereco = new Endereco();
	endereco.setBairro(txtBairroCliente.getText().trim());
	endereco.setCep(txtCepCliente.getText().trim());
	endereco.setComplemento(txtCompCliente.getText().trim());
	endereco.setRua(txtRuaCliente.getText().trim());
	endereco.setNumeroRua(Integer.valueOf(txtEndNumCliente.getText().trim()));
	endereco.setStatus(true);
	endereco.setCidade(txtCidade.getText().trim());
	endereco.setEstado(txtEstado.getText().trim());

	cliente.setCpf(txtCpfCliente.getText().trim());
	cliente.setEndereco(endereco);
	cliente.setNome(txtNomeCliente.getText().trim());

	return cliente;
    }

    private List<Telefone> pegaTelefone() // PEGA TODOS OS TELEFONES DA LISTA E COLOCA EM UM ARRAYLIST
    {
	final var tel = new ArrayList<Telefone>();
	for (final var telefone : tblTelefone.getItems()) {
	    tel.add(telefone);
	}
	return tel;
    }

    private boolean checaTelefone() {

	if (tblTelefone.getItems().isEmpty()) {
	    final var alerta = Alerta.alertaCampoNulo();
	    alerta.setTitle("Campos Nulos");
	    alerta.setHeaderText("Campos obrigatorios não preenchidos");
	    alerta.setContentText("Cliente deve ter pelo menos um telefone");
	    alerta.showAndWait();
	    return false;
	} else {
	    return true;
	}
    }

    private void formataCampo() {
	final var incompleto = "#F5757E";
	final var errado = "#F24B4B";
	final var NUMERO = "[0-9]*";
	this.controlador.btnCadastrar.setDisable(true);

	this.controlador.txtCpfCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 11 && change.getControlNewText().matches(NUMERO)) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("CPF menor que 11 numeros");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() == 11) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Valores numericos apenas");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 11 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO

		return null;
	    }
	}));

	this.controlador.txtCepCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 14 && change.getControlNewText().matches(NUMERO)) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("CEP menor que 14 numeros");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() == 14) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Valores numericos apenas");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtEndNumCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 20 && change.getControlNewText().matches(NUMERO)) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("Pelo menos um numero de endereco");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 1) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Valores numericos apenas");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtNomeCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("O nome é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 10) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Nome maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtRuaCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("A rua é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 6) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Rua maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtBairroCliente.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 30) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("O bairro é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 4) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Nome maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtCidade.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("A cidade é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 4) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Cidade maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

	this.controlador.txtEstado.setTextFormatter(new TextFormatter<String>(change -> {
	    // INSTANCIA O TOOLTIP, QUE É A DICA DO PORQUE ESTA ERRADO
	    final var too = new Tooltip();

	    // SE O TEXTO FOR MENOR OU IGUAL A 11 (E) TEXTO FOR NUMERO
	    if (change.getControlNewText().length() <= 60) {
		// MOSTRA A DICA POR 2 SEGUNDOS
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// TROCA A COR DO CAMPO PARA O INCOMPLETO
		change.getControl().setStyle("-fx-control-inner-background: " + incompleto);

		// AVISA PELA DICA QUE ESTA COM MENOS QUE 11 NUMEROS
		too.setText("O estado é obrigatorio");
		// DESATIVA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO TIVER EXATAMENTE 11 CARACTERES O FUNDO FICA BRANCO E LIBERA O
		// BOTAO DE CADASTRO
		if (change.getControlNewText().length() >= 4) {
		    this.controlador.btnCadastrar.setDisable(false);
		    change.getControl().setStyle("-fx-control-inner-background: white");
		}
		// RETORNA O TEXTO COM ESSAS CARACTERISTICAS
		return change;
	    } // CASO A PESSOA DIGITAR LETRA CAI NESTE ELSE
	    else {
		// AVISA CASO TENTAR COLOCAR LETRA EM VEZ DE NUMEROS
		too.setText("Estado maior que 60 caracteres");
		// DURACAO DA DICA
		too.setShowDuration(Duration.seconds(2));
		change.getControl().setTooltip(too);
		// COLOCA O TEXTO COM A COR DE ERRADO
		change.getControl().setStyle("-fx-control-inner-background: " + errado);
		// DESABILITA O BOTAO DE CADASTRO
		this.controlador.btnCadastrar.setDisable(true);
		// SE O TEXTO FOR MENOS OU IGUAL A 14 ELE PODE DIGITAR LETRAS MAS FICARA COMO
		// ERRADO
		return null;
	    }
	}));

    }
}
