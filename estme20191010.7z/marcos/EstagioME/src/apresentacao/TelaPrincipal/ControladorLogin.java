package apresentacao.TelaPrincipal;

import java.io.IOException;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import negocio.NegLogin;
import objeto.Funcionario;
import utilidade.Alerta;

public class ControladorLogin extends Application {

    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField txtSenha;
    private static Stage stage;
    @FXML
    private Button btnLogin;

    @FXML
    private Button btnCancelar;

    @FXML
   private void CancelarLogin(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
  private  void RealizarLogin(final ActionEvent event) {
	final var negLogin = new NegLogin();
	final var func = new Funcionario();
	func.setNome(txtUsuario.getText());
	func.setChaveAcesso(txtSenha.getText());

	try {
	    if (negLogin.consultar(func)) {
		stage.close();
		abreTelaMenu();
	    } else {
		Alerta.alertaCampoNulo().show();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

  private void abreTelaMenu() {
	try {
	    final var root = (AnchorPane) FXMLLoader
		    .load(getClass().getClassLoader().getResource("apresentacao/TelaPrincipal/TelaPrincipal.fxml"));

	    final var scene = new Scene(root);
	    // new JMetro(scene, Main.style).setAutomaticallyColorPanes(true);
	    
	    stage.setTitle("Menu Principal");
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}

    }

    @Override
    public void start(final Stage primaryStage) throws Exception {

	stage = primaryStage;
	abreTelaLogin();
    }

    private void abreTelaLogin() {

	try {
	    final var root = (AnchorPane) FXMLLoader
		    .load(getClass().getClassLoader().getResource("apresentacao/TelaPrincipal/loginScreen.fxml"));

	    final var scene = new Scene(root);
	    // new JMetro(scene, Main.style).setAutomaticallyColorPanes(true);
	    stage.setResizable(false);
	    stage.setTitle("Login");
	    stage.setScene(scene);
	    stage.show();

	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}

    }
}
