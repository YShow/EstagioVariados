package apresentacao.TelaPrincipal;

import apresentacao.Caixa.ControladorConsultarCaixa;
import apresentacao.Cliente.ControladorConsultaCliente;
import apresentacao.Fornecedor.ControladorConsultarFornecedor;
import apresentacao.Funcionario.ControladorConsultarFuncionario;
import apresentacao.Mercadoria.ControladorConsultarMercadoria;
import apresentacao.Produto.ControladorConsultaProduto;
import apresentacao.Venda.ControladorConsultarVenda;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import utilidade.TIPO_TELA;

public class ControladorMenu {

    @FXML
    private Button btnVenda;

    @FXML
    private Button btnCaixa;

    @FXML
    private Button btnProduto;

    @FXML
    private Button btnMercadoria;

    @FXML
    private Button btnCliente;

    @FXML
    private Button btnFornecedor;

    @FXML
    private Button btnFuncionario;

    @FXML
    private Button btnRelatorios;

    @FXML
    void Caixa(final ActionEvent event) {
	final var telaCaixa = new ControladorConsultarCaixa();
	telaCaixa.abreTelaConsultarCaixa();
    }

    @FXML
    void Cliente(final ActionEvent event) {
	final var telaCliente = new ControladorConsultaCliente();
	telaCliente.abrirTelaCliente(TIPO_TELA.INSERE);
    }

    @FXML
    void Fornecedor(final ActionEvent event) {
	final var telaFornecedor = new ControladorConsultarFornecedor();
	telaFornecedor.abreTelaConsultaFornecedor();
    }

    @FXML
    void Funcionario(final ActionEvent event) {
	final var telaFuncionario = new ControladorConsultarFuncionario();
	telaFuncionario.abreTelaConsultaFuncionario();
    }

    @FXML
    void Mercadoria(final ActionEvent event) {
	final var telaMercadoria = new ControladorConsultarMercadoria();
	telaMercadoria.abreTelaConsultaMercadoria();
    }

    @FXML
    void Produto(final ActionEvent event) {
	final var telaProduto = new ControladorConsultaProduto();
	telaProduto.abreTelaConsultaProduto();
    }

    @FXML
    void Venda(final ActionEvent event) {
	final var telaVenda = new ControladorConsultarVenda();
	telaVenda.abreTelaConsultaVenda();

    }

    @FXML
    void Relatorios(final ActionEvent event) {

    }

}
