package apresentacao.Caixa;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import utilidade.Alerta;

public class ControladorConsultarCaixa {

    @FXML
    private TextField txtCliente;

    @FXML
    private Button btnConsultarCaixa;

    @FXML
    private Button btnInativarCaixa;

    @FXML
    private Button btnAlterarCaixa;

    @FXML
    private Button btnCadastrarCaixa;
    @FXML
    private TableView<?> tblCaixa;

    public void abreTelaConsultarCaixa() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Caixa/ConsultarCaixa.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

   

    @FXML
    void AlterarCaixa(final ActionEvent event) {
	final var alterarCaixa = new ControladorAlterarCaixa();
	alterarCaixa.abreTelaAlteraCaixa();
    }

    @FXML
    void CadastrarCaixa(final ActionEvent event) {
	final var cadastraCaixa = new ControladorCadastrarCaixa();
	cadastraCaixa.abreTelaCadastrarCaixa();
    }

    @FXML
    void ConsultarClaixa(final ActionEvent event) {

    }

    @FXML
    void InativarCaixa(final ActionEvent event) {

    }
}
