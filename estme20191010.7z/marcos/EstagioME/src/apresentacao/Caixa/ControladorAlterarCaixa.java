package apresentacao.Caixa;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import utilidade.Alerta;

public class ControladorAlterarCaixa {
    @FXML
    private TextField txtDataVenda;

    @FXML
    private TextField txtValorTotal;

    @FXML
    private TextField txtFuncionario;

    @FXML
    private Button btnBuscarFuncionario;

    @FXML
    private Button btnConcluir;

    @FXML
    private Button btnCancelar;

    @FXML
    private CheckBox chkAtivo;

    public void abreTelaAlteraCaixa() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Caixa/AlterarCaixa.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
    void BuscarFuncionario(final ActionEvent event) {

    }

    @FXML
    void CancelarAlteracao(final ActionEvent event) {

    }

    @FXML
    void ConcluirAlterar(final ActionEvent event) {

    }

}
