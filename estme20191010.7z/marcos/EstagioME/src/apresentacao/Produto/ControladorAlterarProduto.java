package apresentacao.Produto;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegProduto;
import objeto.Produto;
import utilidade.Alerta;

public class ControladorAlterarProduto {
    @FXML
    private TextField txtNomeProduto;

    @FXML
    private Button btnAlterarProduto;

    @FXML
    private TextField txtQuantidadeProduto;

    @FXML
    private TextField txtPrecoCusto;

    @FXML
    private TextField txtPrecoCasco;

    @FXML
    private TextField txtPrecoVenda;

    @FXML
    private Button btnCancelarAlteracao;

    @FXML
    private CheckBox chkAtivo;
    @FXML
    private Label lblCodigo;


    public  void abreTelaConsultaProduto(Produto produto) {

   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);

   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Produto/AlterarProduto.fxml"));
   	    root = loader.load();
   	    ControladorAlterarProduto control = loader.getController();
   	    
   	   control.lblCodigo.setText(String.valueOf(produto.getCodProduto()));
   	   control.txtNomeProduto.setText(produto.getNomeProduto());
   	   control.txtPrecoCasco.setText(String.valueOf(produto.getPrecoCasco()));
   	   control.txtPrecoCusto.setText(String.valueOf(produto.getPrecoCusto()));
   	   control.txtPrecoVenda.setText(String.valueOf(produto.getPrecoVenda()));
   	   control.txtQuantidadeProduto.setText(String.valueOf(produto.getQuantidadeProduto()));
   	   control.chkAtivo.setSelected(produto.isStatus());
   	   
   	    final var scene = new Scene(root);

   	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage()).show();
   	}
       }
    
    @FXML
    void AlterarProduto(ActionEvent event) {
	var negprod = new NegProduto();
	
	
	
	try {
	    var produto  = new Produto();
	    produto.setCodProduto(Integer.parseInt(lblCodigo.getText().trim()));
	    produto.setNomeProduto(txtNomeProduto.getText().trim());
	    produto.setPrecoCasco(BigDecimal.valueOf(Double.parseDouble(txtPrecoCasco.getText().trim())));
	    produto.setPrecoCusto(BigDecimal.valueOf(Double.parseDouble(txtPrecoCusto.getText().trim())));
	    produto.setPrecoVenda(BigDecimal.valueOf(Double.parseDouble(txtPrecoVenda.getText().trim())));
	    produto.setQuantidadeProduto(Integer.parseInt(txtQuantidadeProduto.getText().trim()));
	    produto.setStatus(chkAtivo.isSelected());
	    
	    if(negprod.alterar(produto)) {
		Alerta.alertaSucesso().show();
	    }
		    
	} catch (SQLException e) {
	   Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void CalcelarAlteracao(ActionEvent event) {
	btnCancelarAlteracao.getScene().getWindow().hide();
    }

}
