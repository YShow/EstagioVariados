package apresentacao.Produto;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegProduto;
import objeto.Produto;
import utilidade.Alerta;

public class ControladorCadastrarProduto {
    @FXML
    private TextField txtNome;

    @FXML
    private Button btnConcluir;

    @FXML
    private TextField txtQuantidade;

    @FXML
    private TextField txtPrecoCusto;

    @FXML
    private TextField txtPrecoCasco;
    @FXML
    private CheckBox chkAtivo;


    @FXML
    private TextField txtPrecoVenda;

    @FXML
    private Button btnCancelar;

    public  void abreTelaCadastrarProduto() {

   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);

   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Produto/CadastrarProduto.fxml"));
   	    root = loader.load();

   	    final var scene = new Scene(root);
   	    
   	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage()).show();
   	}
       }
    
    @FXML
    void CancelarCadastro(ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void ConcluirCadastro(ActionEvent event) {
	var negProduto = new NegProduto();
	var produto = new Produto();
	
	
	produto.setNomeProduto(txtNome.getText().trim());
	produto.setPrecoCasco(BigDecimal.valueOf(Double.parseDouble(txtPrecoCasco.getText().trim())));
	produto.setPrecoCusto(BigDecimal.valueOf(Double.valueOf(txtPrecoCusto.getText().trim())));
	produto.setPrecoVenda(BigDecimal.valueOf(Double.valueOf(txtPrecoVenda.getText().trim())));
	produto.setQuantidadeProduto(Integer.parseInt(txtQuantidade.getText().trim()));
	produto.setStatus(chkAtivo.isSelected());
	
	try {
	    if(negProduto.inserir(produto))
	    {
		Alerta.alertaSucesso().show();
	    }
	} catch (SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
