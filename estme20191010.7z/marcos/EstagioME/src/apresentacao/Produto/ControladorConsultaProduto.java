package apresentacao.Produto;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegProduto;
import objeto.Produto;
import utilidade.Alerta;

public class ControladorConsultaProduto {
    @FXML
    private TextField txtProduto;

    @FXML
    private Button btnConsultar;

    @FXML
    private Button btnDesativaProduto;

    @FXML
    private Button btnAlteraProduto;

    @FXML
    private Button btnCadastrarProduto;

    @FXML
    private TableView<Produto> tblProduto;

    @FXML
    private TableColumn<Produto, Integer> tcCod;

    @FXML
    private TableColumn<Produto, String> tcNome;

    @FXML
    private TableColumn<Produto, Integer> tcQtd;

    @FXML
    private TableColumn<Produto, BigDecimal> tcPrecCusto;

    @FXML
    private TableColumn<Produto, BigDecimal> tcPrecVenda;

    @FXML
    private TableColumn<Produto, BigDecimal> tcPrecCasco;

    
  public  void abreTelaConsultaProduto() {

   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);

   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Produto/ConsultarProduto.fxml"));
   	    root = loader.load();

   	    final var scene = new Scene(root);

   	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage()).show();
   	}
       }

  public Produto abreTelaConsultaProdutoSelecionar() {

 	final var stage = new Stage();
 	Parent root;
 	final var loader = new FXMLLoader();
 	stage.initModality(Modality.APPLICATION_MODAL);

 	try {
 	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Produto/ConsultarProduto.fxml"));
 	    root = loader.load();
 	    ControladorConsultaProduto control = loader.getController();
 	    
 	    control.btnAlteraProduto.setDisable(true);
 	    control.btnCadastrarProduto.setDisable(true);
 	    control.btnDesativaProduto.setOnAction(e -> {
 		control.btnDesativaProduto.getScene().getWindow().hide();
 	    });
 	    final var scene = new Scene(root);

 	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
 	    stage.setScene(scene);
 	    stage.showAndWait();
 	    return control.pegaProduto();
 	    
 	} catch (final IOException e) {
 	    Alerta.alertaErro(e.getMessage()).show();
 	}
 	return null;
     }
  
  private Produto pegaProduto() {
          return tblProduto.getSelectionModel().getSelectedItem();
  }
  
    @FXML
    void CadastrarProduto(final ActionEvent event) {
	var cadastra = new ControladorCadastrarProduto();
	cadastra.abreTelaCadastrarProduto();
    }

    @FXML
    void ConsultaProduto(final ActionEvent event) {
	var negProd = new NegProduto();
	try {
	var produtos = negProd.consultar(txtProduto.getText().trim());
	
	var data = FXCollections.observableArrayList(produtos);
	tblProduto.setItems(data);
	tcCod.setCellValueFactory(new PropertyValueFactory<Produto,Integer>("codProduto"));
	tcNome.setCellValueFactory(new PropertyValueFactory<Produto,String>("nomeProduto"));
	tcPrecCusto.setCellValueFactory(new PropertyValueFactory<Produto,BigDecimal>("precoCusto"));
	tcPrecVenda.setCellValueFactory(new PropertyValueFactory<Produto,BigDecimal>("precoVenda"));
	tcPrecCasco.setCellValueFactory(new PropertyValueFactory<Produto,BigDecimal>("precoCasco"));
	tcQtd.setCellValueFactory(new PropertyValueFactory<Produto,Integer>("quantidadeProduto"));
	
	
	}catch (SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
	
    }

    @FXML
    void btnAlteraProduto(final ActionEvent event) {
	var altera = new ControladorAlterarProduto();
	
	altera.abreTelaConsultaProduto(tblProduto.getSelectionModel().getSelectedItem());
    }

    @FXML
    void btnDesativaProduto(final ActionEvent event) {
	var produto = tblProduto.getSelectionModel().getSelectedItem();
	
	try {
	    var negprod = new NegProduto();
	    if(negprod.excluir(produto.getCodProduto()))
	    {
		Alerta.alertaSucesso().show();
		tblProduto.getItems().remove(produto);
	    }
	    
	    
	} catch (SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

}
