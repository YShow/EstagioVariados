package apresentacao.Funcionario;

import java.io.IOException;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFuncionario;
import objeto.Funcionario;
import utilidade.Alerta;

public class ControladorConsultarFuncionario {

    @FXML
    private TextField txtfuncionario;

    @FXML
    private Button btnConsultarFuncionario;

    @FXML
    private Button btnDesativaFuncionario;

    @FXML
    private Button btnAlteraFuncionario;

    @FXML
    private Button btnCadastrar;

    @FXML
    private TableView<Funcionario> tblFuncionario;

    @FXML
    private TableColumn<Funcionario, Integer> tcCodigo;

    @FXML
    private TableColumn<Funcionario, String> tcNome;

    @FXML
    private TableColumn<Funcionario, String> tcUsuario;

    @FXML
    private TableColumn<Funcionario, String> tcFuncao;

    @FXML
    private TableColumn<Funcionario, Boolean> tcAdm;

    @FXML
    private TableColumn<Funcionario, Boolean> tcStatus;

    public void abreTelaConsultaFuncionario() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Funcionario/ConsultarFuncionario.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
   private void AlteraFuncionario(final ActionEvent event) {
	final var funcionario = tblFuncionario.getSelectionModel().getSelectedItem();
	final var alteraFuncionario = new ControladorAlterarFuncionario();
	alteraFuncionario.abreTelaAlterarFuncionario(funcionario);
    }

    @FXML
   private void CadastrarFuncionario(final ActionEvent event) {
	final var cadastraFuncionario = new ControladorCadastrarFuncionario();
	cadastraFuncionario.abreTelaCadastrarFuncionario();
    }

    @FXML
   private void ConsultarFuncionario(final ActionEvent event) {
	final var negfun = new NegFuncionario();
	try {
	    final var funcionarios = negfun.consultar(txtfuncionario.getText());

	    tcAdm.setCellValueFactory(new PropertyValueFactory<Funcionario, Boolean>("AcessoAdmin"));
	    tcCodigo.setCellValueFactory(new PropertyValueFactory<Funcionario, Integer>("CodigoFuncionario"));
	    tcFuncao.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("Funcao"));
	    tcNome.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("Nome"));
	    tcStatus.setCellValueFactory(new PropertyValueFactory<Funcionario, Boolean>("Status"));
	    tcUsuario.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("NomeUsuario"));

	    final var data = FXCollections.observableList(funcionarios);
	    tblFuncionario.setItems(data);

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();

	}
    }

    @FXML
   private void DesativaFuncionario(final ActionEvent event) {
	final var funcionario = tblFuncionario.getSelectionModel().getSelectedItem();
	final var negFuncionario = new NegFuncionario();
	try {
	    if (negFuncionario.desativar(funcionario.getCodigoFuncionario())) {
		Alerta.alertaSucesso().show();
		tblFuncionario.getItems().remove(funcionario);
	    }

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }
}
