package apresentacao.Funcionario;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFuncionario;
import objeto.Funcionario;
import utilidade.Alerta;
import utilidade.EFuncoesFuncionario;

public class ControladorAlterarFuncionario {

    @FXML
    private Button btnConcluirAlteracao;

    @FXML
    private Button btnCancelarAlteraracao;

    @FXML
    private TextField txtnomeFuncionario;

    @FXML
    private TextField txtusuarioFuncionario;

    @FXML
    private CheckBox checkBoxAdm;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private TextField txtCodFuncionario;

    @FXML
    private PasswordField txtsenhaFuncionario;

    @FXML
    private ComboBox<EFuncoesFuncionario> cbFuncao;

    @FXML
    private PasswordField txtSenhaFuncionarioConfirma;

  protected  void abreTelaAlterarFuncionario(final Funcionario funcionario) {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Funcionario/AlterarFuncionario.fxml"));
	    root = loader.load();
	    final var controler = (ControladorAlterarFuncionario) loader.getController();
	    controler.cbFuncao.getItems().setAll(EFuncoesFuncionario.values());
	    controler.txtCodFuncionario.setText(String.valueOf(funcionario.getCodigoFuncionario()));
	    controler.cbFuncao.setValue(funcionario.getFuncao());
	    controler.txtnomeFuncionario.setText(funcionario.getNome());
	    controler.txtusuarioFuncionario.setText(funcionario.getNomeUsuario());
	    controler.checkBoxAdm.setSelected(funcionario.isAcessoAdmin());
	    controler.chkAtivo.setSelected(funcionario.isStatus());

	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
  private   void CancelarAlteracao(final ActionEvent event) {
	btnCancelarAlteraracao.getScene().getWindow().hide();
    }

    @FXML
  private  void ConcluirAlteracao(final ActionEvent event) {
	final var func = new Funcionario();
	func.setAcessoAdmin(checkBoxAdm.isSelected());
	func.setChaveAcesso(txtsenhaFuncionario.getText());
	func.setFuncao(cbFuncao.getValue());
	func.setNome(txtnomeFuncionario.getText());
	func.setNomeUsuario(txtusuarioFuncionario.getText());
	func.setStatus(chkAtivo.isSelected());
	func.setCodigoFuncionario(Integer.parseInt(txtCodFuncionario.getText()));

	final var negfun = new NegFuncionario();
	try {
	  if(txtsenhaFuncionario.getText().trim().contentEquals(txtSenhaFuncionarioConfirma.getText().trim()))
	  {
	    if (negfun.alterar(func)) {
		Alerta.alertaSucesso().show();
	    }
	  }else
	  {
	      Alerta.alertaSenhaNaoBate().show();
	  }
	  
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }
}
