package apresentacao.Funcionario;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFuncionario;
import objeto.Funcionario;
import utilidade.Alerta;
import utilidade.EFuncoesFuncionario;

public class ControladorCadastrarFuncionario {

    @FXML
    private Button btnConcluirCadFuncionario;

    @FXML
    private Button btnCancelarCadFuncionario;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtUsuario;

    @FXML
    private CheckBox acessoAdministrador;

    @FXML
    private PasswordField txtSenha;

    @FXML
    private ComboBox<EFuncoesFuncionario> cbFuncao;

    @FXML
    private PasswordField txtSenhaConfirma;


   protected void abreTelaCadastrarFuncionario() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Funcionario/CadastrarFuncionario.fxml"));
	    root = loader.load();
	    ControladorCadastrarFuncionario control = loader.getController();
	    control.cbFuncao.getItems().setAll(EFuncoesFuncionario.values());
	    
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
   private void CancelarCadFuncionario(final ActionEvent event) {

    }

    @FXML
   private void ConcluirCadFuncionario(final ActionEvent event) {
	final var funcionario = new Funcionario();
	funcionario.setAcessoAdmin(acessoAdministrador.isSelected());
	funcionario.setChaveAcesso(txtSenha.getText());
	funcionario.setFuncao(cbFuncao.getValue());
	funcionario.setNome(txtNome.getText());
	funcionario.setNomeUsuario(txtUsuario.getText());
	funcionario.setStatus(true);

	final var negfunc = new NegFuncionario();
	try {
	    if(txtSenha.getText().trim().contentEquals(txtSenhaConfirma.getText().trim()))
	    {
		if (negfunc.inserir(funcionario)) {
		    Alerta.alertaSucesso().show();
		}
	    }else
	    {
		Alerta.alertaSenhaNaoBate().show();
	    }

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}
    }
}
