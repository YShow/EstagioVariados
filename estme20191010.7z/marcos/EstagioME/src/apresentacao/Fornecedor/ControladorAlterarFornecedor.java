package apresentacao.Fornecedor;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFornecedor;
import objeto.Fornecedor;
import objeto.Telefone;
import utilidade.Alerta;
import utilidade.ETelefone;

public class ControladorAlterarFornecedor {

    @FXML
    private Button btnRemoverNum;

    @FXML
    private TextField txtNomeFornecedor;

    @FXML
    private TextField txtCidade;

    @FXML
    private TextField txtProdutoFornecido;

    @FXML
    private TextField txtNumeroTel;

    @FXML
    private TextField txtDDD;

    @FXML
    private TextField txtTipoTel;

    @FXML
    private TextField txtTelEstado;

    @FXML
    private Button btnAddNumLista;

    @FXML
    private TableView<Telefone> tblTelefone;

    @FXML
    private TableColumn<Telefone, Integer> tcDDD;

    @FXML
    private TableColumn<Telefone, Integer> tcNumero;

    @FXML
    private TableColumn<Telefone, ETelefone> tcTipo;

    @FXML
    private Button btnConcluir;

    @FXML
    private Button btnCancelar;

    @FXML
    private ChoiceBox<ETelefone> cbTipoTel;

    @FXML
    private CheckBox chkAtivo;
    @FXML
    private Label lblCodigoFornecedor;

    public void abreTelaAlteraFornecedor(final Fornecedor fornecedor) {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Fornecedor/AlterarFornecedor.fxml"));
	    root = loader.load();
	    final var controler = (ControladorAlterarFornecedor) loader.getController();
	    controler.txtNomeFornecedor.setText(fornecedor.getNome());
	    controler.txtProdutoFornecido.setText(fornecedor.getProduto());
	    controler.txtCidade.setText(fornecedor.getNomeCidade());
	    controler.cbTipoTel.getItems().setAll(ETelefone.values());
	    controler.lblCodigoFornecedor.setText(String.valueOf(fornecedor.getCodFornecedor()));
	    controler.chkAtivo.setSelected(fornecedor.isStatus());
	    pegaTelefone(fornecedor.getCodFornecedor(), controler);

	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    void pegaTelefone(final int id, final ControladorAlterarFornecedor controlador) {
	final var negFornecedor = new NegFornecedor();
	try {
	    final var telefones = negFornecedor.pegaTelefonesFornecedor(id);

	    controlador.tcDDD.setCellValueFactory(new PropertyValueFactory<Telefone, Integer>("Ddd"));

	    controlador.tcNumero.setCellValueFactory(new PropertyValueFactory<Telefone, Integer>("NumTelefone"));
	    controlador.tcTipo.setCellValueFactory(new PropertyValueFactory<Telefone, ETelefone>("Tipo"));
	    final var data = FXCollections.observableList(telefones);
	    controlador.tblTelefone.setItems(data);

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }

    @FXML
    void AddNumLista(final ActionEvent event) {
	final var telefone = new Telefone();
	telefone.setNumTelefone(Integer.valueOf(txtNumeroTel.getText()));
	telefone.setDdd(Integer.valueOf(txtDDD.getText()));
	telefone.setStatus(true);
	telefone.setTipo(cbTipoTel.getValue());

	tcDDD.setCellValueFactory(ddd -> new ReadOnlyIntegerWrapper(ddd.getValue().getDdd()).asObject());
	tcNumero.setCellValueFactory(
		numero -> new ReadOnlyIntegerWrapper(numero.getValue().getNumTelefone()).asObject());
	tcTipo.setCellValueFactory(new PropertyValueFactory<Telefone,ETelefone>("Tipo"));

	tblTelefone.getItems().add(telefone);
    }

    @FXML
    void btnRemoverNum(final ActionEvent event) {
	final var telefone = tblTelefone.getSelectionModel().getSelectedItem();
	tblTelefone.getItems().remove(telefone);
    }

    @FXML
    void CancelarCadastro(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void ConcluirCadastro(final ActionEvent event) {
	final var negFornecedor = new NegFornecedor();
	try {
	    if (negFornecedor.Alerar(pegaFornecedor(), pegaTelefones())) {
		Alerta.alertaSucesso().show();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }
    
    private List<Telefone> pegaTelefones(){
	final var telefones = new ArrayList<Telefone>();
	for (final var telefone : tblTelefone.getItems()) {
	    telefones.add(telefone);
	}
	return telefones;
    }
    private Fornecedor pegaFornecedor() {
	final var fornecedor = new Fornecedor();
	fornecedor.setNome(txtNomeFornecedor.getText());
	fornecedor.setNomeCidade(txtCidade.getText());
	fornecedor.setProduto(txtProdutoFornecido.getText());
	fornecedor.setStatus(chkAtivo.isSelected());
	fornecedor.setCodFornecedor(Integer.parseInt(lblCodigoFornecedor.getText()));
	return fornecedor;
    }
}
