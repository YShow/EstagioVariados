package apresentacao.Fornecedor;

import java.io.IOException;
import java.sql.SQLException;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFornecedor;
import objeto.Fornecedor;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorConsultarFornecedor {

    @FXML
    private TextField txtFornecedor;

    @FXML
    private Button btnConsultaFornecedor;

    @FXML
    private Button btnInativarFornecedor;

    @FXML
    private Button btnAlterarFornecedor;

    @FXML
    private Button btnCadastraFornecedor;

    @FXML
    private TableView<Fornecedor> tblFornecedor;

    @FXML
    private TableColumn<Fornecedor, Integer> tcCodigo;

    @FXML
    private TableColumn<Fornecedor, String> tcNome;

    @FXML
    private TableColumn<Fornecedor, String> tcCidade;

    @FXML
    private TableColumn<Fornecedor, String> tcProduto;
    @FXML
    private TableColumn<Fornecedor, Boolean> tcAtivo;

    private static Fornecedor fornecedor;
    private static TIPO_TELA tipo_tela;

    public void abreTelaConsultaFornecedor() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Fornecedor/ConsultarFornecedor.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    public Fornecedor abreTelaConsultaFornecedorPegaValor() {
	tipo_tela = TIPO_TELA.CONSULTA;
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Fornecedor/ConsultarFornecedor.fxml"));
	    root = loader.load();
	    final var controler = (ControladorConsultarFornecedor) loader.getController();
	    controler.btnAlterarFornecedor.setDisable(true);
	    controler.btnCadastraFornecedor.setDisable(true);
	    controler.btnInativarFornecedor.setText("Selecionar");
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.showAndWait();
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
	return fornecedor;
    }

    @FXML
    void AlterarFornecedor(final ActionEvent event) {
	final var fornecedor = tblFornecedor.getSelectionModel().getSelectedItem();
	final var alteraFornecedor = new ControladorAlterarFornecedor();
	alteraFornecedor.abreTelaAlteraFornecedor(fornecedor);
    }

    @FXML
    void CadastrarForencedor(final ActionEvent event) {
	final var cadastraFornecedor = new ControladorCadastrarFornecedor();
	cadastraFornecedor.abreTelaCadastrarFornecedor();
    }

    @FXML
    void ConsultaFornecedor(final ActionEvent event) {
	final var negFornecedor = new NegFornecedor();
	try {

	    final var fornecedores = negFornecedor.Consultar(txtFornecedor.getText());
	    final var data = FXCollections.observableList(fornecedores);
	    tblFornecedor.setItems(data);
	    tcCidade.setCellValueFactory(cidade -> new ReadOnlyStringWrapper(cidade.getValue().getNomeCidade()));
	    tcCodigo.setCellValueFactory(
		    codigo -> new ReadOnlyIntegerWrapper(codigo.getValue().getCodFornecedor()).asObject());
	    tcNome.setCellValueFactory(nome -> new ReadOnlyStringWrapper(nome.getValue().getNome()));
	    tcProduto.setCellValueFactory(produto -> new ReadOnlyStringWrapper(produto.getValue().getProduto()));
	    tcAtivo.setCellValueFactory(new PropertyValueFactory<Fornecedor,Boolean>("status"));
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }

    @FXML
    void InativarFornecedor(final ActionEvent event) {
	if (tipo_tela.equals(TIPO_TELA.CONSULTA)) {
	    fornecedor = tblFornecedor.getSelectionModel().getSelectedItem();

	    btnInativarFornecedor.getScene().getWindow().hide();
	} else {
	    final var negFornecedor = new NegFornecedor();
	    final var idFornecedor = tblFornecedor.getSelectionModel().getSelectedItem();
	    try {
		if (negFornecedor.remover(idFornecedor.getCodFornecedor())) {
		    Alerta.alertaSucesso();
		    tblFornecedor.getItems().remove(idFornecedor);
		}
	    } catch (final SQLException e) {
		Alerta.alertaErro(e.getMessage());
	    }
	}
    }
}
