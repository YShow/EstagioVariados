package apresentacao.Fornecedor;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFornecedor;
import objeto.Fornecedor;
import objeto.Telefone;
import utilidade.Alerta;
import utilidade.ETelefone;

public class ControladorCadastrarFornecedor {

    @FXML
    private TextField txtNomeFornecedor;

    @FXML
    private TextField txtCidade;

    @FXML
    private TextField txtProdutoFornecido;

    @FXML
    private TextField txtNumeroTel;

    @FXML
    private TextField txtDDD;

   

    @FXML
    private TextField txtTelEstado;

    @FXML
    private Button btnAddNumLista;

    @FXML
    private TableView<Telefone> tblTelefoneFornecedor;

    @FXML
    private TableColumn<Telefone, Integer> tcDDD;

    @FXML
    private TableColumn<Telefone, Integer> tcNumero;

    @FXML
    private TableColumn<Telefone, ETelefone> tcTipo;

    @FXML
    private ChoiceBox<ETelefone> cbTipoTel;

    @FXML
    private Button btnConcluir;

    @FXML
    private Button btnCancelar;

    public void abreTelaCadastrarFornecedor() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(
		    getClass().getClassLoader().getResource("apresentacao/Fornecedor/CadastrarFornecedor.fxml"));
	    root = loader.load();
	    var controlador = (ControladorCadastrarFornecedor) loader.getController();
	    controlador.cbTipoTel.getItems().setAll(ETelefone.values());
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void AddNumLista(final ActionEvent event) {
	final var telefone = new Telefone();
	telefone.setNumTelefone(Integer.valueOf(txtNumeroTel.getText()));
	telefone.setDdd(Integer.valueOf(txtDDD.getText()));
	telefone.setStatus(true);
	telefone.setTipo(cbTipoTel.getValue());

	tcDDD.setCellValueFactory(ddd -> new ReadOnlyIntegerWrapper(ddd.getValue().getDdd()).asObject());
	tcNumero.setCellValueFactory(
		numero -> new ReadOnlyIntegerWrapper(numero.getValue().getNumTelefone()).asObject());
	tcTipo.setCellValueFactory(new PropertyValueFactory<Telefone,ETelefone>("Tipo"));

	tblTelefoneFornecedor.getItems().add(telefone);

    }

    @FXML
    void CancelarCadastro(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void ConcluirCadastro(final ActionEvent event) {
	final var negFornecedor = new NegFornecedor();
	final var telefones = new ArrayList<Telefone>();
	for (final var telefone : tblTelefoneFornecedor.getItems()) {
	    telefones.add(telefone);
	}
	final var fornecedor = new Fornecedor();
	fornecedor.setNome(txtNomeFornecedor.getText());
	fornecedor.setNomeCidade(txtCidade.getText());
	fornecedor.setProduto(txtProdutoFornecido.getText());
	fornecedor.setStatus(true);

	try {
	    if (negFornecedor.Inserir(fornecedor, telefones)) {
		Alerta.alertaSucesso().show();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage()).show();
	}

    }
}
