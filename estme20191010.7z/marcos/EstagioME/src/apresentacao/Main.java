package apresentacao;

import apresentacao.TelaPrincipal.ControladorLogin;
import javafx.application.Application;
import javafx.stage.Stage;
import utilidade.Alerta;

public class Main extends Application {

    @Override
    public void start(final Stage primaryStage) {
	// isto é um teste para como esconder uma tela e abrir outra sem fexar o
	// programa
	// Platform.setImplicitExit(false);
	try {
	    final var login = new ControladorLogin();
	    login.start(primaryStage);

	} catch (final Exception e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    public static void main(final String[] args) {
	launch(args);
    }
}
