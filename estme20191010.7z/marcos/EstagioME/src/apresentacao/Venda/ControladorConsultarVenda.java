package apresentacao.Venda;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegVenda;
import objeto.Venda;
import utilidade.Alerta;

public class ControladorConsultarVenda {
    @FXML
    private TextField txtVenda;

    @FXML
    private Button btnConsultar;

    @FXML
    private Button btnDesativaVenda;

    @FXML
    private Button btnAlteraVenda;

    @FXML
    private Button btnCadastrarVenda;

    @FXML
    private TableView<Venda> tblVenda;

    @FXML
    private TableColumn<Venda, Integer> tcCod;

    @FXML
    private TableColumn<Venda, String> tcProd;

    @FXML
    private TableColumn<Venda, String> tcCliente;

    @FXML
    private TableColumn<Venda, String> tcFunc;

    @FXML
    private TableColumn<Venda, BigDecimal> tcValor;

    public void abreTelaConsultaVenda() {

	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Venda/ConsultarVenda.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void AlteraVenda(final ActionEvent event) {

    }

    @FXML
    void CadastrarVenda(final ActionEvent event) {
	var venda = new ControladorCadastrarVenda();
	venda.abreTelaCadastraVenda();
    }

    @FXML
    void ConsultaVenda(final ActionEvent event) {
	try {
	var negVenda = new NegVenda();
	var vendas = negVenda.consultar(txtVenda.getText().trim());
	
	tblVenda.setItems(FXCollections.observableArrayList(vendas));
	
	tcCliente.setCellValueFactory(cliente -> new ReadOnlyStringWrapper(cliente.getValue().getCliente().getNome()));
	tcCod.setCellValueFactory(new PropertyValueFactory<Venda,Integer>("codVenda"));
	tcFunc.setCellValueFactory(func -> new ReadOnlyStringWrapper(func.getValue().getFuncionario().getNome()));
	tcProd.setCellValueFactory(prod -> new ReadOnlyStringWrapper(prod.getValue().getProduto().getNomeProduto()));
	tcValor.setCellValueFactory(valor -> new ReadOnlyObjectWrapper<BigDecimal>(valor.getValue().getCaixa().getValorTotalVenda()));
	
	}catch (SQLException e) {
	  Alerta.alertaErro(e.getMessage()).show();
	}
    }

    @FXML
    void DesativaVenda(final ActionEvent event) {
	var negVenda = new NegVenda();
	var venda = tblVenda.getSelectionModel().getSelectedItem();
	try {
	    if(negVenda.excluir(venda.getCodVenda()))
	    {
	        Alerta.alertaSucesso();
	        tblVenda.getItems().remove(venda);
	    }
	} catch (SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

}
