package apresentacao.Venda;

import java.io.IOException;
import java.math.BigDecimal;

import apresentacao.Cliente.ControladorConsultaCliente;
import apresentacao.Produto.ControladorConsultaProduto;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import objeto.Funcionario;
import objeto.Produto;
import utilidade.Alerta;

public class ControladorCadastrarVenda {
    @FXML
    private TextField txtCodCliente;

  

    @FXML
    private TextField txtCodFuncionario;

    @FXML
    private TextField txtQuantidadeVendida;

    @FXML
    private Label txtNomeCliente;

    @FXML
    private Label txtNomeFuncionario;

    @FXML
    private TableView<Produto> tblProduto;

    @FXML
    private TableColumn<Produto, Integer> tcCod;

    @FXML
    private TableColumn<Produto, String> tcNomeProd;

    @FXML
    private TableColumn<Produto, BigDecimal> tcPrecoVenda;

    @FXML
    private TableColumn<Produto, Integer> tcQtd;

    @FXML
    private TextField txtValorTotal;

    @FXML
    private Button btnCadastroVenda;

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnRemover;

    @FXML
    private Button btnBuscarCodCliente;


    @FXML
    private Button btnAdicionarProd;    

    @FXML
    private Button btnBuscarCodFuncionario;
    @FXML
    private Button btnAddVenda;
    public  void abreTelaCadastraVenda() {

   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);

   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/Venda/CadastrarVenda.fxml"));
   	    root = loader.load();
   	    ControladorCadastrarVenda control = loader.getController();
   	    
   	    control.tcQtd.setEditable(true);
   	    control.tblProduto.setEditable(true);
   	    final var scene = new Scene(root);

   	    scene.getStylesheets().add(getClass().getResource("Caixa.css").toExternalForm());
   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage()).show();
   	}
       }
    
    private void atualizaValorTotal() {
	var total = new BigDecimal(2);
	for (var valores : tblProduto.getItems()) {
	    total = total.add(valores.getPrecoVenda());
	}
	txtValorTotal.setText(total.toString());	
    }
    
    @FXML
    void BuscarCodCliente(final ActionEvent event) {
	var telac = new ControladorConsultaCliente();
	var cli = telac.abrirTelaClienteSelecionar();
	txtCodCliente.setText(String.valueOf(cli.getCodCliente()));
	
    }

    @FXML
    void BuscarCodFuncionario(ActionEvent event) {
	txtCodFuncionario.setText(String.valueOf(Funcionario.getFuncionario().getIdFuncionario()));
    }

    @FXML
    void CancelarCadastroVenda(ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

   
    @FXML
    void ConcluirCadastroVenda(ActionEvent event) {

    }

    @FXML
    void RemoverProduto(ActionEvent event) {
	var prod = tblProduto.getSelectionModel().getSelectedItem();
	tblProduto.getItems().remove(prod);	
	atualizaValorTotal();
    }

    @FXML
    void addVenda(ActionEvent event) {

    }

    @FXML
    void btnAdicionarProd(ActionEvent event) {
	var prod = new ControladorConsultaProduto();
	var produto = prod.abreTelaConsultaProdutoSelecionar();
	
	tcCod.setCellValueFactory(new PropertyValueFactory<Produto,Integer>("codProduto"));
	tcNomeProd.setCellValueFactory(new PropertyValueFactory<Produto,String>("nomeProduto"));
	tcPrecoVenda.setCellValueFactory(new PropertyValueFactory<Produto,BigDecimal>("precoVenda"));
	tcQtd.setCellValueFactory(new PropertyValueFactory<Produto,Integer>("quantidadeProduto"));
	
	
	tblProduto.getItems().add(produto);
	atualizaValorTotal();
    }

}
