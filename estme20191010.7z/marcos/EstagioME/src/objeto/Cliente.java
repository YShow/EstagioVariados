package objeto;

import java.util.List;

public class Cliente {

    private boolean status;

    public boolean getStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    public int getCodCliente() {
	return codCliente;
    }

    public void setCodCliente(final int codCliente) {
	this.codCliente = codCliente;
    }

    public String getCpf() {
	return cpf;
    }

    public void setCpf(final String cpf) {
	this.cpf = cpf;
    }

    public Endereco getEndereco() {
	return endereco;
    }

    public void setEndereco(final Endereco endereco) {
	this.endereco = endereco;
    }

    public String getNome() {
	return nome;
    }

    public void setNome(final String nome) {
	this.nome = nome;
    }

    private int codCliente;
    private String cpf;
    private Endereco endereco;
    private String nome;

    public List<Telefone> getTelefone() {
	return telefone;
    }

    public void setTelefone(final List<Telefone> telefone) {
	this.telefone = telefone;
    }

    private List<Telefone> telefone;

}
