package objeto;

public class ItensEntrada {

    private int codigoEntrada;
    private int codigoProduto;
    private int quantidade;
    private String nomeProduto;
}
