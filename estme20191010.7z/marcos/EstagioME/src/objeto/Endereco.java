package objeto;

public class Endereco {

    private String bairro;

    public String getBairro() {
	return bairro;
    }

    public void setBairro(final String bairro) {
	this.bairro = bairro;
    }

    public int getCodEndereco() {
	return codEndereco;
    }

    public void setCodEndereco(final int codEndereco) {
	this.codEndereco = codEndereco;
    }

    public String getCep() {
	return cep;
    }

    public void setCep(final String cep) {
	this.cep = cep;
    }

    public String getRua() {
	return rua;
    }

    public void setRua(final String rua) {
	this.rua = rua;
    }

    public String getComplemento() {
	return complemento;
    }

    public void setComplemento(final String complemento) {
	this.complemento = complemento;
    }

    public boolean isStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    private int codEndereco;

    public int getNumeroRua() {
	return numeroRua;
    }

    public void setNumeroRua(final int numeroRua) {
	this.numeroRua = numeroRua;
    }

    public String getCidade() {
	return cidade;
    }

    public void setCidade(final String cidade) {
	this.cidade = cidade;
    }

    public String getEstado() {
	return estado;
    }

    public void setEstado(final String estado) {
	this.estado = estado;
    }

    private int numeroRua;
    private String cep;
    private String rua;
    private String complemento;
    private String cidade;
    private String estado;
    private boolean status;

}
