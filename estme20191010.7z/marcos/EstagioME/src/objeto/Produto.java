package objeto;

import java.math.BigDecimal;

public class Produto {

    private int codProduto;

    public int getCodProduto() {
	return codProduto;
    }

    public void setCodProduto(final int codProduto) {
	this.codProduto = codProduto;
    }

    public int getQuantidadeProduto() {
	return quantidadeProduto;
    }

    public void setQuantidadeProduto(final int quantidadeProduto) {
	this.quantidadeProduto = quantidadeProduto;
    }

    public BigDecimal getPrecoCusto() {
	return precoCusto;
    }

    public void setPrecoCusto(final BigDecimal precoCusto) {
	this.precoCusto = precoCusto;
    }

    public BigDecimal getPrecoCasco() {
	return precoCasco;
    }

    public void setPrecoCasco(final BigDecimal precoCasco) {
	this.precoCasco = precoCasco;
    }

    public BigDecimal getPrecoVenda() {
	return precoVenda;
    }

    public void setPrecoVenda(final BigDecimal precoVenda) {
	this.precoVenda = precoVenda;
    }

    public String getNomeProduto() {
	return nomeProduto;
    }

    public void setNomeProduto(final String nomeProduto) {
	this.nomeProduto = nomeProduto;
    }

    public boolean isStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    private int quantidadeProduto;
    private BigDecimal precoCusto;
    private BigDecimal precoCasco;
    private BigDecimal precoVenda;
    private String nomeProduto;
    private boolean status;
}
