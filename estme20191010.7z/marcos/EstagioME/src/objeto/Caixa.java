package objeto;

import java.math.BigDecimal;

public class Caixa {

    public String getDataVenda() {
	return dataVenda;
    }

    public void setDataVenda(final String dataVenda) {
	this.dataVenda = dataVenda;
    }

    public int getCodVenda() {
	return codVenda;
    }

    public void setCodVenda(final int codVenda) {
	this.codVenda = codVenda;
    }

    public BigDecimal getValorTotalVenda() {
	return valorTotalVenda;
    }

    public void setValorTotalVenda(final BigDecimal valorTotalVenda) {
	this.valorTotalVenda = valorTotalVenda;
    }

    public int getCodigoFuncionario() {
	return codigoFuncionario;
    }

    public void setCodigoFuncionario(final int codigoFuncionario) {
	this.codigoFuncionario = codigoFuncionario;
    }

    private String dataVenda;
    private int codVenda;
    private BigDecimal valorTotalVenda;
    private int codigoFuncionario;
    public final int getCodCaixa() {
        return codCaixa;
    }

    public final void setCodCaixa(int codCaixa) {
        this.codCaixa = codCaixa;
    }

    private int codCaixa;

}
