package objeto;

public class ItensVenda {
    private int quantidade;

    public int getQuantidade() {
	return quantidade;
    }

    public void setQuantidade(final int quantidade) {
	this.quantidade = quantidade;
    }

    public int getCodigoVenda() {
	return codigoVenda;
    }

    public void setCodigoVenda(final int codigoVenda) {
	this.codigoVenda = codigoVenda;
    }

    public int getCodigoProduto() {
	return codigoProduto;
    }

    public void setCodigoProduto(final int codigoProduto) {
	this.codigoProduto = codigoProduto;
    }

    private int codigoVenda;
    private int codigoProduto;

}
