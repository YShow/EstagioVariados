package objeto;

public class Recebe {

    private int codigoFuncionario;

    public int getCodigoFuncionario() {
	return codigoFuncionario;
    }

    public void setCodigoFuncionario(final int codigoFuncionario) {
	this.codigoFuncionario = codigoFuncionario;
    }

    public int getCodigoEntrada() {
	return codigoEntrada;
    }

    public void setCodigoEntrada(final int codigoEntrada) {
	this.codigoEntrada = codigoEntrada;
    }

    private int codigoEntrada;
}
