package objeto;

public class Fornecedor {

    public int getCodFornecedor() {
	return codFornecedor;
    }

    public void setCodFornecedor(final int codFornecedor) {
	this.codFornecedor = codFornecedor;
    }

    public String getNome() {
	return nome;
    }

    public void setNome(final String nome) {
	this.nome = nome;
    }

    public String getNomeCidade() {
	return nomeCidade;
    }

    public void setNomeCidade(final String nomeCidade) {
	this.nomeCidade = nomeCidade;
    }

    public int getTelefone() {
	return telefone;
    }

    public void setTelefone(final int telefone) {
	this.telefone = telefone;
    }

    public String getProduto() {
	return produto;
    }

    public void setProduto(final String produto) {
	this.produto = produto;
    }

    public boolean isStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    private int codFornecedor;
    private String nome;
    private String nomeCidade;
    private int telefone;
    private String produto;
    private boolean status;
}
