package objeto;

public class Venda {
    public boolean getStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    public int getCodVenda() {
	return codVenda;
    }

    public void setCodVenda(final int codVenda) {
	this.codVenda = codVenda;
    }

    public String getDataVenda() {
	return dataVenda;
    }

    public void setDataVenda(final String dataVenda) {
	this.dataVenda = dataVenda;
    }

    
    private boolean status;
    private int codVenda;
    private String dataVenda;
    
    public final Produto getProduto() {
        return produto;
    }

    public final void setProduto(Produto produto) {
        this.produto = produto;
    }

    public final Cliente getCliente() {
        return cliente;
    }

    public final void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public final Funcionario getFuncionario() {
        return funcionario;
    }

    public final void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }


    private Produto produto;
    private Cliente cliente;
    private Funcionario funcionario;
    
    public final Caixa getCaixa() {
        return caixa;
    }

    public final void setCaixa(Caixa caixa) {
        this.caixa = caixa;
    }


    private Caixa caixa;
}
