package objeto;

import utilidade.EFuncoesFuncionario;

public class Funcionario {

    private static int idFuncionario;

    public static int getIdFuncionario() {
	return idFuncionario;
    }

    public static void setIdFuncionario(final int idFuncionario) {
	Funcionario.idFuncionario = idFuncionario;
    }

    public String getNomeUsuario() {
	return nomeUsuario;
    }

    public void setNomeUsuario(final String nomeUsuario) {
	this.nomeUsuario = nomeUsuario;
    }

    public boolean isAcessoAdmin() {
	return acessoAdmin;
    }

    public void setAcessoAdmin(final boolean acessoAdmin) {
	this.acessoAdmin = acessoAdmin;
    }

    public String getChaveAcesso() {
	return chaveAcesso;
    }

    public void setChaveAcesso(final String chaveAcesso) {
	this.chaveAcesso = chaveAcesso;
    }

    public EFuncoesFuncionario getFuncao() {
	return funcao;
    }

    public void setFuncao(final EFuncoesFuncionario funcao) {
	this.funcao = funcao;
    }

    public String getNome() {
	return nome;
    }

    public void setNome(final String nome) {
	this.nome = nome;
    }

    public int getCodigoFuncionario() {
	return codigoFuncionario;
    }

    public void setCodigoFuncionario(final int codigoFuncionario) {
	this.codigoFuncionario = codigoFuncionario;
    }

    public boolean isStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    private static Funcionario funcionario;

    public static Funcionario getFuncionario() {
	return funcionario;
    }

    public static void setFuncionario(final Funcionario funcionario) {
	Funcionario.funcionario = funcionario;
    }

    private String nomeUsuario;
    private boolean acessoAdmin;
    private String chaveAcesso;
    private EFuncoesFuncionario funcao;
    private String nome;
    private int codigoFuncionario;
    private boolean status;
}
