package objeto;

import utilidade.ETelefone;

public class Telefone {

    public int getDdd() {
	return ddd;
    }

    public void setDdd(final int ddd) {
	this.ddd = ddd;
    }

    public boolean isStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    public ETelefone getTipo() {
	return tipo;
    }

    public void setTipo(final ETelefone tipo) {
	this.tipo = tipo;
    }

    public int getCodCliente() {
	return codCliente;
    }

    public void setCodCliente(final int codCliente) {
	this.codCliente = codCliente;
    }

    public int getNumero() {
	return numero;
    }

    public void setNumero(final int numero) {
	this.numero = numero;
    }

    public int getNumTelefone() {
	return numTelefone;
    }

    public void setNumTelefone(final int numTelefone) {
	this.numTelefone = numTelefone;
    }

    private int ddd;

    private boolean status;
    private ETelefone tipo;
    private int codCliente;
    private int codFornecedor;

    public int getCodFornecedor() {
	return codFornecedor;
    }

    public void setCodFornecedor(final int codFornecedor) {
	this.codFornecedor = codFornecedor;
    }

    private int numTelefone;
    private int numero;

}
