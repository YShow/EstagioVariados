package objeto;

import java.time.LocalDate;

public class EntradaMercadoria {
    private LocalDate dataEntrega;

    public LocalDate getDataEntrega() {
	return dataEntrega;
    }

    public void setDataEntrega(final LocalDate dataEntrega) {
	this.dataEntrega = dataEntrega;
    }

    public int getQuantidadeProduto() {
	return quantidadeProduto;
    }

    public void setQuantidadeProduto(final int quantidadeProduto) {
	this.quantidadeProduto = quantidadeProduto;
    }

    public boolean isStatus() {
	return status;
    }

    public void setStatus(final boolean status) {
	this.status = status;
    }

    public int getCodigoEntrada() {
	return codigoEntrada;
    }

    public void setCodigoEntrada(final int codigoEntrada) {
	this.codigoEntrada = codigoEntrada;
    }

    public int getCodigoFornecedor() {
	return codigoFornecedor;
    }

    public void setCodigoFornecedor(final int codigoFornecedor) {
	this.codigoFornecedor = codigoFornecedor;
    }

    private int quantidadeProduto;
    private boolean status;
    private int codigoEntrada;
    private int codigoFornecedor;

}
