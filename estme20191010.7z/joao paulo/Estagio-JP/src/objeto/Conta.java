package objeto;

import java.time.LocalDate;

public class Conta {
    private int id;

    public int getId() {
	return id;
    }

    public void setId(final int id) {
	this.id = id;
    }

    public String getDescricao() {
	return descricao;
    }

    public void setDescricao(final String descricao) {
	this.descricao = descricao;
    }

    public Float getValor() {
	return valor;
    }

    public void setValor(final Float valor) {
	this.valor = valor;
    }

    public LocalDate getDataPagamento() {
	return dataPagamento;
    }

    public void setDataPagamento(final LocalDate dataPagamento) {
	this.dataPagamento = dataPagamento;
    }

    public LocalDate getVencimento() {
	return vencimento;
    }

    public void setVencimento(final LocalDate vencimento) {
	this.vencimento = vencimento;
    }

    public String getTipo() {
	return tipo;
    }

    public void setTipo(final String tipo) {
	this.tipo = tipo;
    }

    private String descricao;
    private Float valor;
    private LocalDate dataPagamento;
    private LocalDate vencimento;
    private String tipo;
    private boolean ativo;

    public boolean isAtivo() {
	return ativo;
    }

    public void setAtivo(final boolean ativo) {
	this.ativo = ativo;
    }
}
