package objeto;

public class Telefone {

    public String getDdd() {
	return ddd;
    }

    public void setDdd(final String ddd) {
	this.ddd = ddd;
    }

    public String getFixo() {
	return fixo;
    }

    public void setFixo(final String fixo) {
	this.fixo = fixo;
    }

    public int getId() {
	return id;
    }

    public void setId(final int id) {
	this.id = id;
    }

    public String getMovel() {
	return movel;
    }

    public void setMovel(final String movel) {
	this.movel = movel;
    }

    public Pessoa getPessoa() {
	return pessoa;
    }

    public void setPessoa(final Pessoa pessoa) {
	this.pessoa = pessoa;
    }

    public Usuario getUsuario() {
	return usuario;
    }

    public void setUsuario(final Usuario usuario) {
	this.usuario = usuario;
    }

    private String ddd;
    private String fixo;
    private int id;
    private String movel;
    private Pessoa pessoa;
    private Usuario usuario;
}
