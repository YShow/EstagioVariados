package objeto;

public class PessoaJuridica extends Pessoa {
    private String cnpj;

    public String getCnpj() {
	return cnpj;
    }

    public void setCnpj(final String cnpj) {
	this.cnpj = cnpj;
    }

    public String getNomeFantasia() {
	return nomeFantasia;
    }

    public void setNomeFantasia(final String nomeFantasia) {
	this.nomeFantasia = nomeFantasia;
    }

    public String getInscricaoEstadual() {
	return InscricaoEstadual;
    }

    public void setInscricaoEstadual(final String inscricaoEstadual) {
	InscricaoEstadual = inscricaoEstadual;
    }

    public String getRazaoSocial() {
	return RazaoSocial;
    }

    public void setRazaoSocial(final String razaoSocial) {
	RazaoSocial = razaoSocial;
    }

    private String nomeFantasia;
    private String InscricaoEstadual;
    private String RazaoSocial;
}
