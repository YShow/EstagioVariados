package objeto;

public class ContasPagar extends Conta {
    public PessoaJuridica getPessoaJuridica() {
	return pessoaJuridica;
    }

    public void setPessoaJuridica(final PessoaJuridica pessoaJuridica) {
	this.pessoaJuridica = pessoaJuridica;
    }

    private PessoaJuridica pessoaJuridica;
}
