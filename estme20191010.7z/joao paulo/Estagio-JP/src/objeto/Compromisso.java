package objeto;

public class Compromisso {
    private String hora;
    private Pessoa pessoa;

    public Pessoa getPessoa() {
	return pessoa;
    }

    public void setPessoa(final Pessoa pessoa) {
	this.pessoa = pessoa;
    }

    public String getHora() {
	return hora;
    }

    public void setHora(final String hora) {
	this.hora = hora;
    }

    public int getId() {
	return id;
    }

    public void setId(final int id) {
	this.id = id;
    }

    public String getNome() {
	return nome;
    }

    public void setNome(final String nome) {
	this.nome = nome;
    }

    public float getDuracao() {
	return duracao;
    }

    public void setDuracao(final float duracao) {
	this.duracao = duracao;
    }

    public boolean getRealizado() {
	return realizado;
    }

    public void setRealizado(final boolean realizado) {
	this.realizado = realizado;
    }

    public String getDescricao() {
	return descricao;
    }

    public void setDescricao(final String descricao) {
	this.descricao = descricao;
    }

    public String getDia() {
	return Dia;
    }

    public void setDia(final String dia) {
	Dia = dia;
    }

    private int id;
    private String nome;
    private float duracao;
    private boolean realizado;
    private String descricao;
    private String Dia;
}
