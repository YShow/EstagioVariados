package objeto;

public class Usuario {
    private int id;
    private static Usuario Usuario;

    public static Usuario getUsuario() {
	return Usuario;
    }

    public static void setUsuario(final Usuario usuario) {
	Usuario = usuario;
    }

    public int getId() {
	return id;
    }

    public void setId(final int id) {
	this.id = id;
    }

    public String getNome() {
	return nome;
    }

    public void setNome(final String nome) {
	this.nome = nome;
    }

    public String getCpf() {
	return cpf;
    }

    public void setCpf(final String cpf) {
	this.cpf = cpf;
    }

    public boolean getAtivo() {
	return ativo;
    }

    public void setAtivo(final boolean ativo) {
	this.ativo = ativo;
    }

    public String getRg() {
	return rg;
    }

    public void setRg(final String rg) {
	this.rg = rg;
    }

    private String nome;
    private String cpf;
    private String senha;

    public String getSenha() {
	return senha;
    }

    public void setSenha(final String senha) {
	this.senha = senha;
    }

    public boolean getAdm() {
	return Adm;
    }

    public void setAdm(final boolean adm) {
	Adm = adm;
    }

    private boolean Adm;
    private boolean ativo;
    private String rg;

}
