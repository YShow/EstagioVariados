package objeto;

public class Endereco {

    public int getNumero() {
	return numero;
    }

    public void setNumero(final int numero) {
	this.numero = numero;
    }

    public String getCidade() {
	return cidade;
    }

    public void setCidade(final String cidade) {
	this.cidade = cidade;
    }

    public String getBairro() {
	return bairro;
    }

    public void setBairro(final String bairro) {
	this.bairro = bairro;
    }

    public String getComplemento() {
	return complemento;
    }

    public void setComplemento(final String complemento) {
	this.complemento = complemento;
    }

    public String getRua() {
	return rua;
    }

    public void setRua(final String rua) {
	this.rua = rua;
    }

    public String getEstado() {
	return Estado;
    }

    public void setEstado(final String estado) {
	Estado = estado;
    }

    public String getCep() {
	return cep;
    }

    public void setCep(final String cep) {
	this.cep = cep;
    }

    public int getId() {
	return id;
    }

    public void setId(final int id) {
	this.id = id;
    }

    public Pessoa getPessoa() {
	return pessoa;
    }

    public void setPessoa(final Pessoa pessoa) {
	this.pessoa = pessoa;
    }

    public Usuario getUsuario() {
	return usuario;
    }

    public void setUsuario(final Usuario usuario) {
	this.usuario = usuario;
    }

    private int numero;
    private String cidade;
    private String bairro;
    private String complemento;
    private String rua;
    private String Estado;
    private String cep;
    private int id;
    private Pessoa pessoa;
    private Usuario usuario;

}
