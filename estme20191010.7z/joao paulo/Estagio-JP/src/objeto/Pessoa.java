package objeto;

public class Pessoa {
    private int id;

    public int getId() {
	return id;
    }

    public void setId(final int id) {
	this.id = id;
    }

    public boolean isAtivo() {
	return ativo;
    }

    public void setAtivo(final boolean ativo) {
	this.ativo = ativo;
    }

    private boolean ativo;
}
