package objeto;

public class ContasReceber extends Conta {
    private PessoaFisica pessoaFisica;

    public PessoaFisica getPessoaFisica() {
	return pessoaFisica;
    }

    public void setPessoaFisica(final PessoaFisica pessoaFisica) {
	this.pessoaFisica = pessoaFisica;
    }

}
