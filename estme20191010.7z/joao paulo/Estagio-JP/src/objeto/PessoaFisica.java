package objeto;

public class PessoaFisica extends Pessoa {
    private String nome;

    public String getNome() {
	return nome;
    }

    public void setNome(final String nome) {
	this.nome = nome;
    }

    public String getRG() {
	return rg;
    }

    public void setRG(final String rG) {
	rg = rG;
    }

    public String getCPF() {
	return cpf;
    }

    public void setCPF(final String cPF) {
	cpf = cPF;
    }

    private String rg;
    private String cpf;

}
