package apresentacao;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ControladorMenuPrincipal {

    @FXML
    void miContaPagar(final ActionEvent event) {
	final var pagaConsulta = new ControladorPagarConsulta();
	pagaConsulta.abreTelaPagaConsulta();

    }

    @FXML
    void miContaRecebe(final ActionEvent event) {
	final var contaRecebe = new ControladorRecebePagConsulta();
	contaRecebe.abreTelaPagaConsulta();
    }

    @FXML
    void miPessoaFisica(final ActionEvent event) {

	final var pessoaFisica = new ControladorPessoaFisica();
	pessoaFisica.abreTelaPessoaFisica();
    }

    @FXML
    void miPessoaJuridica(final ActionEvent event) {
	final var pessoaJuridica = new ControladorPessoaJuridica();
	pessoaJuridica.abreTelaPessoaJuridica();
    }

    @FXML
    void miUsuario(final ActionEvent event) {
	final var usuario = new ControladorUsuario();
	usuario.abreTelaUsuario();
    }

    @FXML
    void miCompromisso(final ActionEvent event) {
	final var compromisso = new ControladorCompromisso();
	compromisso.abreTelaCompromisso();
    }
    @FXML
    void miCalendario(final ActionEvent event) {
	final var calendario = new ControladorCalendario();
	calendario.abreTelaCalendario();
    }
}
