package apresentacao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import apresentacao.insere.ControladorInserirPessoaFisica;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegPessoaFisica;
import objeto.PessoaFisica;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorPessoaFisica {

    @FXML
    private TextArea txtNome;

    @FXML
    private TableView<PessoaFisica> tblPessoaFisica;

    @FXML
    private TableColumn<PessoaFisica, String> tcNome;

    @FXML
    private TableColumn<PessoaFisica, String> tcCpf;

    @FXML
    private TableColumn<PessoaFisica, String> tcRg;

    @FXML
    private TableColumn<PessoaFisica, Boolean> tcAtivo;
    @FXML
    private TableColumn<PessoaFisica, Integer> tcCodigo;
    private final ControladorInserirPessoaFisica pessoaF = new ControladorInserirPessoaFisica();
    @FXML
    private Button btnInserir;

    @FXML
    private Button btnAltera;

    @FXML
    private Button btnRemove;

    public void abreTelaPessoaFisica() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/PessoaFisicaConsulta.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    public PessoaFisica abreTelaPessoaFisicaSelecionar() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	var pessoa = new PessoaFisica();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/PessoaFisicaConsulta.fxml"));
	    root = loader.load();
	    final var control = (ControladorPessoaFisica) loader.getController();

	    control.btnAltera.setDisable(true);
	    control.btnInserir.setDisable(true);
	    control.btnRemove.setText("Selecionar");
	    control.btnRemove.setOnAction(event -> {
		stage.close();
	    });
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);
	    stage.setScene(scene);
	    stage.showAndWait();

	    pessoa = control.pegaPessoa();

	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
	return pessoa;
    }

    private PessoaFisica pegaPessoa() {
	return tblPessoaFisica.getSelectionModel().getSelectedItem();
    }

    @FXML
    void btnAlterar(final ActionEvent event) {
	final var usuario = tblPessoaFisica.getSelectionModel().getSelectedItem();
	pessoaF.abreTelaPessoaFisicaInsere(TIPO_TELA.ALTERA, usuario);
    }

    @FXML
    void btnConsultar(final ActionEvent event) {
	final var negPF = new NegPessoaFisica();
	try {
	    final List<PessoaFisica> pessoaFisica = negPF.consultar(txtNome.getText());
	    final var data = FXCollections.observableList(pessoaFisica);
	    tblPessoaFisica.setItems(data);
	    tcAtivo.setCellValueFactory(new PropertyValueFactory<PessoaFisica, Boolean>("Ativo"));
	    tcCpf.setCellValueFactory(new PropertyValueFactory<PessoaFisica, String>("CPF"));
	    tcNome.setCellValueFactory(new PropertyValueFactory<PessoaFisica, String>("Nome"));
	    tcRg.setCellValueFactory(new PropertyValueFactory<PessoaFisica, String>("RG"));
	    tcCodigo.setCellValueFactory(new PropertyValueFactory<PessoaFisica, Integer>("Id"));
	} catch (final SQLException e) {

	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnInserir(final ActionEvent event) {
	pessoaF.abreTelaPessoaFisicaInsere(TIPO_TELA.INSERE, null);
    }

    @FXML
    void btnRemover(final ActionEvent event) {
	final var pessoaFisica = tblPessoaFisica.getSelectionModel().getSelectedItem();
	final var negPessoaFisica = new NegPessoaFisica();
	try {
	    if (negPessoaFisica.excluir(pessoaFisica.getId())) {
		tblPessoaFisica.getItems().remove(pessoaFisica);
		Alerta.alertaSucesso();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
