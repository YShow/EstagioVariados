package apresentacao;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import jfxtras.scene.control.CalendarPicker;
import utilidade.Alerta;


public class ControladorCalendario {


    @FXML
    private Pane pnPainel;

    @FXML
    private CalendarPicker calData;
    public void abreTelaCalendario() {

   	try {
   	 final var stage = new Stage();
    	Parent root;
    	final var loader = new FXMLLoader();
    	stage.initModality(Modality.APPLICATION_MODAL);

   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/calendario.fxml"));
   	    root = loader.load();

   	    final var scene = new Scene(root);

   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage());
   	}

       }
}
