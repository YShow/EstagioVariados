package apresentacao;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import apresentacao.insere.ControladorInsereContaPagar;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegContaPagar;
import objeto.ContasPagar;
import utilidade.Alerta;

public class ControladorPagarConsulta {

    @FXML
    private TextArea txtPesquisa;

    @FXML
    private TableView<ContasPagar> tblContaPagar;

    @FXML
    private TableColumn<ContasPagar, String> tcDescricao;

    @FXML
    private TableColumn<ContasPagar, Float> tcValor;

    @FXML
    private TableColumn<ContasPagar, LocalDate> tcData;

    @FXML
    private TableColumn<ContasPagar, LocalDate> tcVencimento;

    @FXML
    private TableColumn<ContasPagar, String> tcTipo;

    @FXML
    private TableColumn<ContasPagar, String> tcPessoa;
    @FXML
    private TableColumn<ContasPagar, Integer> tcCodPessoa;

    @FXML
    private TableColumn<ContasPagar, Integer> tcIdConta;
    @FXML
    private TableColumn<ContasPagar, Boolean> tcAtivo;

    public void abreTelaPagaConsulta() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/ContaPagarConsulta.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnAlterarContaPagar(final ActionEvent event) {
	final var telaAltera = new ControladorInsereContaPagar();
	final var conta = tblContaPagar.getSelectionModel().getSelectedItem();
	telaAltera.abreTelaAlteraContaPagar(conta);
    }

    @FXML
    void btnConsultar(final ActionEvent event) {
	final var negPagCon = new NegContaPagar();
	try {
	    final var pagContas = negPagCon.consultar(txtPesquisa.getText().trim());

	    final var data = FXCollections.observableArrayList(pagContas);
	    tblContaPagar.setItems(data);

	    tcData.setCellValueFactory(new PropertyValueFactory<ContasPagar, LocalDate>("dataPagamento"));
	    tcDescricao.setCellValueFactory(new PropertyValueFactory<ContasPagar, String>("descricao"));
	    tcPessoa.setCellValueFactory(
		    pessoa -> new ReadOnlyStringWrapper(pessoa.getValue().getPessoaJuridica().getNomeFantasia()));
	    tcCodPessoa.setCellValueFactory(
		    pessoa -> new ReadOnlyIntegerWrapper(pessoa.getValue().getPessoaJuridica().getId()).asObject());
	    tcIdConta.setCellValueFactory(new PropertyValueFactory<ContasPagar, Integer>("id"));
	    tcTipo.setCellValueFactory(new PropertyValueFactory<ContasPagar, String>("tipo"));
	    tcValor.setCellValueFactory(new PropertyValueFactory<ContasPagar, Float>("valor"));
	    tcVencimento.setCellValueFactory(new PropertyValueFactory<ContasPagar, LocalDate>("vencimento"));
	    tcAtivo.setCellValueFactory(new PropertyValueFactory<ContasPagar, Boolean>("ativo"));

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnExcluirContaPagar(final ActionEvent event) {
	final var negConta = new NegContaPagar();
	final var conta = tblContaPagar.getSelectionModel().getSelectedItem();
	try {
	    if (negConta.excluir(conta.getId())) {
		tblContaPagar.getItems().remove(conta);
		Alerta.alertaSucesso();

	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnInserirContaPagar(final ActionEvent event) {
	final var insere = new ControladorInsereContaPagar();
	insere.abreTelaInsereContaPagar();
    }
}
