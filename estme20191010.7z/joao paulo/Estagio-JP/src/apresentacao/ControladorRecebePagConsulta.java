package apresentacao;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import apresentacao.insere.ControladorInsereContaReceber;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegContaReceber;
import objeto.ContasReceber;
import utilidade.Alerta;

public class ControladorRecebePagConsulta {
    @FXML
    private Button btnInserir;

    @FXML
    private Button btnAlterar;

    @FXML
    private Button btnExcluir;

    @FXML
    private Button btnConsulta;

    @FXML
    private TextArea txtPesquisa;

    @FXML
    private TableView<ContasReceber> tblContaReceber;

    @FXML
    private TableColumn<ContasReceber, String> tcDescricao;

    @FXML
    private TableColumn<ContasReceber, Float> tcValor;

    @FXML
    private TableColumn<ContasReceber, LocalDate> tcDataPag;

    @FXML
    private TableColumn<ContasReceber, LocalDate> tcVenc;

    @FXML
    private TableColumn<ContasReceber, String> tcTipo;

    @FXML
    private TableColumn<ContasReceber, String> tcNomePessoa;

    @FXML
    private TableColumn<ContasReceber, Integer> tcIdConta;

    @FXML
    private TableColumn<ContasReceber, Integer> tcCodPessoa;

    public void abreTelaPagaConsulta() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/ContaReceberConsulta.fxml"));
	    root = loader.load();

	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnAlterar(final ActionEvent event) {
	final var inserir = new ControladorInsereContaReceber();
	final var data = tblContaReceber.getSelectionModel().getSelectedItem();
	inserir.abreTelaAlteraContaReceberAlterar(data);
    }

    @FXML
    void btnConsulta(final ActionEvent event) {

	final var negReceCon = new NegContaReceber();

	try {

	    final var contas = negReceCon.consultaContaReceber(txtPesquisa.getText().trim());
	    if (!contas.isEmpty()) {
		final var data = FXCollections.observableArrayList(contas);
		tblContaReceber.setItems(data);

		tcCodPessoa.setCellValueFactory(
			pessoa -> new ReadOnlyIntegerWrapper(pessoa.getValue().getPessoaFisica().getId()).asObject());
		tcDataPag.setCellValueFactory(new PropertyValueFactory<ContasReceber, LocalDate>("dataPagamento"));
		tcDescricao.setCellValueFactory(new PropertyValueFactory<ContasReceber, String>("descricao"));
		tcIdConta.setCellValueFactory(new PropertyValueFactory<ContasReceber, Integer>("id"));
		tcNomePessoa.setCellValueFactory(
			pessoa -> new ReadOnlyStringWrapper(pessoa.getValue().getPessoaFisica().getNome()));
		tcTipo.setCellValueFactory(new PropertyValueFactory<ContasReceber, String>("tipo"));
		tcValor.setCellValueFactory(new PropertyValueFactory<ContasReceber, Float>("valor"));
		tcVenc.setCellValueFactory(new PropertyValueFactory<ContasReceber, LocalDate>("vencimento"));
	    } else {
		Alerta.alertaCustomizado("Nenhuma conta encontrada", "Nenhuma conta encontrada com este cpf");
	    }

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnExcluir(final ActionEvent event) {
	final var negCon = new NegContaReceber();
	final var conta =  tblContaReceber.getSelectionModel().getSelectedItem();
	try {
	    if(negCon.excluir(conta.getId()))
	    {
		Alerta.alertaSucesso();
		tblContaReceber.getItems().remove(conta);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnInserir(final ActionEvent event) {
	final var inserir = new ControladorInsereContaReceber();
	inserir.abreTelaInsereContaReceber();
    }
}
