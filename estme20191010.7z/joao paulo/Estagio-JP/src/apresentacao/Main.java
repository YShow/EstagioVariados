package apresentacao;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(final Stage primaryStage) {
	final var loginTela = new ControladorLogin();
	try {
	    loginTela.start(primaryStage);
	} catch (final Exception e) {
	    System.out.println(e.getMessage());
	}
    }

    public static void main(final String[] args) {
	launch(args);
    }
}
