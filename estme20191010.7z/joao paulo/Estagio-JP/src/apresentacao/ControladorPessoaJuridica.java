package apresentacao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import apresentacao.insere.ControladorInserirPessoaJuridica;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegPessoaJuridica;
import objeto.PessoaJuridica;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorPessoaJuridica {
    @FXML
    private TextArea txtNome;
    @FXML
    private Button btnInserir;

    @FXML
    private Button btnAlterar;

    @FXML
    private Button btnExcluir;

    @FXML
    private Button btnConsultar;

    @FXML
    private TableView<PessoaJuridica> tblPessoaJuridica;

    @FXML
    private TableColumn<PessoaJuridica, String> tcCnpj;

    @FXML
    private TableColumn<PessoaJuridica, String> tcNome;

    @FXML
    private TableColumn<PessoaJuridica, String> tcRazao;

    @FXML
    private TableColumn<PessoaJuridica, String> tcInsEsta;

    @FXML
    private TableColumn<PessoaJuridica, Integer> tcCodigo;
    @FXML
    private TableColumn<PessoaJuridica, Boolean> tcAtivo;
    private final ControladorInserirPessoaJuridica pessoaJ = new ControladorInserirPessoaJuridica();

    public void abreTelaPessoaJuridica() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/PessoaJuridicaConsulta.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    public PessoaJuridica abreTelaPessoaJuridicaSeleciona() {
	var pessoaJu = new PessoaJuridica();
	try {
	    final var stage = new Stage();
	    Parent root;
	    final var loader = new FXMLLoader();
	    stage.initModality(Modality.APPLICATION_MODAL);

	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/PessoaJuridicaConsulta.fxml"));
	    root = loader.load();

	    final ControladorPessoaJuridica control = loader.getController();

	    control.btnAlterar.setDisable(true);
	    control.btnAlterar.setVisible(false);
	    control.btnInserir.setDisable(true);
	    control.btnInserir.setVisible(false);
	    control.btnExcluir.setText("Selecionar");
	    control.btnExcluir.setOnAction(e -> {
		control.btnExcluir.getScene().getWindow().hide();
	    });
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.showAndWait();
	    pessoaJu = control.tblPessoaJuridica.getSelectionModel().getSelectedItem();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
	return pessoaJu;
    }

    @FXML
    void btnAlterar(final ActionEvent event) {
	final var pessoa = tblPessoaJuridica.getSelectionModel().getSelectedItem();
	pessoaJ.abreTelaPessoaJuridicaInsere(TIPO_TELA.ALTERA, pessoa);
    }

    @FXML
    void btnConsultar(final ActionEvent event) {
	final var negPJ = new NegPessoaJuridica();
	try {
	    final List<PessoaJuridica> pessoaJuridica = negPJ.consultar(txtNome.getText());
	    final var data = FXCollections.observableList(pessoaJuridica);
	    tblPessoaJuridica.setItems(data);
	    tcAtivo.setCellValueFactory(new PropertyValueFactory("Ativo"));
	    tcCnpj.setCellValueFactory(new PropertyValueFactory("Cnpj"));
	    tcInsEsta.setCellValueFactory(new PropertyValueFactory("InscricaoEstadual"));
	    tcNome.setCellValueFactory(new PropertyValueFactory("NomeFantasia"));
	    tcRazao.setCellValueFactory(new PropertyValueFactory("RazaoSocial"));
	    tcCodigo.setCellValueFactory(new PropertyValueFactory("Id"));

	} catch (final SQLException e) {

	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void btnExcluir(final ActionEvent event) {

	final var pessoaJuridica = tblPessoaJuridica.getSelectionModel().getSelectedItem();
	final var negPessoaJuridica = new NegPessoaJuridica();
	try {
	    if (negPessoaJuridica.excluir(pessoaJuridica.getId())) {
		tblPessoaJuridica.getItems().remove(pessoaJuridica);
		Alerta.alertaSucesso();
	    }
	} catch (final SQLException e) {
	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void btnInserir(final ActionEvent event) {
	pessoaJ.abreTelaPessoaJuridicaInsere(TIPO_TELA.INSERE, null);
    }
}
