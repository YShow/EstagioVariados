package apresentacao.insere;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegPessoaJuridica;
import objeto.Endereco;
import objeto.PessoaJuridica;
import objeto.Telefone;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorInserirPessoaJuridica {
    @FXML
    private TextField txtInscricaoEstadual;

    @FXML
    private Button btnGravarUsuario;

    @FXML
    private TextField txtCNPJ;

    @FXML
    private TextField txtNomeFantasia;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TableView<Telefone> tblTelefone;

    @FXML
    private TableColumn<Telefone, String> tcDDD;

    @FXML
    private TableColumn<Telefone, String> tcFixo;

    @FXML
    private TableColumn<Telefone, String> tcMovel;

    @FXML
    private TableView<Endereco> tblEndereco;

    @FXML
    private TableColumn<Endereco, Integer> tcNumero;

    @FXML
    private TableColumn<Endereco, String> tcCidade;

    @FXML
    private TableColumn<Endereco, String> tcBairro;

    @FXML
    private TableColumn<Endereco, String> tcComplemento;

    @FXML
    private TableColumn<Endereco, String> tcRua;

    @FXML
    private TableColumn<Endereco, String> tcEstado;

    @FXML
    private TableColumn<Endereco, String> tcCep;

    @FXML
    private TextField txtRazaoSocial;

    private static int codPessoa;
    private static TIPO_TELA tipo_telaa;

    public void abreTelaPessoaJuridicaInsere(final TIPO_TELA tipo_tela, final PessoaJuridica pessoaJuridica) {
	tipo_telaa = tipo_tela;
	final var stage = new Stage();
	Parent root;
	try {

	    final var loader = new FXMLLoader(getClass().getResource("/apresentacao/insere/PessoaJuridicaInsere.fxml"));
	    stage.initModality(Modality.APPLICATION_MODAL);
	    root = loader.load();
	    final var controlador = (ControladorInserirPessoaJuridica) loader.getController();
	    stage.setScene(new Scene(root));
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));

	    if (tipo_tela.equals(TIPO_TELA.ALTERA)) {
		codPessoa = pessoaJuridica.getId();
		controlador.txtCodigo.setText(String.valueOf(codPessoa));
		controlador.chkAtivo.setSelected(pessoaJuridica.isAtivo());
		controlador.txtCNPJ.setText(pessoaJuridica.getCnpj());
		controlador.txtInscricaoEstadual.setText(pessoaJuridica.getInscricaoEstadual());
		controlador.txtNomeFantasia.setText(pessoaJuridica.getNomeFantasia());
		controlador.txtRazaoSocial.setText(pessoaJuridica.getRazaoSocial());
		preencheTelefone(controlador);
		preencheEndereco(controlador);
		stage.setTitle("Alterar Pessoa Juridica");
		stage.show();
	    } else {

		stage.setTitle("Inserir pessoa");
		stage.show();
	    }
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnGravar(final ActionEvent event) {
	final var negPJ = new NegPessoaJuridica();
	final var pessoaJ = new PessoaJuridica();
	if (tipo_telaa.equals(TIPO_TELA.ALTERA)) {

	    pessoaJ.setAtivo(chkAtivo.isSelected());
	    pessoaJ.setCnpj(txtCNPJ.getText());
	    pessoaJ.setId(codPessoa);
	    pessoaJ.setInscricaoEstadual(txtInscricaoEstadual.getText());
	    pessoaJ.setNomeFantasia(txtNomeFantasia.getText());
	    pessoaJ.setRazaoSocial(txtRazaoSocial.getText());
	    final var listTel = new ArrayList<Telefone>();
	    for (final var telefone : tblTelefone.getItems()) {
		listTel.add(telefone);
	    }
	    final var listEnde = new ArrayList<Endereco>();
	    for (final var endereco : tblEndereco.getItems()) {
		listEnde.add(endereco);
	    }

	    try {
		final var a = negPJ.alterar(pessoaJ, listTel, listEnde);
		System.out.println(a);
	    } catch (final SQLException e) {
		System.out.println(e.getMessage());
	    }
	} else {
	    pessoaJ.setAtivo(chkAtivo.isSelected());
	    pessoaJ.setCnpj(txtCNPJ.getText());
	    pessoaJ.setInscricaoEstadual(txtInscricaoEstadual.getText());
	    pessoaJ.setNomeFantasia(txtNomeFantasia.getText());
	    pessoaJ.setRazaoSocial(txtRazaoSocial.getText());
	    final var listTel = new ArrayList<Telefone>();
	    for (final var telefone : tblTelefone.getItems()) {
		listTel.add(telefone);
	    }
	    final var listEnde = new ArrayList<Endereco>();
	    for (final var endereco : tblEndereco.getItems()) {
		listEnde.add(endereco);
	    }
	    try {
		negPJ.inserir(pessoaJ, listTel, listEnde);
	    } catch (final Exception e) {
		System.out.println(e.getMessage());
	    }
	}
    }

    @FXML
    void btnInserirEndereco(final ActionEvent event) {
	final var enderecotela = new ControladorInsereEndereco();
	final var endereco = enderecotela.abreTelaInsereEndereco();
	if (endereco != null) {
	    tcBairro.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getBairro()));
	    tcCep.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCep()));
	    tcCidade.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCidade()));
	    tcComplemento.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getComplemento()));
	    tcEstado.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getEstado()));
	    tcRua.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getRua()));
	    tcNumero.setCellValueFactory(
		    bairro -> new ReadOnlyIntegerWrapper(bairro.getValue().getNumero()).asObject());
	    tblEndereco.getItems().add(endereco);
	}
    }

    @FXML
    void btnInserirTelefone(final ActionEvent event) {
	final var telefonetela = new ControladorInsereTelefone();
	final var telefone = telefonetela.abreTelaInsereTelefone();
	if (telefone != null) {
	    tcDDD.setCellValueFactory(ddd -> new ReadOnlyStringWrapper(ddd.getValue().getDdd()));
	    tcFixo.setCellValueFactory(fixo -> new ReadOnlyStringWrapper(fixo.getValue().getFixo()));
	    tcMovel.setCellValueFactory(movel -> new ReadOnlyStringWrapper(movel.getValue().getMovel()));

	    tblTelefone.getItems().add(telefone);
	}

    }

    void preencheTelefone(final ControladorInserirPessoaJuridica controlador) {
	final var telefones = new NegPessoaJuridica();

	try {
	    final var telefone = telefones.pegaTelefone(codPessoa);
	    controlador.tcDDD.setCellValueFactory(ddd -> new ReadOnlyStringWrapper(ddd.getValue().getDdd()));
	    controlador.tcFixo.setCellValueFactory(fixo -> new ReadOnlyStringWrapper(fixo.getValue().getFixo()));
	    controlador.tcMovel.setCellValueFactory(movel -> new ReadOnlyStringWrapper(movel.getValue().getMovel()));
	    final var data = FXCollections.observableList(telefone);
	    controlador.tblTelefone.setItems(data);

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    void preencheEndereco(final ControladorInserirPessoaJuridica controlador) {
	final var enderecos = new NegPessoaJuridica();

	try {
	    final var endereco = enderecos.pegaEndereco(codPessoa);
	    final var data = FXCollections.observableList(endereco);
	    controlador.tcBairro
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getBairro()));
	    controlador.tcCep.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCep()));
	    controlador.tcCidade
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCidade()));
	    controlador.tcComplemento
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getComplemento()));
	    controlador.tcEstado
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getEstado()));
	    controlador.tcRua.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getRua()));
	    controlador.tcNumero.setCellValueFactory(
		    bairro -> new ReadOnlyIntegerWrapper(bairro.getValue().getNumero()).asObject());

	    controlador.tblEndereco.setItems(data);

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
