package apresentacao.insere;

import java.io.IOException;
import java.sql.SQLException;

import apresentacao.ControladorPessoaFisica;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegContaReceber;
import objeto.ContasReceber;
import objeto.PessoaFisica;
import utilidade.Alerta;

public class ControladorInsereContaReceber {
    @FXML
    private Button btnGravar;

    @FXML
    private TextField txtDescricao;

    @FXML
    private TextField txtValor;

    @FXML
    private TextField txtTIpo;

    @FXML
    private TextField txtNomePessoa;

    @FXML
    private Button btnCancelar;

    @FXML
    private DatePicker datePag;

    @FXML
    private DatePicker dateVenciemnto;
    @FXML
    private CheckBox chkAtivo;
    @FXML
    private Button btnPesquisar;
    @FXML
    private Label lblCodPessoa;

    public void abreTelaInsereContaReceber() {
   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);

   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/ContaReceberInsere.fxml"));
   	    root = loader.load();

   	    final var scene = new Scene(root);

   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage());
   	}
       }


    public void abreTelaAlteraContaReceberAlterar(final ContasReceber conta) {
   	final var stage = new Stage();
   	Parent root;
   	final var loader = new FXMLLoader();
   	stage.initModality(Modality.APPLICATION_MODAL);

   	try {
   	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/ContaReceberInsere.fxml"));
   	    root = loader.load();
   	    final ControladorInsereContaReceber control = loader.getController();


   	    control.txtDescricao.setText(conta.getDescricao());
   	    control.txtNomePessoa.setText(conta.getPessoaFisica().getNome());
   	    control.txtTIpo.setText(conta.getTipo());
   	    control.txtValor.setText(String.valueOf(conta.getValor()));
   	    control.chkAtivo.setSelected(conta.isAtivo());
   	    control.datePag.setValue(conta.getDataPagamento());
   	    control.dateVenciemnto.setValue(conta.getVencimento());
   	    control.lblCodPessoa.setText(String.valueOf(conta.getPessoaFisica().getId()));

   	    control.btnPesquisar.setDisable(true);
   	    control.txtNomePessoa.setEditable(false);


   	    control.btnGravar.setOnAction(e -> {

   		final var negConta = new NegContaReceber();
   		final var contaNova = new ContasReceber();

   		contaNova.setDescricao(control.txtDescricao.getText().trim());
   		contaNova.setTipo(control.txtTIpo.getText().trim());
   		contaNova.setValor(Float.parseFloat(control.txtValor.getText().trim()));
   		contaNova.setAtivo(control.chkAtivo.isSelected());
   		contaNova.setDataPagamento(control.datePag.getValue());
   		contaNova.setVencimento(control.dateVenciemnto.getValue());
   		contaNova.setId(conta.getId());

   		try {
   		    if (negConta.alteraContaReceber(contaNova)) {
   			Alerta.alertaSucesso();
   		    }
   		} catch (final SQLException e1) {
   		    Alerta.alertaErro(e1.getMessage());
   		}

   	    });


   	    final var scene = new Scene(root);

   	    stage.setScene(scene);
   	    stage.show();
   	} catch (final IOException e) {
   	    Alerta.alertaErro(e.getMessage());
   	}
       }

    @FXML
    void btnCancelar(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void btnGravarContaReceber(final ActionEvent event) {
	final var contaRecebe = new ContasReceber();

	contaRecebe.setAtivo(chkAtivo.isSelected());
	contaRecebe.setDataPagamento(datePag.getValue());
	contaRecebe.setDescricao(txtDescricao.getText().trim());
	contaRecebe.setTipo(txtTIpo.getText().trim());
	contaRecebe.setValor(Float.parseFloat(txtValor.getText().trim()));
	contaRecebe.setVencimento(dateVenciemnto.getValue());

	final var pessoa = new PessoaFisica();
	pessoa.setId(Integer.parseInt(lblCodPessoa.getText().trim()));
	contaRecebe.setPessoaFisica(pessoa);

	final var negRec = new NegContaReceber();
	try {
	    if(negRec.insereContaRecebe(contaRecebe))
	    {
		Alerta.alertaSucesso();
	    }


	} catch (final SQLException e) {
	  Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnPesquisar(final ActionEvent event) {
	final var pessoaJuridica = new ControladorPessoaFisica();
	final var pessoa = pessoaJuridica.abreTelaPessoaFisicaSelecionar();

	lblCodPessoa.setText(String.valueOf(pessoa.getId()));
	lblCodPessoa.setVisible(true);
	txtNomePessoa.setText(pessoa.getNome());
    }

}
