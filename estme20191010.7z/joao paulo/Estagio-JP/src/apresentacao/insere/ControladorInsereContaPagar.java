package apresentacao.insere;

import java.io.IOException;
import java.sql.SQLException;

import apresentacao.ControladorPessoaJuridica;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegContaPagar;
import objeto.ContasPagar;
import objeto.PessoaJuridica;
import utilidade.Alerta;

public class ControladorInsereContaPagar {

    @FXML
    private Button btnGravarContaPagar;

    @FXML
    private TextField txtDescricao;

    @FXML
    private TextField txtValor;
    @FXML
    private TextField txtNomePessoa;

    @FXML
    private TextField txtTipo;

    @FXML
    private Button btnCancelar;

    @FXML
    private DatePicker datePagamento;

    @FXML
    private DatePicker dateVencimento;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private Button btnPesquisaPessoaFisica;

    @FXML
    private Label lblCodigoPessoaFisica;

    public void abreTelaInsereContaPagar() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/ContaPagarInsere.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    public void abreTelaAlteraContaPagar(final ContasPagar conta) {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/ContaPagarInsere.fxml"));
	    root = loader.load();
	    final ControladorInsereContaPagar control = loader.getController();

	    control.txtDescricao.setText(conta.getDescricao());
	    control.txtNomePessoa.setText(conta.getPessoaJuridica().getNomeFantasia());
	    control.txtTipo.setText(conta.getTipo());
	    control.txtValor.setText(String.valueOf(conta.getValor()));
	    control.chkAtivo.setSelected(conta.isAtivo());
	    control.lblCodigoPessoaFisica.setText(String.valueOf(conta.getPessoaJuridica().getId()));
	    control.datePagamento.setValue(conta.getDataPagamento());
	    control.dateVencimento.setValue(conta.getVencimento());
	    control.txtNomePessoa.setEditable(false);
	    control.txtNomePessoa.setDisable(true);
	    control.btnPesquisaPessoaFisica.setDisable(true);

	    control.btnGravarContaPagar.setOnAction(e -> {

		final var negConta = new NegContaPagar();
		final var contaNova = new ContasPagar();

		contaNova.setDescricao(control.txtDescricao.getText().trim());
		contaNova.setTipo(control.txtTipo.getText().trim());
		contaNova.setValor(Float.parseFloat(control.txtValor.getText().trim()));
		contaNova.setAtivo(control.chkAtivo.isSelected());
		contaNova.setDataPagamento(control.datePagamento.getValue());
		contaNova.setVencimento(control.dateVencimento.getValue());
		contaNova.setId(conta.getId());

		try {
		    if (negConta.alterar(contaNova)) {
			Alerta.alertaSucesso();
		    }
		} catch (final SQLException e1) {
		    Alerta.alertaErro(e1.getMessage());
		}

	    });

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnCancelar(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void btnGravarContaPagar(final ActionEvent event) {
	final var negContaPaga = new NegContaPagar();
	final var contaPaga = new ContasPagar();
	final var pessoa = new PessoaJuridica();
	contaPaga.setDataPagamento(datePagamento.getValue());
	contaPaga.setAtivo(chkAtivo.isSelected());
	pessoa.setId(Integer.parseInt(lblCodigoPessoaFisica.getText().trim()));
	contaPaga.setPessoaJuridica(pessoa);
	contaPaga.setDescricao(txtDescricao.getText().trim());
	contaPaga.setTipo(txtTipo.getText().trim());
	contaPaga.setValor(Float.parseFloat(txtValor.getText().trim()));
	contaPaga.setVencimento(dateVencimento.getValue());

	try {
	    if (negContaPaga.inserir(contaPaga)) {
		Alerta.alertaSucesso();
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnPesquisaPessoaFisica(final ActionEvent event) {
	final var pessoaJuridica = new ControladorPessoaJuridica();
	final var pessoa = pessoaJuridica.abreTelaPessoaJuridicaSeleciona();

	lblCodigoPessoaFisica.setText(String.valueOf(pessoa.getId()));
	txtNomePessoa.setText(pessoa.getNomeFantasia());
    }

}
