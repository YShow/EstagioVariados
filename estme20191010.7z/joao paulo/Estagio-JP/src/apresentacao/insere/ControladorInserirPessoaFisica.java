package apresentacao.insere;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegPessoaFisica;
import negocio.NegTelefoneEndereco;
import objeto.Endereco;
import objeto.PessoaFisica;
import objeto.Telefone;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorInserirPessoaFisica {
    @FXML
    private TextField txtRG;

    @FXML
    private Button btnGravarUsuario;

    @FXML
    private TextField txtCPF;

    @FXML
    private TextField txtNome;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TableView<Telefone> tblTelefone;

    @FXML
    private TableColumn<Telefone, String> tcDDD;

    @FXML
    private TableColumn<Telefone, String> tcFixo;

    @FXML
    private TableColumn<Telefone, String> tcMovel;

    @FXML
    private TableView<Endereco> tblEndereco;

    @FXML
    private TableColumn<Endereco, Integer> tcNumero;

    @FXML
    private TableColumn<Endereco, String> tcCidade;

    @FXML
    private TableColumn<Endereco, String> tcBairro;

    @FXML
    private TableColumn<Endereco, String> tcComplemento;

    @FXML
    private TableColumn<Endereco, String> tcRua;

    @FXML
    private TableColumn<Endereco, String> tcEstado;

    @FXML
    private TableColumn<Endereco, String> tcCep;
    private static int codPessoa;
    private static TIPO_TELA tipo_telaa;

    public void abreTelaPessoaFisicaInsere(final TIPO_TELA tipo_tela, final PessoaFisica pessoaFisica) {
	tipo_telaa = tipo_tela;
	final var stage = new Stage();
	Parent root;
	try {
	    final var loader = new FXMLLoader(getClass().getResource("/apresentacao/insere/PessoaFisicaInsere.fxml"));
	    stage.initModality(Modality.APPLICATION_MODAL);
	    root = loader.load();
	    final var controlador = (ControladorInserirPessoaFisica) loader.getController();
	    stage.setScene(new Scene(root));
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));

	    if (tipo_tela.equals(TIPO_TELA.ALTERA)) {
		codPessoa = pessoaFisica.getId();
		controlador.chkAtivo.setSelected(pessoaFisica.isAtivo());
		controlador.txtCPF.setText(pessoaFisica.getCPF());
		controlador.txtNome.setText(pessoaFisica.getNome());
		controlador.txtRG.setText(pessoaFisica.getRG());
		controlador.txtCodigo.setText(String.valueOf(pessoaFisica.getId()));
		preencheEndereco(controlador);
		preencheTelefone(controlador);

		stage.setTitle("Alterar pessoa");
		stage.show();
	    } else {

		stage.setTitle("Inserir pessoa");
		stage.show();
	    }
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void btnGravar(final ActionEvent event) {
	final var negPF = new NegPessoaFisica();
	final var pessoaF = new PessoaFisica();
	if (tipo_telaa.equals(TIPO_TELA.ALTERA)) {
	    pessoaF.setAtivo(chkAtivo.isSelected());
	    pessoaF.setCPF(txtCPF.getText());
	    pessoaF.setId(codPessoa);
	    pessoaF.setNome(txtNome.getText());
	    pessoaF.setRG(txtRG.getText());
	    System.out.println(pessoaF.getId());
	    try {
		final var a = negPF.alterar(pessoaF);
		System.out.println(a);
	    } catch (final SQLException e) {
		System.out.println(e.getMessage());
	    }
	} else {
	    pessoaF.setAtivo(chkAtivo.isSelected());
	    pessoaF.setCPF(txtCPF.getText());
	    pessoaF.setNome(txtNome.getText());
	    pessoaF.setRG(txtRG.getText());
	    final var endereco = pegaEnderecos();
	    final var tel = pegaTelefones();

	    try {
		negPF.inserir(pessoaF, tel, endereco);
	    } catch (final Exception e) {
		System.out.println(e.getMessage());
	    }
	}

    }

    private List<Telefone> pegaTelefones() {
	final var listTel = new ArrayList<Telefone>();
	for (final var telefone : tblTelefone.getItems()) {
	    listTel.add(telefone);
	}
	return listTel;
    }

    private List<Endereco> pegaEnderecos() {
	final var listEnde = new ArrayList<Endereco>();
	for (final var endereco : tblEndereco.getItems()) {
	    listEnde.add(endereco);
	}
	return listEnde;
    }

    @FXML
    void btnInserirEndereco(final ActionEvent event) {
	final var enderecotela = new ControladorInsereEndereco();
	final var endereco = enderecotela.abreTelaInsereEndereco();
	if (endereco != null) {
	    tcBairro.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getBairro()));
	    tcCep.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCep()));
	    tcCidade.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCidade()));
	    tcComplemento.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getComplemento()));
	    tcEstado.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getEstado()));
	    tcRua.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getRua()));
	    tcNumero.setCellValueFactory(
		    bairro -> new ReadOnlyIntegerWrapper(bairro.getValue().getNumero()).asObject());
	    tblEndereco.getItems().add(endereco);
	}
    }

    @FXML
    void btnInserirTelefone(final ActionEvent event) {
	final var telefonetela = new ControladorInsereTelefone();
	final var telefone = telefonetela.abreTelaInsereTelefone();
	if (telefone != null) {
	    tcDDD.setCellValueFactory(ddd -> new ReadOnlyStringWrapper(ddd.getValue().getDdd()));
	    tcFixo.setCellValueFactory(fixo -> new ReadOnlyStringWrapper(fixo.getValue().getFixo()));
	    tcMovel.setCellValueFactory(movel -> new ReadOnlyStringWrapper(movel.getValue().getMovel()));

	    tblTelefone.getItems().add(telefone);
	}

    }

    void preencheTelefone(final ControladorInserirPessoaFisica controlador) {
	final var telefones = new NegTelefoneEndereco();

	try {
	    final var telefone = telefones.pegaTelefonesPessoa(codPessoa);
	    final var data = FXCollections.observableArrayList(telefone);

	    controlador.tcDDD.setCellValueFactory(ddd -> new ReadOnlyStringWrapper(ddd.getValue().getDdd()));
	    controlador.tcFixo.setCellValueFactory(fixo -> new ReadOnlyStringWrapper(fixo.getValue().getFixo()));
	    controlador.tcMovel.setCellValueFactory(movel -> new ReadOnlyStringWrapper(movel.getValue().getMovel()));
	    controlador.tblTelefone.setItems(data);

	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    void preencheEndereco(final ControladorInserirPessoaFisica controlador) {
	final var enderecos = new NegTelefoneEndereco();

	try {
	    final var endereco = enderecos.pegaEnderecoPessoa(codPessoa);
	    final var data = FXCollections.observableArrayList(endereco);

	    controlador.tcBairro
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getBairro()));
	    controlador.tcCep.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCep()));
	    controlador.tcCidade
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCidade()));
	    controlador.tcComplemento
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getComplemento()));
	    controlador.tcEstado
		    .setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getEstado()));
	    controlador.tcRua.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getRua()));
	    controlador.tcNumero.setCellValueFactory(
		    bairro -> new ReadOnlyIntegerWrapper(bairro.getValue().getNumero()).asObject());
	    controlador.tblEndereco.setItems(data);
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
