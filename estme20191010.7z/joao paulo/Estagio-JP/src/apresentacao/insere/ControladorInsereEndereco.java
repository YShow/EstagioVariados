package apresentacao.insere;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import objeto.Endereco;

public class ControladorInsereEndereco {
    @FXML
    private Button btnGravarEndereco;

    @FXML
    private TextField txtCEP;

    @FXML
    private Button btnCancelar;

    @FXML
    private TextField txtRua;

    @FXML
    private TextField txtEstado;

    @FXML
    private TextField txtNumero;

    @FXML
    private TextField txtCidade;

    @FXML
    private TextField txtBairro;

    @FXML
    private TextField txtComplemento;

    private static Endereco enderecoo;

    public Endereco abreTelaInsereEndereco() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/EnderecoInsere.fxml"));
	    root = loader.load();

	    stage.initModality(Modality.APPLICATION_MODAL);

	    stage.setScene(new Scene(root));
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));

	    stage.setTitle("Inserir pessoa");
	    stage.showAndWait();
	    stage.close();
	} catch (final IOException e) {
	    System.out.println(e.toString() + "\n " + e.getMessage() + "\n" + e.getLocalizedMessage());
	}
	return enderecoo;

    }

    @FXML
    void btnCancela(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void btnGravaEndereco(final ActionEvent event) {
	final var endereco = new Endereco();
	endereco.setBairro(txtBairro.getText());
	endereco.setCep(txtCEP.getText());
	endereco.setCidade(txtCidade.getText());
	endereco.setComplemento(txtComplemento.getText());
	endereco.setEstado(txtEstado.getText());
	endereco.setNumero(Integer.valueOf(txtNumero.getText()));
	endereco.setRua(txtRua.getText());

	enderecoo = endereco;
	btnGravarEndereco.getScene().getWindow().hide();
    }
}
