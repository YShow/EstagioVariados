package apresentacao.insere;

import java.io.IOException;
import java.sql.SQLException;

import apresentacao.ControladorPessoaFisica;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegCompromisso;
import objeto.Compromisso;
import objeto.Pessoa;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorInsereCompromisso {
    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtDescricao;

    @FXML
    private TextField txtHora;

    @FXML
    private TextField txtDIa;

    @FXML
    private TextField txtDuracao;

    @FXML
    private Button btnGravarCompromisso;
    @FXML
    private TextField txtCodCliente;
    @FXML
    private Button btnPesquisarCliente;
    @FXML
    private TextField txtCodCompromisso;

    @FXML
    private CheckBox chkRealizado;
    @FXML
    private Label lblCodCompromisso;

    private static TIPO_TELA tipo_telaa;

    @FXML
    private Button btnCancelarCompromisso;

    public void abreTelaCompromisso(final TIPO_TELA tipo_tela, final Compromisso compromisso) {
	tipo_telaa = tipo_tela;
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {

	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/CompromissoInsere.fxml"));
	    root = loader.load();
	    final var scene = new Scene(root);
	    final var control = (ControladorInsereCompromisso) loader.getController();
	    if (tipo_tela == TIPO_TELA.ALTERA) {
		control.txtDescricao.setText(compromisso.getDescricao());
		control.txtDIa.setText(compromisso.getDia());
		control.txtDuracao.setText(String.valueOf(compromisso.getDuracao()));
		control.txtHora.setText(compromisso.getHora());
		control.txtNome.setText(compromisso.getNome());
		control.chkRealizado.setSelected(compromisso.getRealizado());
		control.txtCodCliente.setText(String.valueOf(compromisso.getPessoa().getId()));
		control.txtCodCompromisso.setText(String.valueOf(compromisso.getId()));
		stage.setScene(scene);
		stage.show();
	    } else {
		control.chkRealizado.setSelected(false);
		control.txtCodCompromisso.setDisable(true);
		control.txtCodCompromisso.setVisible(false);
		control.lblCodCompromisso.setDisable(true);
		control.lblCodCompromisso.setVisible(false);
		stage.setScene(scene);
		stage.show();
	    }
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnPesquisarCliente(final ActionEvent event) {
	final var pessoaT = new ControladorPessoaFisica();
	final var pessoa = pessoaT.abreTelaPessoaFisicaSelecionar();
	txtCodCliente.setText(String.valueOf(pessoa.getId()));
    }

    @FXML
    void btnCancela(final ActionEvent event) {
	btnCancelarCompromisso.getScene().getWindow().hide();
    }

    @FXML
    void btnGravarCompromisso(final ActionEvent event) {
	final var negComp = new NegCompromisso();
	final var compromisso = pegaCompromisso();
	try {
	    if (tipo_telaa == TIPO_TELA.INSERE) {
		if (negComp.inserir(compromisso)) {
		    Alerta.alertaSucesso();
		}
	    } else if (tipo_telaa == TIPO_TELA.ALTERA) {
		if (negComp.alterar(compromisso)) {
		    Alerta.alertaSucesso();
		}
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    private final Compromisso pegaCompromisso() {
	final var comp = new Compromisso();
	comp.setDescricao(txtDescricao.getText());
	comp.setDia(txtDIa.getText());
	comp.setDuracao(Float.parseFloat(txtDuracao.getText()));
	comp.setHora(txtHora.getText());
	comp.setNome(txtNome.getText());
	comp.setRealizado(chkRealizado.isSelected());
	comp.setId(Integer.parseInt(txtCodCompromisso.getText()));
	final var pessoa = new Pessoa();
	pessoa.setId(Integer.parseInt(txtCodCliente.getText()));
	comp.setPessoa(pessoa);
	return comp;
    }

}
