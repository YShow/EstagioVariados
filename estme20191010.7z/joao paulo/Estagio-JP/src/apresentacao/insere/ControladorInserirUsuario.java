package apresentacao.insere;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegTelefoneEndereco;
import negocio.NegUsuario;
import objeto.Endereco;
import objeto.Telefone;
import objeto.Usuario;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorInserirUsuario {

    @FXML
    private TextField txtRG;

    @FXML
    private PasswordField txtSenhaFuncionario;

    @FXML
    private CheckBox chkAdm;

    @FXML
    private Button btnGravarUsuario;

    @FXML
    private TextField txtCPF;

    @FXML
    private TextField txtNome;

    @FXML
    private CheckBox chkAtivo;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TableView<Telefone> tblTelefone;

    @FXML
    private TableColumn<Telefone, String> tcDDD;

    @FXML
    private TableColumn<Telefone, String> tcFixo;

    @FXML
    private TableColumn<Telefone, String> tcMovel;

    @FXML
    private TableView<Endereco> tblEndereco;

    @FXML
    private TableColumn<Endereco, Integer> tcNumero;

    @FXML
    private TableColumn<Endereco, String> tcCidade;

    @FXML
    private TableColumn<Endereco, String> tcBairro;

    @FXML
    private TableColumn<Endereco, String> tcComplemento;

    @FXML
    private TableColumn<Endereco, String> tcRua;

    @FXML
    private TableColumn<Endereco, String> tcEstado;

    @FXML
    private TableColumn<Endereco, String> tcCep;

    private static TIPO_TELA tipo_telaa;

    public void abreTelaFuncionarioInsere(final TIPO_TELA tipo_tela, final Usuario usuarioIn) {
	tipo_telaa = tipo_tela;
	final var stage = new Stage();
	Parent root;
	try {
	    final var loader = new FXMLLoader(getClass().getResource("/apresentacao/insere/UsuarioInsere.fxml"));
	    stage.initModality(Modality.APPLICATION_MODAL);
	    root = loader.load();
	    final var controlador = (ControladorInserirUsuario) loader.getController();
	    stage.setScene(new Scene(root));
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));

	    if (tipo_tela.equals(TIPO_TELA.ALTERA)) {
		controlador.txtCodigo.setVisible(false);
		controlador.txtCodigo.setText(String.valueOf(usuarioIn.getId()));
		controlador.btnGravarUsuario.setText("Alterar");
		controlador.txtCPF.setText(usuarioIn.getCpf());
		controlador.txtNome.setText(usuarioIn.getNome());
		controlador.txtSenhaFuncionario.setText(usuarioIn.getSenha());
		controlador.chkAdm.setSelected(usuarioIn.getAdm());
		controlador.chkAtivo.setSelected(usuarioIn.getAtivo());
		controlador.txtRG.setText(usuarioIn.getRg());
		preencheTelefones(controlador, usuarioIn.getId());
		preencheEnderecos(controlador, usuarioIn.getId());
		stage.setTitle("Alterar Usuario");
		stage.show();
	    } else {

		stage.setTitle("Inserir Usuario");
		stage.show();
	    }
	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void btnGravarUsuario(final ActionEvent event) {
	final var negUsuario = new NegUsuario();
	final var usuario = new Usuario();
	final var listTel = pegaTelefones();
	final var listEnde = pegaEnderecos();
	if (tipo_telaa.equals(TIPO_TELA.ALTERA)) {
	    try {
		usuario.setAdm(chkAdm.isSelected());
		usuario.setAtivo(chkAtivo.isSelected());
		usuario.setCpf(txtCPF.getText());
		usuario.setNome(txtNome.getText());
		usuario.setRg(txtRG.getText());
		usuario.setSenha(txtSenhaFuncionario.getText());
		usuario.setId(Integer.valueOf(txtCodigo.getText()));

		if (negUsuario.alterar(usuario, listTel, listEnde)) {
		    Alerta.alertaSucesso();
		}

	    } catch (final SQLException e) {
		System.out.println(e.getMessage());
	    }
	} else {
	    try {

		usuario.setAdm(chkAdm.isSelected());
		usuario.setAtivo(chkAtivo.isSelected());
		usuario.setCpf(txtCPF.getText());
		usuario.setNome(txtNome.getText());
		usuario.setRg(txtRG.getText());
		usuario.setSenha(txtSenhaFuncionario.getText());

		if (negUsuario.inserir(usuario, listEnde, listTel)) {
		    Alerta.alertaSucesso();
		}

	    } catch (final SQLException e) {
		Alerta.alertaErro(e.getMessage());
	    }
	}
    }

    @FXML
    void btnInserirEndereco(final ActionEvent event) {
	final var enderecotela = new ControladorInsereEndereco();
	final var endereco = enderecotela.abreTelaInsereEndereco();
	if (endereco != null) {
	    tcBairro.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getBairro()));
	    tcCep.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCep()));
	    tcCidade.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getCidade()));
	    tcComplemento.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getComplemento()));
	    tcEstado.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getEstado()));
	    tcRua.setCellValueFactory(bairro -> new ReadOnlyStringWrapper(bairro.getValue().getRua()));
	    tcNumero.setCellValueFactory(
		    bairro -> new ReadOnlyIntegerWrapper(bairro.getValue().getNumero()).asObject());
	    tblEndereco.getItems().add(endereco);
	}
    }

    @FXML
    void btnInserirTelefone(final ActionEvent event) {
	final var telefonetela = new ControladorInsereTelefone();
	final var telefone = telefonetela.abreTelaInsereTelefone();
	if (telefone != null) {
	    tcDDD.setCellValueFactory(ddd -> new ReadOnlyStringWrapper(ddd.getValue().getDdd()));
	    tcFixo.setCellValueFactory(fixo -> new ReadOnlyStringWrapper(fixo.getValue().getFixo()));
	    tcMovel.setCellValueFactory(movel -> new ReadOnlyStringWrapper(movel.getValue().getMovel()));

	    tblTelefone.getItems().add(telefone);
	}
    }

    private List<Telefone> pegaTelefones() {
	final var listTel = new ArrayList<Telefone>();
	for (final var telefone : tblTelefone.getItems()) {
	    listTel.add(telefone);
	}
	return listTel;
    }

    private List<Endereco> pegaEnderecos() {
	final var listEnde = new ArrayList<Endereco>();
	for (final var endereco : tblEndereco.getItems()) {
	    listEnde.add(endereco);
	}
	return listEnde;
    }

    private void preencheTelefones(final ControladorInserirUsuario controlador, final int id) {
	final var negtel = new NegTelefoneEndereco();
	try {
	    final var telefones = negtel.pegaTelefonesUsuario(id);

	    if (!telefones.isEmpty()) {
		controlador.tcFixo.setCellValueFactory(new PropertyValueFactory<Telefone, String>("fixo"));
		controlador.tcMovel.setCellValueFactory(new PropertyValueFactory<Telefone, String>("movel"));
		controlador.tcDDD.setCellValueFactory(new PropertyValueFactory<Telefone, String>("ddd"));
		final var data = FXCollections.observableArrayList(telefones);
		controlador.tblTelefone.setItems(data);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    private void preencheEnderecos(final ControladorInserirUsuario controlador, final int id) {
	final var negende = new NegTelefoneEndereco();
	try {
	    final var endereco = negende.pegaEnderecoUsuario(id);
	    if (!endereco.isEmpty()) {

		controlador.tcBairro.setCellValueFactory(new PropertyValueFactory<Endereco, String>("bairro"));
		controlador.tcCep.setCellValueFactory(new PropertyValueFactory<Endereco, String>("cep"));
		controlador.tcCidade.setCellValueFactory(new PropertyValueFactory<Endereco, String>("cidade"));
		controlador.tcComplemento
			.setCellValueFactory(new PropertyValueFactory<Endereco, String>("complemento"));
		controlador.tcEstado.setCellValueFactory(new PropertyValueFactory<Endereco, String>("estado"));
		controlador.tcRua.setCellValueFactory(new PropertyValueFactory<Endereco, String>("rua"));
		controlador.tcNumero.setCellValueFactory(new PropertyValueFactory<Endereco, Integer>("numero"));

		final var data = FXCollections.observableArrayList(endereco);
		controlador.tblEndereco.setItems(data);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
