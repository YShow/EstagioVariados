package apresentacao.insere;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import objeto.Telefone;

public class ControladorInsereTelefone {

    @FXML
    private Button btnGravar;

    @FXML
    private TextField txtDDD;

    @FXML
    private TextField txtFixo;

    @FXML
    private TextField txtMovel;

    @FXML
    private Button btnCancelar;
    private static Telefone telefone;

    public Telefone abreTelaInsereTelefone() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/insere/TelefoneInsere.fxml"));
	    root = loader.load();

	    stage.initModality(Modality.APPLICATION_MODAL);

	    stage.setScene(new Scene(root));
	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));

	    stage.setTitle("Inserir telefone");
	    stage.showAndWait();
	    stage.close();
	} catch (final IOException e) {
	    System.out.println(e.toString() + "\n " + e.getMessage() + "\n" + e.getLocalizedMessage());
	}
	return telefone;

    }

    @FXML
    void btnCancelar(final ActionEvent event) {
	btnCancelar.getScene().getWindow().hide();
    }

    @FXML
    void btnGravar(final ActionEvent event) {
	final var telefonee = new Telefone();
	telefonee.setDdd(txtDDD.getText());
	telefonee.setFixo(txtFixo.getText());
	telefonee.setMovel(txtMovel.getText());

	telefone = telefonee;
	btnGravar.getScene().getWindow().hide();

    }
}
