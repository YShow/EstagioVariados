package apresentacao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import apresentacao.insere.ControladorInserirUsuario;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegUsuario;
import objeto.Usuario;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorUsuario {
    @FXML
    private TextArea txtNome;

    @FXML
    private TableView<Usuario> tblUsuario;

    @FXML
    private TableColumn<Usuario, String> tcNome;

    @FXML
    private TableColumn<Usuario, String> tcSenha;

    @FXML
    private TableColumn<Usuario, String> tcCPF;

    @FXML
    private TableColumn<Usuario, String> tcRG;

    @FXML
    private TableColumn<Usuario, Boolean> tcAdm;

    @FXML
    private TableColumn<Usuario, Boolean> tcAtivo;
    @FXML
    private TableColumn<Usuario, Integer> tcCodigo;

    private final ControladorInserirUsuario insUsuario = new ControladorInserirUsuario();

    public void abreTelaUsuario() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/UsuarioConsulta.fxml"));
	    root = loader.load();

	    stage.setMinHeight(root.minHeight(-1));
	    stage.setMinWidth(root.minWidth(-1));
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnAlterar(final ActionEvent event) {

	final var usuario = tblUsuario.getSelectionModel().getSelectedItem();

	insUsuario.abreTelaFuncionarioInsere(TIPO_TELA.ALTERA, usuario);
    }

    @FXML
    void btnConsulta(final ActionEvent event) {
	final var negUsuario = new NegUsuario();
	try {
	    final List<Usuario> usuario = negUsuario.consultar(txtNome.getText());
	    final var data = FXCollections.observableList(usuario);
	    tblUsuario.setItems(data);
	    tcAdm.setCellValueFactory(new PropertyValueFactory("Adm"));
	    tcAtivo.setCellValueFactory(new PropertyValueFactory("Ativo"));
	    tcRG.setCellValueFactory(new PropertyValueFactory("Rg"));
	    tcCPF.setCellValueFactory(new PropertyValueFactory("Cpf"));
	    tcNome.setCellValueFactory(new PropertyValueFactory("Nome"));
	    tcSenha.setCellValueFactory(new PropertyValueFactory("Senha"));
	    tcCodigo.setCellValueFactory(new PropertyValueFactory("Id"));

	} catch (final SQLException e) {

	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void btnExcluir(final ActionEvent event) {
	final var usuario = tblUsuario.getSelectionModel().getSelectedItem();
	final var negUsuario = new NegUsuario();
	try {
	    if (negUsuario.excluir(usuario.getId())) {
		tblUsuario.getItems().remove(usuario);
	    }
	} catch (final SQLException e) {
	    System.out.println(e.getMessage());
	}
    }

    @FXML
    void btnInserir(final ActionEvent event) {
	insUsuario.abreTelaFuncionarioInsere(TIPO_TELA.INSERE, null);
    }

}
