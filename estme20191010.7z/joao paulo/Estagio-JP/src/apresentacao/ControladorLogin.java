package apresentacao;

import java.io.IOException;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import negocio.NegLogin;
import objeto.Usuario;
import utilidade.Alerta;

public class ControladorLogin extends Application {
    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnEntrar;

    @FXML
    private TextField txtUsuario;

    @FXML
    private PasswordField txtSenha;
    private static Stage stage;

    @FXML
    void btnCancelar(final ActionEvent event) {

	Platform.exit();
    }

    @FXML
    void btnEntrar(final ActionEvent event) {
	if (txtUsuario.getText().isBlank() || txtSenha.getText().isBlank()) {
	    Alerta.alertaCampoNulo();
	} else {
	    final var usuario = new Usuario();
	    usuario.setNome(txtUsuario.getText());
	    usuario.setSenha(txtSenha.getText());
	    final var login = new NegLogin();
	    try {
		if (login.verificaLogin(usuario)) {

		    stage.close();
		    abreTelaMenuPrincipal();
		} else {
		    Alerta.alertaUsuarioNaoExiste();
		}
	    } catch (final SQLException e) {
		Alerta.alertaErro(e.getMessage());

	    }
	}
    }

    @Override
    public void start(final Stage primaryStage) throws Exception {
	stage = primaryStage;
	abreTelaLogin();
    }

    private void abreTelaLogin() {

	try {
	    final var root = (AnchorPane) FXMLLoader.load(getClass().getResource("telaLogin.fxml"));
	    final var scene = new Scene(root);
	    stage.setTitle("ECOMM");
	    stage.setScene(scene);
	    stage.show();

	} catch (final IOException e) {
	    System.out.println(e.getMessage());
	}
    }

    private void abreTelaMenuPrincipal() {
	try {
	    final var root = (AnchorPane) FXMLLoader.load(getClass().getResource("menuPrincipal.fxml"));
	    final var scene = new Scene(root, 500, 500);
	    stage.setTitle("ECOMM");
	    stage.setMinHeight(600);
	    stage.setMinWidth(600);
	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }
}
