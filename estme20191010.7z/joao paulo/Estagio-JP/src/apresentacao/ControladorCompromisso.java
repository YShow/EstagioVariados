package apresentacao;

import java.io.IOException;
import java.sql.SQLException;

import apresentacao.insere.ControladorInsereCompromisso;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegCompromisso;
import objeto.Compromisso;
import utilidade.Alerta;
import utilidade.TIPO_TELA;

public class ControladorCompromisso {
    @FXML
    private TextArea txtPesquisa;

    @FXML
    private TableView<Compromisso> tvCompromisso;

    @FXML
    private TableColumn<Compromisso, String> tcNome;

    @FXML
    private TableColumn<Compromisso, String> tcDescricao;

    @FXML
    private TableColumn<Compromisso, String> tcHora;

    @FXML
    private TableColumn<Compromisso, String> tcDia;

    @FXML
    private TableColumn<Compromisso, String> tcDuracao;

    @FXML
    private TableColumn<Compromisso, Boolean> tcRealizado;
    @FXML
    private TableColumn<Compromisso, Integer> tcCliente;
    @FXML
    private TableColumn<Compromisso, Integer> tcCodigo;

    private final ControladorInsereCompromisso insereComp = new ControladorInsereCompromisso();

    private final NegCompromisso negComp = new NegCompromisso();

    public void abreTelaCompromisso() {
	final var stage = new Stage();
	Parent root;
	final var loader = new FXMLLoader();
	stage.initModality(Modality.APPLICATION_MODAL);

	try {
	    loader.setLocation(getClass().getClassLoader().getResource("apresentacao/CompromissoConsulta.fxml"));
	    root = loader.load();
	    final var scene = new Scene(root);

	    stage.setScene(scene);
	    stage.show();
	} catch (final IOException e) {
	    Alerta.alertaErro(e.getMessage());
	}

    }

    @FXML
    void btnAlterar(final ActionEvent event) {
	final var comp = tvCompromisso.getSelectionModel().getSelectedItem();
	insereComp.abreTelaCompromisso(TIPO_TELA.ALTERA, comp);
    }

    @FXML
    void btnConsultar(final ActionEvent event) {
	try {
	    final var comp = negComp.consultar(txtPesquisa.getText());
	    if (!comp.isEmpty()) {
		tcDescricao.setCellValueFactory(new PropertyValueFactory<Compromisso, String>("descricao"));
		tcDia.setCellValueFactory(new PropertyValueFactory<Compromisso, String>("dia"));
		tcDuracao.setCellValueFactory(new PropertyValueFactory<Compromisso, String>("duracao"));
		tcHora.setCellValueFactory(new PropertyValueFactory<Compromisso, String>("hora"));
		tcNome.setCellValueFactory(new PropertyValueFactory<Compromisso, String>("nome"));
		tcRealizado.setCellValueFactory(new PropertyValueFactory<Compromisso, Boolean>("realizado"));
		tcCliente.setCellValueFactory(
			cliente -> new ReadOnlyIntegerWrapper(cliente.getValue().getPessoa().getId()).asObject());
		tcCodigo.setCellValueFactory(new PropertyValueFactory<Compromisso, Integer>("id"));
		final var data = FXCollections.observableArrayList(comp);
		tvCompromisso.setItems(data);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnExcluir(final ActionEvent event) {
	final var comp = tvCompromisso.getSelectionModel().getSelectedItem();

	try {
	    if (negComp.excluir(comp.getId())) {
		Alerta.alertaSucesso();
		tvCompromisso.getItems().remove(comp);
	    }
	} catch (final SQLException e) {
	    Alerta.alertaErro(e.getMessage());
	}
    }

    @FXML
    void btnInserir(final ActionEvent event) {
	insereComp.abreTelaCompromisso(TIPO_TELA.INSERE, null);
    }

}
