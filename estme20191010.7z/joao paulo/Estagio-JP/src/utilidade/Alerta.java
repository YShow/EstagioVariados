package utilidade;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

public class Alerta {



    public static void alertaSucesso() {
	final Alert alerta = new Alert(Alert.AlertType.NONE);
	alerta.setAlertType(AlertType.INFORMATION);
	alerta.setTitle("Função realizada com sucesso");
	alerta.setHeaderText("");
	alerta.setHeight(300);
	alerta.setWidth(300);
	alerta.show();

    }

    public static void alertaErro(final String erro) {
	final Alert alerta = new Alert(Alert.AlertType.NONE);
	alerta.setAlertType(AlertType.WARNING);
	alerta.setTitle("Ocorreu um problema");
	alerta.setHeaderText("Verifique os campos e informe o erro ao desenvolvedor");
	alerta.setContentText("Erro: " + erro);
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	alerta.show();

    }

    public static void alertaCampoNulo() {
	final Alert alerta = new Alert(Alert.AlertType.NONE);
	alerta.setAlertType(AlertType.INFORMATION);
	alerta.setHeaderText("Verifique os campos");
	alerta.setContentText("Por favor verifique se todos os campos foram preenchidos");
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	alerta.show();
    }

    public static void alertaUsuarioNaoExiste() {
	final Alert alerta = new Alert(Alert.AlertType.NONE);
	alerta.setAlertType(AlertType.INFORMATION);
	alerta.setHeaderText("Confirme os campos");
	alerta.setContentText("Este usuario não existe");
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	alerta.show();
    }

    public static void alertaCustomizado(final String header, final String text) {
	final Alert alerta = new Alert(Alert.AlertType.NONE);
	alerta.setAlertType(AlertType.INFORMATION);
	alerta.setHeaderText(header);
	alerta.setContentText(text);
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	alerta.show();
    }

    public static void alertaClienteEmCaixa() {
	final Alert alerta = new Alert(Alert.AlertType.NONE);
	alerta.setAlertType(AlertType.WARNING);
	alerta.setHeaderText("Cliente possui caixa");
	alerta.setContentText("Não é possivel desativar este cliente ele ja possui um caixa");
	alerta.setResult(ButtonType.OK);
	alerta.setHeight(300);
	alerta.setWidth(300);
	alerta.show();
    }

}
