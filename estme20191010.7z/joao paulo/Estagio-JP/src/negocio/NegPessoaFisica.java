package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Endereco;
import objeto.PessoaFisica;
import objeto.Telefone;

public class NegPessoaFisica {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "INSERT into pessoa_fisica(pessoa_fisica.cpf,pessoa_fisica.nome,pessoa_fisica.rg) VALUES(?,?,?)";
    private static final String SQL_SEARCH = "SELECT pf.nome, pf.rg, pf.cpf, pf.pessoa_codigo,p.ativo "
	    + "FROM ecom.pessoa_fisica pf JOIN pessoa p on p.codigo = pf.pessoa_codigo" + " WHERE pf.cpf LIKE ?;";
    private static final String SQL_UPDATE = "UPDATE ecom.pessoa_fisica pf JOIN pessoa p on p.codigo = pf.pessoa_codigo\n" +
    	"SET pf.nome= ?, pf.rg= ?, pf.cpf= ?, p.ativo = ?\n" +
    	"where pf.pessoa_codigo = ?;";
    private static final String SQL_DELETE = "UPDATE ecom.pessoa SET ativo=false WHERE codigo= ?;";
    private static final String SQL_INSERT_TELEFONE = "INSERT into telefone(ddd,fixo,movel,codigo_pessoa) VALUES (?,?,?,?)";
    private static final String SQL_INSERT_ENDERECO = "INSERT into endereco(numero,cidade,bairro,complemento,rua,estado,cep,codigo_pessoa)"
	    + " VALUES (?,?,?,?,?,?,?,?)";

    public boolean inserir(final PessoaFisica pessoaFisica, final List<Telefone> telefone,
	    final List<Endereco> endereco) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT);
	final var telefoneinsere = con.prepareStatement(SQL_INSERT_TELEFONE);
	final var enderecoInsere = con.prepareStatement(SQL_INSERT_ENDERECO);
	final var codCliente = con.prepareStatement("select MAX(codigo) from pessoa");
	con.setAutoCommit(false);
	try (con; comando; telefoneinsere; enderecoInsere;) {
	    comando.setString(1, pessoaFisica.getCPF());
	    comando.setString(2, pessoaFisica.getNome());
	    comando.setString(3, pessoaFisica.getRG());

	    int inseriu = 0;
	    if (comando.executeUpdate() >= 1) {
		final var id = codCliente.executeQuery();
		if (id.next()) {
		    final var codigoCliente = id.getInt(1);
		    System.out.println(codigoCliente);
		    for (final var telefonesing : telefone) {
			// (ddd,fixo,movel,codigo_pessoa)
			telefoneinsere.setString(1, telefonesing.getDdd());
			telefoneinsere.setString(2, telefonesing.getFixo());
			telefoneinsere.setString(3, telefonesing.getMovel());
			telefoneinsere.setInt(4, codigoCliente);

			telefoneinsere.addBatch();
		    }
		    inseriu += telefoneinsere.executeBatch().length;

		    // (numero,cidade,bairro,complemento,rua,estado,cep,codigo_pessoa)
		    for (final var enderecosing : endereco) {
			enderecoInsere.setInt(1, enderecosing.getNumero());
			enderecoInsere.setString(2, enderecosing.getCidade());
			enderecoInsere.setString(3, enderecosing.getBairro());
			enderecoInsere.setString(4, enderecosing.getComplemento());
			enderecoInsere.setString(5, enderecosing.getRua());
			enderecoInsere.setString(6, enderecosing.getRua());
			enderecoInsere.setString(7, enderecosing.getEstado());
			enderecoInsere.setInt(8, codigoCliente);
			enderecoInsere.addBatch();
		    }
		    inseriu += enderecoInsere.executeBatch().length;
		}
	    }

	    con.commit();
	    System.out.println(inseriu);
	    return inseriu >= 1;

	}
    }

    public List<PessoaFisica> consultar(final String metodo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, '%' + metodo + '%');
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<PessoaFisica>();
	    while (result.next()) {
		final var pessoaFisica = new PessoaFisica();
		pessoaFisica.setRG(result.getString("pf.rg"));
		pessoaFisica.setCPF(result.getString("pf.cpf"));
		pessoaFisica.setAtivo(result.getBoolean("p.ativo"));
		pessoaFisica.setId(result.getInt("pf.pessoa_codigo"));
		pessoaFisica.setNome(result.getString("pf.nome"));
		lista.add(pessoaFisica);
	    }
	    return lista;
	}
    }

    public boolean alterar(final PessoaFisica pessoaFisica) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_UPDATE)) {


	    /*
	     * UPDATE ecom.pessoa_fisica pf JOIN pessoa p on p.codigo = pf.pessoa_codigo
SET pf.nome= ?, pf.rg= ?, pf.cpf= ?, p.ativo = ?
where pf.pessoa_codigo = ?*/
	    comando.setString(1, pessoaFisica.getNome());
	    comando.setString(2, pessoaFisica.getRG());
	    comando.setString(3, pessoaFisica.getCPF());
	    comando.setBoolean(4, pessoaFisica.isAtivo());
	    comando.setInt(5, pessoaFisica.getId());

	    return comando.executeUpdate() >= 1;
	}
    }

    public boolean excluir(final int id) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    comando.setInt(1, id);
	    return comando.executeUpdate() >= 1;
	}
    }
}
