package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Endereco;
import objeto.Telefone;
import objeto.Usuario;

public class NegUsuario {

    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "INSERT INTO ecom.usuario\n"
	    + "(cpf, nome, ativo, rg, senha, administrador) " + "VALUES(?, ?, ?, ?,?, ?);";
    private static final String SQL_SEARCH = "SELECT codigo, cpf, nome, ativo, rg, senha, administrador\n"
	    + "FROM ecom.usuario where cpf LIKE ?";
    private static final String SQL_UPDATE = "UPDATE ecom.usuario\n"
	    + "SET cpf=?, nome=?, ativo= ?, rg= ?, senha= ?, administrador= ?\n" + "WHERE codigo= ?;";
    private static final String SQL_DELETE = "DELETE FROM ecom.usuario\n" + "WHERE codigo = ?;";
    private static final String SQL_INSERT_TELEFONE = "INSERT into telefone(ddd,fixo,movel,codigo_usuario) VALUES (?,?,?,?)";
    private static final String SQL_INSERT_ENDERECO = "INSERT into endereco(numero,cidade,bairro,complemento,rua,estado,cep,codigo_usuario)"
	    + " VALUES (?,?,?,?,?,?,?,?)";

    public boolean inserir(final Usuario usuario, final List<Endereco> enderecos, final List<Telefone> telefones)
	    throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
	final var comandoInsereTelefone = con.prepareStatement(SQL_INSERT_TELEFONE);
	final var comandoInsereEndereco = con.prepareStatement(SQL_INSERT_ENDERECO);
	try (con; comando; comandoInsereEndereco; comandoInsereTelefone) {

	    comando.setString(1, usuario.getCpf());
	    comando.setString(2, usuario.getNome());
	    comando.setBoolean(3, usuario.getAtivo());
	    comando.setString(4, usuario.getRg());
	    comando.setString(5, usuario.getSenha());
	    comando.setBoolean(6, usuario.getAdm());
	    comando.executeUpdate();
	    final var idUsuario = comando.getGeneratedKeys();
	    int inseriu[] = null;
	    if (idUsuario.next()) {
		final var cod_usuario = idUsuario.getInt(1);
		for (final var telefone : telefones) {
		    /* "INSERT into telefone(ddd,fixo,movel,codigo_usuario) VALUES (?,?,?,?)"; */
		    comandoInsereTelefone.setString(1, telefone.getDdd());
		    comandoInsereTelefone.setString(2, telefone.getFixo());
		    comandoInsereTelefone.setString(3, telefone.getMovel());
		    comandoInsereTelefone.setInt(4, cod_usuario);
		    comandoInsereTelefone.addBatch();
		}
		comandoInsereTelefone.executeBatch();

		for (final var endereco : enderecos) {
		    /*
		     * "INSERT into
		     * endereco(numero,cidade,bairro,complemento,rua,estado,cep,codigo_usuario)
		     */
		    comandoInsereEndereco.setInt(1, endereco.getNumero());
		    comandoInsereEndereco.setString(2, endereco.getCidade());
		    comandoInsereEndereco.setString(3, endereco.getBairro());
		    comandoInsereEndereco.setString(4, endereco.getComplemento());
		    comandoInsereEndereco.setString(5, endereco.getRua());
		    comandoInsereEndereco.setString(6, endereco.getEstado());
		    comandoInsereEndereco.setString(7, endereco.getCep());
		    comandoInsereEndereco.setInt(8, cod_usuario);
		}
		inseriu = comandoInsereEndereco.executeBatch();
	    }

	    return inseriu.length >= 1;
	}
    }

    public List<Usuario> consultar(final String metodo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, '%' + metodo + '%');
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<Usuario>();
	    while (result.next()) {
		final var usuario = new Usuario();
		usuario.setId(result.getInt("codigo"));
		usuario.setCpf(result.getString("cpf"));
		usuario.setAtivo(result.getBoolean("ativo"));
		usuario.setNome(result.getString("nome"));
		usuario.setRg(result.getString("rg"));
		usuario.setSenha(result.getString("senha"));
		usuario.setAdm(result.getBoolean("administrador"));
		lista.add(usuario);
	    }
	    return lista;
	}
    }

    public boolean alterar(final Usuario usuario, final List<Telefone> telefones, final List<Endereco> enderecos)
	    throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_UPDATE);
	final var comandoInsereTelefone = con.prepareStatement(SQL_INSERT_TELEFONE);
	final var comandoInsereEndereco = con.prepareStatement(SQL_INSERT_ENDERECO);
	final var tiraEndereco = con.prepareStatement("DELETE from ecom.endereco WHERE codigo_usuario = ?");
	final var tiraTel = con.prepareStatement("delete from ecom.telefone where codigo_usuario= ?");
	try (con; comando; comandoInsereEndereco; comandoInsereTelefone; tiraEndereco; tiraTel;) {

	    comando.setString(1, usuario.getCpf());
	    comando.setString(2, usuario.getNome());
	    comando.setBoolean(3, usuario.getAtivo());
	    comando.setString(4, usuario.getRg());
	    comando.setString(5, usuario.getSenha());
	    comando.setBoolean(6, usuario.getAdm());
	    comando.setInt(7, usuario.getId());

	    comando.executeUpdate();

	    tiraTel.setInt(1, usuario.getId());
	    tiraTel.executeUpdate();
	    for (final var telefone : telefones) {
		/* "INSERT into telefone(ddd,fixo,movel,codigo_usuario) VALUES (?,?,?,?)"; */
		comandoInsereTelefone.setString(1, telefone.getDdd());
		comandoInsereTelefone.setString(2, telefone.getFixo());
		comandoInsereTelefone.setString(3, telefone.getMovel());
		comandoInsereTelefone.setInt(4, usuario.getId());
		comandoInsereTelefone.addBatch();
	    }
	    comandoInsereTelefone.executeBatch();

	    tiraEndereco.setInt(1, usuario.getId());
	    tiraEndereco.executeUpdate();
	    for (final var endereco : enderecos) {
		/*
		 * "INSERT into
		 * endereco(numero,cidade,bairro,complemento,rua,estado,cep,codigo_usuario)
		 */
		comandoInsereEndereco.setInt(1, endereco.getNumero());
		comandoInsereEndereco.setString(2, endereco.getCidade());
		comandoInsereEndereco.setString(3, endereco.getBairro());
		comandoInsereEndereco.setString(4, endereco.getComplemento());
		comandoInsereEndereco.setString(5, endereco.getRua());
		comandoInsereEndereco.setString(6, endereco.getEstado());
		comandoInsereEndereco.setString(7, endereco.getCep());
		comandoInsereEndereco.setInt(8, usuario.getId());
		comandoInsereEndereco.addBatch();
	    }
	    final var inseriu = comandoInsereEndereco.executeBatch();

	    return inseriu.length >= 1;
	}
    }

    public boolean excluir(final int id) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    comando.setInt(1, id);
	    return comando.executeUpdate() >= 1;
	}
    }
}
