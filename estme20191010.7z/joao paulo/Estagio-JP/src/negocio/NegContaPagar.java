package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.ContasPagar;
import objeto.PessoaJuridica;

public class NegContaPagar {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "INSERT into conta(descricao,valor,data_pagamento,vencimento,tipo,ativo)\n"
	    + "values(?,?,?,?,?,?)";

    private static final String SQL_INSERT_PAG = "INSERT into contas_a_pagar(codigo_conta,codigo_pessoa) values(?,?)";

    private static final String SQL_SEARCH = "SELECT c.ativo,c.codigo,c.descricao,c.valor,c.data_pagamento,c.vencimento,c.tipo,pj.nome,pj.pessoa_codigo  from contas_a_pagar cp\n"
	    + "JOIN conta c on c.codigo = cp.codigo_conta\n"
	    + "JOIN pessoa_juridica pj on pj.pessoa_codigo = cp.codigo_pessoa\n" + "WHERE pj.cnpj like ?";
    private static final String SQL_UPDATE = "UPDATE conta SET descricao =?, valor=?,data_pagamento=?,vencimento=?,tipo=?,ativo = ?\n"
	    + "WHERE codigo = ?";
    private static final String SQL_DELETE = "UPDATE conta SET ativo = false\n" + "WHERE codigo = ?";

    public boolean inserir(final ContasPagar contaPagar) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
	final var pagConta = con.prepareStatement(SQL_INSERT_PAG);
	try (con; comando; pagConta;) {
	    con.setAutoCommit(false);
	    /*
	     * INSERT into conta(descricao,valor,data_pagamento,vencimento,tipo,ativo)\n" +
	     * "values(?,?,?,?,?,true)
	     */
	    comando.setString(1, contaPagar.getDescricao());
	    comando.setFloat(2, contaPagar.getValor());
	    comando.setObject(3, contaPagar.getDataPagamento());
	    comando.setObject(4, contaPagar.getVencimento());
	    comando.setString(5, contaPagar.getTipo());
	    comando.setBoolean(6, contaPagar.isAtivo());

	    comando.executeUpdate();
	    final var id = comando.getGeneratedKeys();
	    int chave = 0;
	    var inseriu = false;
	    if (id.next()) {

		/* INSERT into contas_a_pagar(codigo_conta,codigo_pessoa) values(?,?) */
		chave = id.getInt(1);
		pagConta.setInt(1, chave);
		pagConta.setInt(2, contaPagar.getPessoaJuridica().getId());
		pagConta.executeUpdate();
		inseriu = true;
	    }

	    con.commit();

	    return inseriu;
	}
    }

    public List<ContasPagar> consultar(final String metodo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, metodo + '%');
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<ContasPagar>();
	    while (result.next()) {
		/* c.descricao,c.valor,c.data_pagamento,c.vencimento,c.tipo,pj.nome */
		final var contaPagar = new ContasPagar();
		contaPagar.setDescricao(result.getString("c.descricao"));
		contaPagar.setValor(result.getFloat("c.valor"));
		contaPagar.setDataPagamento(result.getObject("c.data_pagamento", LocalDate.class));
		contaPagar.setVencimento(result.getObject("c.vencimento", LocalDate.class));
		contaPagar.setTipo(result.getString("c.tipo"));
		contaPagar.setId(result.getInt("c.codigo"));
		contaPagar.setAtivo(result.getBoolean("c.ativo"));
		final var pessoaJuridica = new PessoaJuridica();
		pessoaJuridica.setNomeFantasia(result.getString("pj.nome"));
		pessoaJuridica.setId(result.getInt("pj.pessoa_codigo"));
		contaPagar.setPessoaJuridica(pessoaJuridica);

		lista.add(contaPagar);
	    }
	    return lista;
	}
    }

    public boolean alterar(final ContasPagar contaPagar) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_UPDATE);
	try (con; comando;) {
	    /*
	     * UPDATE conta SET descricao =?,
	     * valor=?,data_pagamento=?,vencimento=?,tipo=?\n" + "WHERE codigo = ?
	     */
	    comando.setString(1, contaPagar.getDescricao());
	    comando.setFloat(2, contaPagar.getValor());
	    comando.setObject(3, contaPagar.getDataPagamento());
	    comando.setObject(4, contaPagar.getVencimento());
	    comando.setString(5, contaPagar.getTipo());
	    comando.setBoolean(6, contaPagar.isAtivo());
	    comando.setInt(7, contaPagar.getId());

	    return comando.executeUpdate() >= 1;
	}
    }

    public boolean excluir(final int codigo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    comando.setInt(1, codigo);
	    return comando.executeUpdate() >= 1;
	}
    }
}
