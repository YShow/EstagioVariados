package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Endereco;
import objeto.Telefone;

public class NegTelefoneEndereco {
    private final AcessoBD conexao = new AcessoBD();
    private final static String SQL_PESQUISA_TELEFONE_USUARIO = "SELECT ddd, fixo, id, movel\n"
	    + "FROM ecom.telefone \n" + "WHERE codigo_usuario = ?;\n";
    private final static String SQL_PESQUISA_TELEFONE_PESSOA = "SELECT ddd, fixo, id, movel\n" + "FROM ecom.telefone \n"
	    + "WHERE codigo_pessoa = ?;\n";

    private final static String SQL_PESQUISA_ENDERECO_USUARIO = "SELECT numero, cidade, bairro, complemento, rua, estado, cep \n"
	    + "FROM ecom.endereco\n" + "where codigo_usuario = ?;\n";
    private final static String SQL_PESQUISA_ENDERECO_PESSOA = "SELECT numero, cidade, bairro, complemento, rua, estado, cep"
	    + " FROM ecom.endereco where codigo_pessoa = ?;";

    public List<Telefone> pegaTelefonesUsuario(final int idUsuario) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_PESQUISA_TELEFONE_USUARIO);
	try (con; comando;) {
	    comando.setInt(1, idUsuario);
	    final var result = comando.executeQuery();
	    final var telefones = new ArrayList<Telefone>();
	    while (result.next()) {
		final var tel = new Telefone();
		tel.setDdd(result.getString("ddd"));
		tel.setFixo(result.getString("fixo"));
		tel.setMovel(result.getString("movel"));
		telefones.add(tel);
	    }
	    return telefones;
	}
    }

    public List<Telefone> pegaTelefonesPessoa(final int idPessoa) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_PESQUISA_TELEFONE_PESSOA);
	try (con; comando;) {
	    comando.setInt(1, idPessoa);
	    final var result = comando.executeQuery();
	    final var telefones = new ArrayList<Telefone>();
	    while (result.next()) {
		final var tel = new Telefone();
		tel.setDdd(result.getString("ddd"));
		tel.setFixo(result.getString("fixo"));
		tel.setId(result.getInt("id"));
		tel.setMovel(result.getString("movel"));
		telefones.add(tel);
	    }
	    return telefones;
	}
    }

    public List<Endereco> pegaEnderecoUsuario(final int idUsuario) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_PESQUISA_ENDERECO_USUARIO);
	try (con; comando;) {
	    comando.setInt(1, idUsuario);
	    final var result = comando.executeQuery();
	    final var enderecos = new ArrayList<Endereco>();
	    while (result.next()) {
		final var end = new Endereco();
		/*
		 * numero, cidade, bairro, complemento, rua, estado, cep, id\n" +
		 */
		end.setNumero(result.getInt("numero"));
		end.setCidade(result.getString("cidade"));
		end.setBairro(result.getString("bairro"));
		end.setComplemento(result.getString("complemento"));
		end.setRua(result.getString("rua"));
		end.setEstado(result.getString("estado"));
		end.setCep(result.getString("cep"));

		enderecos.add(end);

	    }

	    return enderecos;
	}

    }

    public List<Endereco> pegaEnderecoPessoa(final int idpessoa) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_PESQUISA_ENDERECO_PESSOA);
	try (con; comando;) {
	    comando.setInt(1, idpessoa);
	    final var result = comando.executeQuery();
	    final var enderecos = new ArrayList<Endereco>();
	    while (result.next()) {
		final var end = new Endereco();
		/*
		 * numero, cidade, bairro, complemento, rua, estado, cep, id\n" +
		 */
		end.setNumero(result.getInt("numero"));
		end.setCidade(result.getString("cidade"));
		end.setBairro(result.getString("bairro"));
		end.setComplemento(result.getString("complemento"));
		end.setRua(result.getString("rua"));
		end.setEstado(result.getString("estado"));
		end.setCep(result.getString("cep"));

		enderecos.add(end);

	    }

	    return enderecos;
	}

    }
}
