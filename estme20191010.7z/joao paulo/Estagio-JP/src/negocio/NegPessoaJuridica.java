package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Endereco;
import objeto.PessoaJuridica;
import objeto.Telefone;

public class NegPessoaJuridica {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "INSERT into pessoa_juridica(cnpj,inscricao_estadual,nome,razao_social)"
	    + "values(?,?,?,?)";
    private static final String SQL_SEARCH = "SELECT pj.cnpj, pj.nome, pj.inscricao_estadual, pj.razao_social, pj.pessoa_codigo, p.ativo\n"
	    + "FROM ecom.pessoa_juridica pj\n" + "join pessoa p on p.codigo = pj.pessoa_codigo\n"
	    + "WHERE cnpj LIKE ?;";
    private static final String SQL_UPDATE = "UPDATE ecom.pessoa_juridica pj\n" +
    	"JOIN pessoa p on p.codigo = pj.pessoa_codigo\n" +
    	"SET pj.cnpj=?, pj.nome=?, pj.inscricao_estadual=?, pj.razao_social=?,p.ativo = ?\n" +
    	"where pj.pessoa_codigo = ?";
    private static final String SQL_DELETE = "UPDATE ecom.pessoa p\n"
	    + "LEFT JOIN pessoa_juridica pj ON p.codigo = pj.pessoa_codigo\n" + "SET p.ativo = ? "
	    + "where p.codigo = ?;";
    private static final String SQL_INSERT_TELEFONE = "INSERT into telefone(ddd,fixo,movel,codigo_pessoa) VALUES (?,?,?,?)";
    private static final String SQL_INSERT_ENDERECO = "INSERT into endereco(numero,cidade,bairro,complemento,rua,estado,cep,codigo_pessoa)"
	    + " VALUES (?,?,?,?,?,?,?,?)";

    private static final String SQL_SEARCH_PESSOA_TELEFONE = "SELECT ddd,fixo,movel from telefone\n"
	    + "where codigo_pessoa = ?";

    private static final String SQL_SEARCH_PESSOA_ENDERECO = "SELECT bairro,cep,cidade,complemento,estado,numero,rua from endereco\n"
	    + "where codigo_pessoa = ?";

    public boolean inserir(final PessoaJuridica pessoaJuridica, final List<Telefone> telefone,
	    final List<Endereco> endereco) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
	final var telefoneinsere = con.prepareStatement(SQL_INSERT_TELEFONE);
	final var enderecoInsere = con.prepareStatement(SQL_INSERT_ENDERECO);
	final var codCliente = con.prepareStatement("select MAX(codigo) from pessoa");
	con.setAutoCommit(false);
	try (con; comando; telefoneinsere; enderecoInsere; codCliente) {

	    comando.setString(1, pessoaJuridica.getCnpj());
	    comando.setString(2, pessoaJuridica.getInscricaoEstadual());
	    comando.setString(3, pessoaJuridica.getNomeFantasia());
	    comando.setString(4, pessoaJuridica.getRazaoSocial());



	    int inseriu = 0;
	    if (comando.executeUpdate() >= 1) {
		final var id = codCliente.executeQuery();
		if (id.next()) {
		    final var codigoCliente = id.getInt(1);
		    System.out.println(codigoCliente);
		    for (final var telefonesing : telefone) {
			// (ddd,fixo,movel,codigo_pessoa)
			telefoneinsere.setString(1, telefonesing.getDdd());
			telefoneinsere.setString(2, telefonesing.getFixo());
			telefoneinsere.setString(3, telefonesing.getMovel());
			telefoneinsere.setInt(4, codigoCliente);

			telefoneinsere.addBatch();
		    }
		    inseriu += telefoneinsere.executeBatch().length;

		    // (numero,cidade,bairro,complemento,rua,estado,cep,codigo_pessoa)
		    for (final var enderecosing : endereco) {
			enderecoInsere.setInt(1, enderecosing.getNumero());
			enderecoInsere.setString(2, enderecosing.getCidade());
			enderecoInsere.setString(3, enderecosing.getBairro());
			enderecoInsere.setString(4, enderecosing.getComplemento());
			enderecoInsere.setString(5, enderecosing.getRua());
			enderecoInsere.setString(6, enderecosing.getRua());
			enderecoInsere.setString(7, enderecosing.getEstado());
			enderecoInsere.setInt(8, codigoCliente);
			enderecoInsere.addBatch();
		    }
		    inseriu += enderecoInsere.executeBatch().length;
		}
	    }

	    con.commit();
	    System.out.println(inseriu);
	    return inseriu >= 1;
	}
    }

    public List<PessoaJuridica> consultar(final String metodo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, '%' + metodo + '%');
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<PessoaJuridica>();
	    while (result.next()) {
		/*
		 * "SELECT cnpj, nome, inscricao_estadual, razao_social, pessoa_codigo\n" +
		 * "FROM ecom.pessoa_juridica WHERE cnpj = ?;"
		 */
		final var pessoaJuridica = new PessoaJuridica();
		pessoaJuridica.setCnpj(result.getString("pj.cnpj"));
		pessoaJuridica.setNomeFantasia(result.getString("pj.nome"));
		pessoaJuridica.setInscricaoEstadual(result.getString("pj.inscricao_estadual"));
		pessoaJuridica.setRazaoSocial(result.getString("pj.razao_social"));
		pessoaJuridica.setId(result.getInt("pj.pessoa_codigo"));
		pessoaJuridica.setAtivo(result.getBoolean("p.ativo"));

		lista.add(pessoaJuridica);
	    }
	    return lista;
	}
    }

    public boolean alterar(final PessoaJuridica pessoaJuridica, final List<Telefone> telefone,
	    final List<Endereco> endereco) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_UPDATE);
	final var deletaTel = con.prepareStatement("DELETE from telefone where codigo_pessoa = ?");
	final var deletaEnde = con.prepareStatement("DELETE FROM endereco where codigo_pessoa = ?");
	final var telefoneinsere = con.prepareStatement(SQL_INSERT_TELEFONE);
	final var enderecoInsere = con.prepareStatement(SQL_INSERT_ENDERECO);
	try (con; comando; deletaEnde; deletaTel; enderecoInsere; telefoneinsere) {
	    con.setAutoCommit(false);
	  /*
	   * UPDATE ecom.pessoa_juridica pj
JOIN pessoa p on p.codigo = pj.pessoa_codigo
SET pj.cnpj=?, pj.nome=?, pj.inscricao_estadual=?, pj.razao_social=?,p.ativo = ?
where pj.pessoa_codigo = ?*/
	    comando.setString(1, pessoaJuridica.getCnpj());
	    comando.setString(2, pessoaJuridica.getNomeFantasia());
	    comando.setString(3, pessoaJuridica.getInscricaoEstadual());
	    comando.setString(4, pessoaJuridica.getRazaoSocial());
	    comando.setBoolean(5, pessoaJuridica.isAtivo());
	    comando.setInt(6, pessoaJuridica.getId());
	    comando.executeUpdate();

	    deletaTel.setInt(1, pessoaJuridica.getId());
	    deletaTel.executeUpdate();
	    deletaEnde.setInt(1, pessoaJuridica.getId());
	    deletaEnde.executeUpdate();
	    final var codigoCliente = pessoaJuridica.getId();
	    int inseriu = 0;
	    System.out.println(codigoCliente);
	    for (final var telefonesing : telefone) {
		// (ddd,fixo,movel,codigo_pessoa)
		telefoneinsere.setString(1, telefonesing.getDdd());
		telefoneinsere.setString(2, telefonesing.getFixo());
		telefoneinsere.setString(3, telefonesing.getMovel());
		telefoneinsere.setInt(4, codigoCliente);

		telefoneinsere.addBatch();
	    }
	    inseriu += telefoneinsere.executeBatch().length;

	    // (numero,cidade,bairro,complemento,rua,estado,cep,codigo_pessoa)
	    for (final var enderecosing : endereco) {
		enderecoInsere.setInt(1, enderecosing.getNumero());
		enderecoInsere.setString(2, enderecosing.getCidade());
		enderecoInsere.setString(3, enderecosing.getBairro());
		enderecoInsere.setString(4, enderecosing.getComplemento());
		enderecoInsere.setString(5, enderecosing.getRua());
		enderecoInsere.setString(6, enderecosing.getRua());
		enderecoInsere.setString(7, enderecosing.getEstado());
		enderecoInsere.setInt(8, codigoCliente);
		enderecoInsere.addBatch();
	    }
	    inseriu += enderecoInsere.executeBatch().length;

	    con.commit();
	    return inseriu >= 1;
	}
    }

    public boolean excluir(final int codigo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    comando.setBoolean(1, false);
	    comando.setInt(2, codigo);
	    return comando.executeUpdate() >= 1;
	}
    }

    public List<Telefone> pegaTelefone(final int idPessoa) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH_PESSOA_TELEFONE)) {
	    comando.setInt(1, idPessoa);
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<Telefone>();
	    while (result.next()) {

		final var telefone = new Telefone();
		telefone.setDdd(result.getString("ddd"));
		telefone.setFixo(result.getString("fixo"));
		telefone.setMovel(result.getString("movel"));

		lista.add(telefone);
	    }
	    return lista;
	}
    }

    public List<Endereco> pegaEndereco(final int idPessoa) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH_PESSOA_ENDERECO)) {
	    comando.setInt(1, idPessoa);
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<Endereco>();
	    while (result.next()) {

		// SELECT bairro,cep,cidade,complemento,estado,numero,rua from endereco
		final var endereco = new Endereco();
		// telefone.setDdd(result.getString("ddd"));
		endereco.setBairro(result.getString("bairro"));
		endereco.setCep(result.getString("cep"));
		endereco.setCidade(result.getString("cidade"));
		endereco.setComplemento(result.getString("complemento"));
		endereco.setEstado(result.getString("estado"));
		endereco.setNumero(result.getInt("numero"));
		endereco.setRua(result.getString("rua"));

		lista.add(endereco);
	    }
	    return lista;
	}
    }

}
