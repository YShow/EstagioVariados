package negocio;

import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.ContasReceber;
import objeto.PessoaFisica;

public class NegContaReceber {
    private final AcessoBD conexao = new AcessoBD();

    private static final String SQL_INSERT = "INSERT into conta(descricao,valor,data_pagamento,vencimento,tipo,ativo)\n"
	    + "values(?,?,?,?,?,?)";

    private static final String SQL_INSERT_PAG = "INSERT into contas_a_receber(codigo_conta,codigo_pessoa) values(?,?)";

    private static final String SQL_UPDATE = "UPDATE conta SET descricao =?, valor=?,data_pagamento=?,vencimento=?,tipo=?,ativo = ?\n"
	    + "WHERE codigo = ?";
    private static final String SQL_SEARCH = "SELECT c.ativo,c.codigo,c.descricao,c.valor,c.data_pagamento,c.vencimento,c.tipo,pj.nome,pj.pessoa_codigo\n"
	    + "from contas_a_receber cp\n" + "JOIN conta c on c.codigo = cp.codigo_conta\n"
	    + "JOIN pessoa_fisica pj on pj.pessoa_codigo = cp.codigo_pessoa " + " where pj.cpf like ?";
    private static final String SQL_DELETE = "UPDATE conta SET ativo = false WHERE codigo = ?";

    public boolean insereContaRecebe(final ContasReceber conta) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
	final var pagConta = con.prepareStatement(SQL_INSERT_PAG);
	try (con; comando;) {
	    comando.setString(1, conta.getDescricao());
	    comando.setFloat(2, conta.getValor());
	    comando.setObject(3, conta.getDataPagamento());
	    comando.setObject(4, conta.getVencimento());
	    comando.setString(5, conta.getTipo());
	    comando.setBoolean(6, conta.isAtivo());

	    comando.executeUpdate();
	    final var id = comando.getGeneratedKeys();
	    int chave = 0;
	    var inseriu = false;
	    if (id.next()) {

		/* INSERT into contas_a_pagar(codigo_conta,codigo_pessoa) values(?,?) */
		chave = id.getInt(1);
		pagConta.setInt(1, chave);
		pagConta.setInt(2, conta.getPessoaFisica().getId());
		inseriu = pagConta.executeUpdate() >= 1;

	    }

	    con.commit();

	    return inseriu;
	}
    }

    public List<ContasReceber> consultaContaReceber(final String cpf) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_SEARCH);
	try (con; comando;) {
	    comando.setString(1, cpf + '%');
	    final var result = comando.executeQuery();
	    final List<ContasReceber> contas = new ArrayList<>();
	    while (result.next()) {
		final var conta = new ContasReceber();
		/*
		 * SELECT c.ativo,c.codigo,c.descricao,c.valor,c.data_pagamento,c.vencimento
		 * ,c.tipo,pj.nome,pj.pessoa_codigo from contas_a_pagar cp JOIN conta c on
		 * c.codigo = cp.codigo_conta JOIN pessoa_fisica pj on pj.pessoa_codigo =
		 * cp.codigo_pessoa
		 */
		conta.setId(result.getInt("c.codigo"));
		conta.setAtivo(result.getBoolean("c.ativo"));
		conta.setDataPagamento(result.getObject("c.data_pagamento", LocalDate.class));
		conta.setDescricao(result.getString("c.descricao"));
		conta.setTipo(result.getString("c.tipo"));
		conta.setValor(result.getFloat("c.valor"));
		conta.setVencimento(result.getObject("c.vencimento", LocalDate.class));

		final var pessoaFisica = new PessoaFisica();

		pessoaFisica.setNome(result.getString("pj.nome"));
		pessoaFisica.setId(result.getInt("pj.pessoa_codigo"));
		conta.setPessoaFisica(pessoaFisica);

		contas.add(conta);
	    }
	    return contas;
	}
    }

    public boolean alteraContaReceber(final ContasReceber conta) throws SQLException {
	final var con = conexao.getConexao();
	final var comando = con.prepareStatement(SQL_UPDATE);
	try (con; comando;) {
	    /*
	     * UPDATE conta SET descricao =?,
	     * valor=?,data_pagamento=?,vencimento=?,tipo=?,ativo = ?\n" +
	     * "WHERE codigo = ?"
	     */
	    comando.setString(1, conta.getDescricao());
	    comando.setFloat(2, conta.getValor());
	    comando.setObject(3, conta.getDataPagamento());
	    comando.setObject(4, conta.getVencimento());
	    comando.setString(5, conta.getTipo());
	    comando.setBoolean(6, conta.isAtivo());
	    comando.setInt(7, conta.getId());
	    return comando.executeUpdate() >= 1;
	}

    }
    public boolean excluir(final int codigo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    comando.setInt(1, codigo);
	    return comando.executeUpdate() >= 1;
	}
    }
}
