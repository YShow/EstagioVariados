package negocio;

import java.sql.SQLException;

import acessoBD.MariaDB.AcessoBD;
import objeto.Usuario;

public class NegLogin {

    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_SEARCH = "SELECT nome, senha, administrador from usuario WHERE senha = ? and nome = ?;";

    public boolean verificaLogin(final Usuario usuario) throws SQLException {
	try (final var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, usuario.getSenha());
	    comando.setString(2, usuario.getNome());
	    final var resultado = comando.executeQuery();
	    if (resultado.next()) {
		final var usuarioPadrao = new Usuario();
		usuarioPadrao.setAdm(resultado.getBoolean("administrador"));
		Usuario.setUsuario(usuarioPadrao);
		return true;
	    } else {
		return false;
	    }
	}
    }
}
