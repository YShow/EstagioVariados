package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Compromisso;
import objeto.Pessoa;

public class NegCompromisso {
    private final AcessoBD conexao = new AcessoBD();
    private static final String SQL_INSERT = "INSERT INTO ecom.compromisso\n"
	    + "(hora, nome, duracao, realizado, descricao, dia, pessoa_codigo)\n" + "VALUES(?, ?, ?, ?, ?, ?, ?);";
    private static final String SQL_SEARCH = "SELECT hora, codigo, nome, duracao, realizado, descricao, dia, pessoa_codigo\n"
	    + "FROM ecom.compromisso WHERE nome like ? ;";
    private static final String SQL_UPDATE = "UPDATE ecom.compromisso\n"
	    + "SET hora=?, nome=?, duracao=?, realizado=?, descricao=?, dia=?, pessoa_codigo=?\n" + "WHERE codigo=?;";
    private static final String SQL_DELETE = "DELETE FROM ecom.compromisso\n" + "WHERE codigo= ?;";

    public boolean inserir(final Compromisso compromisso) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_INSERT)) {
	    comando.setString(1, compromisso.getHora());
	    comando.setString(2, compromisso.getNome());
	    comando.setFloat(3, compromisso.getDuracao());
	    comando.setBoolean(4, compromisso.getRealizado());
	    comando.setString(5, compromisso.getDescricao());
	    comando.setString(6, compromisso.getDia());
	    comando.setInt(7, compromisso.getPessoa().getId());

	    return comando.executeUpdate() >= 1;
	}
    }

    public List<Compromisso> consultar(final String metodo) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_SEARCH)) {
	    comando.setString(1, metodo + '%');
	    final var result = comando.executeQuery();
	    final var lista = new ArrayList<Compromisso>();
	    while (result.next()) {

		// "SELECT hora, codigo, nome, duracao, realizado, descricao, dia,
		// pessoa_codigo\n" +
		// "FROM ecom.compromisso WHERE nome = ?;"
		final var compromisso = new Compromisso();
		final var pessoa = new Pessoa();
		compromisso.setHora(result.getString("hora"));
		compromisso.setDescricao(result.getString("descricao"));
		compromisso.setDia(result.getString("dia"));
		compromisso.setDuracao(result.getFloat("duracao"));
		compromisso.setId(result.getInt("codigo"));
		compromisso.setNome(result.getString("nome"));
		pessoa.setId(result.getInt("pessoa_codigo"));
		compromisso.setPessoa(pessoa);
		compromisso.setRealizado(result.getBoolean("realizado"));
		lista.add(compromisso);
	    }
	    return lista;
	}
    }

    public boolean alterar(final Compromisso compromisso) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_UPDATE)) {
	    /*
	     * "UPDATE ecom.compromisso\n" +
	     * "SET hora=?, nome=?, duracao=?, realizado=?, descricao=?, dia=?, pessoa_codigo=?\n"
	     * + "WHERE codigo=?;"
	     */
	    comando.setString(1, compromisso.getHora());
	    comando.setString(2, compromisso.getNome());
	    comando.setFloat(3, compromisso.getDuracao());
	    comando.setBoolean(4, compromisso.getRealizado());
	    comando.setString(5, compromisso.getDescricao());
	    comando.setString(6, compromisso.getDia());
	    comando.setInt(7, compromisso.getPessoa().getId());
	    comando.setInt(8, compromisso.getId());

	    return comando.executeUpdate() >= 1;
	}
    }

    public boolean excluir(final int id) throws SQLException {
	try (var comando = conexao.getConexao().prepareStatement(SQL_DELETE)) {
	    comando.setInt(1, id);
	    return comando.executeUpdate() >= 1;
	}
    }
}
