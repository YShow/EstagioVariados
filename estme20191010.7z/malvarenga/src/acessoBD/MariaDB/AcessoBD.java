package acessoBD.MariaDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class AcessoBD {
	// USUARIO DO BANCO
	private static final String USUARIO = "usuario";
	// SENHA DO BANCO
	private static final String SENHA = "1234";
	private static final String STRINGCONEXAO = "jdbc:mariadb://127.0.0.1:3306/estagio?useSSL=false&verifyServerCertificate=false&sslMode=PREFERRED&useTimezone=true&serverTimezone=UTC";

	public Connection getConexao() {
		Connection teste = null;
		try {
			teste = DriverManager.getConnection(STRINGCONEXAO, USUARIO, SENHA);

		} catch (final SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
		return teste;
	}

}
