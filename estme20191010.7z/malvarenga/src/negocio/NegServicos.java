package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Servicos;

public final class NegServicos {
	private final AcessoBD conexao = new AcessoBD();
	private static final String SQL_INSERT = "{ CALL estagio.spInserirServico(?,?,?) }";
	private static final String SQL_SEARCH = "{ CALL estagio.spConsultaServico(?) }";
	private static final String SQL_ALTER = "{ CALL estagio.spAlterarServico(?,?,?,?) }";
	private static final String SQL_DELETE = "";

	public boolean inserirServico(final Servicos servico) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_INSERT);
		try (con; comando) {
			comando.setString(1, servico.getServico());
			comando.setString(2, servico.getHorario());
			comando.setBoolean(3, servico.isAtivo());
			return comando.executeUpdate() >= 1;
		}

	}

	public List<Servicos> pesquisarServico(final String descricao) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_SEARCH);
		try (con; comando) {
			comando.setString(1, descricao);
			final var result = comando.executeQuery();
			final List<Servicos> servicos = new ArrayList<>();

			while (result.next()) {
				final var servico = new Servicos();
				servico.setAtivo(result.getBoolean("ativo"));
				servico.setCodigo(result.getInt("codigo"));
				servico.setHorario(result.getString("horario"));
				servico.setServico(result.getString("servico"));

				servicos.add(servico);
			}

			return servicos;
		}
	}

	public boolean aletrarServico(final Servicos servico) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_ALTER);
		try (con; comando) {
			// CALL estagio.spAlterarServico(:codigo,:horario,:servico,?)
			comando.setInt(1, servico.getCodigo());
			comando.setString(2, servico.getHorario());
			comando.setString(3, servico.getServico());
			comando.setBoolean(4, servico.isAtivo());

			return comando.executeUpdate() >= 1;
		}

	}

}
