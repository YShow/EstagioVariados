package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Objetivos;

public final class NegObjetivos {
	private final AcessoBD conexao = new AcessoBD();
	private static final String SQL_INSERT = "{ CALL estagio.`spInserirObjetivos`(?,?) }";
	private static final String SQL_SEARCH = "{ CALL estagio.`spConsultaObjetivo`(?,?,?) }";
	private static final String SQL_ALTER = "{ CALL estagio.spAlterarObjetivo(?,?,?) }";
	private static final String SQL_DELETE = "";

	public boolean inserirObjetivos(final Objetivos objetivos) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_INSERT);
		try (con; comando;) {

			comando.setBoolean(1, objetivos.isAtivo());
			comando.setString(2, objetivos.getDescricao());

			return comando.executeUpdate() >= 1;
		}

	}

	public List<Objetivos> pesquisaObjeto(final String nomeObjetivo, final int opt, final int id) throws SQLException { // nome
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_SEARCH);
		final var listaObjetivos = new ArrayList<Objetivos>();
		try (con; comando;) {

			comando.setString(1, nomeObjetivo);
			comando.setInt(2, opt);
			comando.setInt(3, id);
			final var resultado = comando.executeQuery();
			while (resultado.next()) {

				final var objetivo = new Objetivos();
				objetivo.setAtivo(resultado.getBoolean("ativo"));
				objetivo.setDescricao(resultado.getString("descricao"));
				objetivo.setId(resultado.getInt("codigo"));
				listaObjetivos.add(objetivo);
			}

			return listaObjetivos;
		}

	}

	public boolean alteraObjeto(final Objetivos objetivo) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_ALTER);

		try (con; comando;) {
			comando.setInt(1, objetivo.getId());
			comando.setString(2, objetivo.getDescricao());
			comando.setBoolean(3, objetivo.isAtivo());

			return comando.executeUpdate() >= 1;
		}
	}

}
