package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Aparelhos;

public final class NegAparelhos {
	private final AcessoBD conexao = new AcessoBD();
	private static final String SQL_INSERT = "{ CALL estagio.spInserirAparelhos(?,?) }";
	private static final String SQL_SEARCH = "{ CALL estagio.spConsultaAparelho(?) }";
	private static final String SQL_ALTER = "{ CALL estagio.spAlterarAparelhos(?,?,?) }";
	private static final String SQL_DELETE = "";

	public boolean insereAparelho(final Aparelhos aparelho) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_INSERT);
		try (con; comando;) {
			comando.setString(1, aparelho.getDescricao());
			comando.setBoolean(2, aparelho.isAtivo());
			return comando.executeUpdate() >= 1;
		}

	}

	public List<Aparelhos> pesquisaAparelhos(final String descricao) throws SQLException {

		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_SEARCH);
		try (con; comando;) {
			final List<Aparelhos> aparelhoss = new ArrayList<>();

			comando.setString(1, descricao);
			final var result = comando.executeQuery();

			while (result.next()) {
				final var apa = new Aparelhos();
				apa.setAtivo(result.getBoolean("ativo"));
				apa.setCodigo(result.getInt("codigo"));
				apa.setDescricao(result.getString("descricao"));

				aparelhoss.add(apa);
			}

			return aparelhoss;
		}

	}

	public boolean alterarAparelho(final Aparelhos aparelho) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_ALTER);
		try (con; comando;) {
			comando.setInt(1, aparelho.getCodigo());
			comando.setString(2, aparelho.getDescricao());
			comando.setBoolean(3, aparelho.isAtivo());

			return comando.executeUpdate() >= 1;
		}
	}

}
