package negocio;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Funcionario;

public final class NegFuncionario {
	private final AcessoBD conexao = new AcessoBD();
	private static final String SQL_INSERT = "{ CALL estagio.`spInserirFuncionarioCompleto`(?,?,?,?,?,?,?,?) }";
	private static final String SQL_SEARCH = "{ CALL estagio.spConsultaFuncionario(?) }";
	private static final String SQL_ALTER = "{ CALL estagio.spAlterarFuncionario(?,?,?,?,?,?,?,?,?) }";
	private static final String SQL_DELETE = "{ CALL estagio.spDeleteFuncionario(?) }";

	public boolean inserirFuncionario(final Funcionario funcionario) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_INSERT);
		try (con; comando;) {
			/*
			 * (supervisor, estagiario, descricao_funcao, senha, cpf, rg, descricao_nome,
			 * ativo);
			 */
			comando.setBoolean(1, funcionario.isSupervisor());
			comando.setBoolean(2, funcionario.isEstagiario());
			comando.setString(3, funcionario.getFuncao());
			comando.setString(4, funcionario.getSenha());
			comando.setString(5, funcionario.getCpf());
			comando.setString(6, funcionario.getRg());
			comando.setString(7, funcionario.getNome());
			comando.setBoolean(8, funcionario.isAtivo());
			return comando.executeUpdate() >= 1;
		}

	}

	public List<Funcionario> pesquisaFuncionario(final String nome) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_SEARCH);
		try (con; comando;) {
			comando.setString(1, nome);
			final var resultado = comando.executeQuery();
			final List<Funcionario> funcionarios = new ArrayList<>();
			while (resultado.next()) {
				final var funcionario = new Funcionario();
				funcionario.setAtivo(resultado.getBoolean("ativo"));
				funcionario.setCodigo(resultado.getInt("codigo"));
				funcionario.setCpf(resultado.getString("cpf"));
				funcionario.setEstagiario(resultado.getBoolean("estagiario"));
				funcionario.setFuncao(resultado.getString("funcao"));
				funcionario.setNome(resultado.getString("nome"));
				funcionario.setRg(resultado.getString("rg"));
				funcionario.setSenha(resultado.getString("senha"));
				funcionario.setSupervisor(resultado.getBoolean("supervisor"));

				funcionarios.add(funcionario);
			}

			return funcionarios;
		}
	}

	public boolean alteraFuncionario(final Funcionario funcionario) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_ALTER);
		try (con; comando;) {
			// { CALL estagio.spAlterarFuncionario(:codigo,:supervisor,:estagiario,:funcao,
			// :senha,:cpf,:rg,:nome,:ativo) }
			comando.setInt(1, funcionario.getCodigo());
			comando.setBoolean(2, funcionario.isSupervisor());
			comando.setBoolean(3, funcionario.isEstagiario());
			comando.setString(4, funcionario.getFuncao());
			comando.setString(5, funcionario.getSenha());
			comando.setString(6, funcionario.getCpf());
			comando.setString(7, funcionario.getRg());
			comando.setString(8, funcionario.getNome());
			comando.setBoolean(9, funcionario.isAtivo());
			return comando.executeUpdate() >= 1;
		}
	}

	public boolean desativaFuncionario(final int id) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_ALTER);
		try (con; comando;) {
			comando.setInt(1, id);
			return comando.executeUpdate() >= 1;
		}
	}
}
