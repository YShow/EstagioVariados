package negocio;

import java.sql.SQLException;

import acessoBD.MariaDB.AcessoBD;
import objeto.Funcionario;

public final class NegLogin {
	private final AcessoBD conexao = new AcessoBD();
	private static final String SQL_SEARCH = "SELECT codigo, supervisor, estagiario, funcao, senha, cpf, rg, nome, ativo\n"
			+ "FROM estagio.funcionario WHERE senha = ? and nome = ? ;";

	public boolean verificaLogin(final Funcionario funcionario) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareStatement(SQL_SEARCH);
		try (con; comando;) {
			comando.setString(1, funcionario.getSenha());
			comando.setString(2, funcionario.getNome());
			final var resultado = comando.executeQuery();
			if (resultado.next()) {
				final var funcionarioPadrao = new Funcionario();
				return true;
			} else {
				return false;
			}
		}
	}
}
