package negocio;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import acessoBD.MariaDB.AcessoBD;
import objeto.Aluno;

public final class NegAluno {
	private final AcessoBD conexao = new AcessoBD();
	private static final String SQL_INSERT = "{ CALL estagio.spInserirAlunoCompleto"
			+ "(?,?," + "?,?,?,"
			+ "?,?,?,?,?,"
			+ "?,?,?,?,?) }";
	private static final String SQL_SEARCH = "{ CALL estagio.spConsultaAluno(?) }";
	private static final String SQL_ALTER = "";
	private static final String SQL_DELETE = "";

	private static final String SQL_PEGA_TUDO_ALUNO = "{ CALL estagio.spConsultaTudoAluno(?) }";

	public boolean insereAluno(final Aluno aluno) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_INSERT);
		try (con; comando;) {
			/*
			 * { CALL estagio.spInserirAlunoCompleto
			 * (:descricao_nome,:descricao_profissao,:cpf,:rg,:valor_mensalidade,
			 * :data_aniversario,:data_vencimento,:lesao_limitacao,:endereco,
			 * :telefone,:valor_matricula,:data_matricula,:ativo,:codigo_servico,:
			 * cod_objetivo) }
			 */
			comando.setString(1, aluno.getNome());
			comando.setString(2, aluno.getProfissao());
			comando.setString(3, aluno.getCpf());
			comando.setString(4, aluno.getRg());
			comando.setDouble(5, aluno.getValor_mensalidade());
			comando.setObject(6, aluno.getData_aniversario());
			comando.setObject(7, aluno.getData_vencimento());
			comando.setString(8, aluno.getLesa_limitacao());
			comando.setString(9, aluno.getEndereco());
			comando.setInt(10, aluno.getTelefone());
			comando.setInt(11, aluno.getValor_matricula());
			comando.setObject(12, aluno.getData_matricula());
			comando.setBoolean(13, aluno.isAtivo());
			comando.setInt(14, aluno.getCodigo_servico());
			comando.setInt(15, aluno.getCod_objetivo());

			return comando.executeUpdate() >= 1;
		}

	}

	public List<Aluno> pesquisaAluno(final String nome) throws SQLException {
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_SEARCH);

		try (con; comando;) {
			final List<Aluno> alunos = new ArrayList<>();
			comando.setString(1, nome);
			final var result = comando.executeQuery();

			while (result.next()) {
				final var aluno = new Aluno();
				aluno.setCodigo(result.getInt("codigo"));
				aluno.setNome(result.getString("nome"));
				aluno.setCpf(result.getString("cpf"));
				alunos.add(aluno);
			}

			return alunos;
		}
	}

	public Aluno pesquisaTudoAluno(final int id) throws SQLException{
		final var con = conexao.getConexao();
		final var comando = con.prepareCall(SQL_PEGA_TUDO_ALUNO);

		try(con;comando;)
		{
			comando.setInt(1, id);
			final var result = comando.executeQuery();
			final var aluno = new Aluno();
			if(result.next())
			{

				/*
				 * SELECT a.codigo,a.nome,a.profissao,a.cpf,a.rg,a.valor_mensalidade,
a.valor_matricula,a.data_vencimento,a.ativo,a.telefone,a.endereco,a.lesao_limitacao,a.data_aniversario
,obj.descricao,serv.servico*/
				aluno.setCodigo(result.getInt("a.codigo"));
				aluno.setNome(result.getString("a.nome"));
				aluno.setProfissao(result.getString("a.profissao"));
				aluno.setCpf(result.getString("a.cpf"));
				aluno.setRg(result.getString("a.rg"));
				aluno.setValor_mensalidade(result.getDouble("a.valor_mensalidade"));
				aluno.setValor_matricula(result.getInt("a.valor_matricula"));
				aluno.setData_vencimento(result.getObject("a.data_vencimento",LocalDate.class));
				aluno.setAtivo(result.getBoolean("a.ativo"));
				aluno.setTelefone(result.getInt("a.telefone"));
				aluno.setEndereco(result.getString("a.endereco"));
				aluno.setLesa_limitacao(result.getString("a.lesao_limitacao"));
				aluno.setData_aniversario(result.getObject("a.data_aniversario",LocalDate.class));
				aluno.setObjetivo(result.getString("obj.descricao"));
				aluno.setServico(result.getString("serv.servico"));
			}
			return aluno;
		}
	}
}
