package apresentacao;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import utilidade.Alerta;
import utilidade.Imagem;
import utilidade.Imagem.IMAGEM;

public final class ControladorMenuPrincipal {

	private final Stage stage = new Stage();
	private Pane root;

	@FXML
	void menuTelaCaixa(final ActionEvent event) {

		try {

			root = FXMLLoader.load(getClass().getResource("Caixa.fxml"));
			root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));
			stage.setMaximized(true);
			stage.setTitle("Menu de Caixa");
			final var scene = new Scene(root);

			stage.setScene(scene);
			stage.show();
		} catch (final IOException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void menuTelaServicos(final ActionEvent event) {

		try {
			root = FXMLLoader.load(getClass().getResource("Servicos.fxml"));
			root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));
			stage.setTitle("Menu de Serviços");
			stage.setMaximized(true);
			final var scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (final IOException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void menuTelaFuncionario(final ActionEvent event) {

		final var telaFuncionario = new ControladorMenuFuncionario();
		telaFuncionario.abreTelaFuncionarioMenu();
	}

	@FXML
	void menuTelaObjetivos(final ActionEvent event) {
		try {
			root = FXMLLoader.load(getClass().getResource("Objetivos.fxml"));
			root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));
			stage.setTitle("Menu de Objetivos");
			stage.setMaximized(true);
			final var scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (final IOException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void menuTelaTreino(final ActionEvent event) {

		try {
			root = FXMLLoader.load(getClass().getResource("Treino.fxml"));
			root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));
			stage.setTitle("Menu de Treino");
			stage.setMaximized(true);
			final var scene = new Scene(root);

			stage.setScene(scene);
			stage.show();

		} catch (final IOException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void menuTelaAparelhos(final ActionEvent event) {

		try {
			root = FXMLLoader.load(getClass().getResource("Aparelhos.fxml"));
			root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));

			stage.setTitle("Menu de Aparelhos");
			stage.setMaximized(true);
			final var scene = new Scene(root);

			stage.setScene(scene);
			stage.show();

		} catch (final IOException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void menuTelaAlunos(final ActionEvent event) {
		final var alunoTela = new ControladorMenuAlunos();
		alunoTela.abreTelaAlunoMenu();

	}
}
