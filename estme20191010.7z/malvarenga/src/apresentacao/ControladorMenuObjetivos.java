package apresentacao;

import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import negocio.NegObjetivos;
import objeto.Objetivos;
import utilidade.Alerta;

public final class ControladorMenuObjetivos {

	@FXML
	private TextField txtDescPesquisa;

	@FXML
	private CheckBox chkAtivo;

	@FXML
	private Button btnCadastrar;

	@FXML
	private Button btnCancelar;

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtDescricao;

	@FXML
	private TextField txtIdPesquisa;

	@FXML
	private TableView<Objetivos> tblViewObjetivo;

	@FXML
	private TableColumn<Objetivos, Integer> tcId;

	@FXML
	private TableColumn<Objetivos, String> tcDescricao;

	@FXML
	private TableColumn<Objetivos, Boolean> tcAtivo;

	@FXML
	private Button btnPesquisar;

	@FXML
	private Button btnAlterar;

	@FXML
	void btnAlterar(final ActionEvent event) {
		final var negObj = new NegObjetivos();
		try {
			if (negObj.alteraObjeto(pegaTextFieldObjetivos())) {
				Alerta.alertaSucesso();
				limpaTela();
			}
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	private Objetivos pegaTextFieldObjetivos() {
		final var obj = new Objetivos();
		obj.setDescricao(txtDescricao.getText());
		obj.setId(Integer.parseInt(txtId.getText()));
		obj.setAtivo(chkAtivo.isSelected());

		return obj;
	}

	@FXML
	void btnCadastrar(final ActionEvent event) {
		try {

			final var negObjetivos = new NegObjetivos();

			final var inserir = negObjetivos.inserirObjetivos(pegaTextFieldObjetivos());
			if (inserir) {
				Alerta.alertaSucesso();
				limpaTela();

			}
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	private void limpaTela() {
		txtDescricao.clear();
		chkAtivo.setSelected(false);
	}

	@FXML
	void btnCancelar(final ActionEvent event) {
		limpaTela();
	}

	@FXML
	void btnPesquisar(final ActionEvent event) {

		final var negObj = new NegObjetivos();
		final var obj = new ArrayList<Objetivos>();
		try {

			if (txtIdPesquisa.getText().isBlank() && !txtDescPesquisa.getText().isBlank()) {
				obj.addAll(negObj.pesquisaObjeto(txtDescPesquisa.getText(), 0, 0));
			} else if (txtDescPesquisa.getText().isBlank() && !txtIdPesquisa.getText().isBlank()) {
				obj.addAll(negObj.pesquisaObjeto("", 1, Integer.parseInt(txtIdPesquisa.getText())));
			} else
			{
				Alerta.alertaCampoNulo("Ambos campos de pesquisa estão vazio"
						,"Por favor, digite o termo de pesquisa nos campos de pesquisa");
			}


			final var data = FXCollections.observableArrayList(obj);
			tblViewObjetivo.setItems(data);
			tcId.setCellValueFactory(new PropertyValueFactory<Objetivos, Integer>("id"));
			tcDescricao.setCellValueFactory(new PropertyValueFactory<Objetivos, String>("descricao"));
			tcAtivo.setCellValueFactory(new PropertyValueFactory<Objetivos, Boolean>("ativo"));

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void pegaValoresTabela(final MouseEvent event) {
		final var objetivo = tblViewObjetivo.getSelectionModel().getSelectedItem();

		if (objetivo != null) {
			txtId.setText(String.valueOf(objetivo.getId()));
			txtDescricao.setText(objetivo.getDescricao());
			chkAtivo.setSelected(objetivo.isAtivo());
		}
	}

}
