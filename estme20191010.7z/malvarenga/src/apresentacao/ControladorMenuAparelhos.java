package apresentacao;

import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import negocio.NegAparelhos;
import objeto.Aparelhos;
import utilidade.Alerta;

public final class ControladorMenuAparelhos {

	@FXML
	private Button btnSalvar;

	@FXML
	private Button btnCancelar;

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtDescricao;

	@FXML
	private TextField txtPesquisar;

	@FXML
	private TableView<Aparelhos> tblViewAparelhos;

	@FXML
	private TableColumn<Aparelhos, Integer> tcId;

	@FXML
	private TableColumn<Aparelhos, String> tcDescricao;

	@FXML
	private TableColumn<Aparelhos, Boolean> tcAtivo;

	@FXML
	private Button btnPesquisar;

	@FXML
	private Button btnAlterar;

	@FXML
	private CheckBox chkAtivo;

	@FXML
	void btnAlterar(final ActionEvent event) {
		try {
			final var aparelho = new Aparelhos();
			final var negAparelhos = new NegAparelhos();
			if (negAparelhos.alterarAparelho(pegaAparelho())) {
				Alerta.alertaSucesso();
			}

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void pegaAparelhosTabela(final MouseEvent event) {
		final var aparelho = tblViewAparelhos.getSelectionModel().getSelectedItem();

		txtDescricao.setText(aparelho.getDescricao());
		txtId.setText(String.valueOf(aparelho.getCodigo()));
		chkAtivo.setSelected(aparelho.isAtivo());
	}

	private Aparelhos pegaAparelho() {
		final var aparelho = new Aparelhos();
		aparelho.setAtivo(chkAtivo.isSelected());
		aparelho.setDescricao(txtDescricao.getText().trim());

		if (!txtId.getText().trim().isBlank()) {
			aparelho.setCodigo(Integer.parseInt(txtId.getText().trim()));
		}

		return aparelho;

	}

	@FXML
	void btnCancelar(final ActionEvent event) {
		txtDescricao.clear();
		txtId.clear();
		txtPesquisar.clear();
		chkAtivo.setSelected(false);
	}

	@FXML
	void btnPesquisar(final ActionEvent event) {
		final var negAparelhos = new NegAparelhos();

		try {
			final var aparelho = negAparelhos.pesquisaAparelhos(txtPesquisar.getText());
			final var data = FXCollections.observableList(aparelho);
			tblViewAparelhos.setItems(data);

			tcAtivo.setCellValueFactory(new PropertyValueFactory<Aparelhos, Boolean>("ativo"));
			tcDescricao.setCellValueFactory(new PropertyValueFactory<Aparelhos, String>("descricao"));
			tcId.setCellValueFactory(new PropertyValueFactory<Aparelhos, Integer>("codigo"));

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void btnSalvar(final ActionEvent event) {
		try {
			final var aparelho = new Aparelhos();
			final var negAparelhos = new NegAparelhos();
			aparelho.setAtivo(chkAtivo.isSelected());
			aparelho.setDescricao(txtDescricao.getText().trim());
			if (negAparelhos.insereAparelho(aparelho)) {
				Alerta.alertaSucesso();
			}
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

}
