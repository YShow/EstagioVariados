package apresentacao;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public final class ControladorMenuTreino {

	@FXML
	private Button btnSalvar;

	@FXML
	private Button btnCancelar;

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtDescricao;

	@FXML
	private TextField txtPesquisar;

	@FXML
	private TableView<?> tblViewObjetivo;

	@FXML
	private TableColumn<?, ?> tcId;

	@FXML
	private TableColumn<?, ?> tcDescricao;

	@FXML
	private TableColumn<?, ?> tcAtivo;

	@FXML
	private Button btnPesquisar;

	@FXML
	private Button btnAlterar;

	@FXML
	private TextField txtGrupoMuscular;

}
