package apresentacao;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegAluno;
import negocio.NegObjetivos;
import negocio.NegServicos;
import objeto.Aluno;
import utilidade.Alerta;
import utilidade.Imagem;
import utilidade.Imagem.IMAGEM;

public final class ControladorMenuAlunos {

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtDescricao;

	@FXML
	private TextField txtPesquisar;

	@FXML
	private TableView<Aluno> tblViewAlunos;

	@FXML
	private TableColumn<Aluno, Integer> tcId;

	@FXML
	private TableColumn<Aluno, String> tcNome;

	@FXML
	private TableColumn<Aluno, String> tcCPF;

	@FXML
	private CheckBox chbAtivo;

	@FXML
	private TextField txtProfissao;

	@FXML
	private ComboBox<String> cbObjetivos;

	@FXML
	private ComboBox<String> cbServicos;

	@FXML
	private TextField txtCPF;

	@FXML
	private TextField txtRG;

	@FXML
	private TextField txtMensalidade;

	@FXML
	private ComboBox<String> cbVencimento;

	@FXML
	private TextField txtTelefone;

	@FXML
	private TextField txtEndereco;

	@FXML
	private TextField txtLesLim;

	@FXML
	private TextField txtMatricula;

	@FXML
	private DatePicker dateAniversario;
	private final NegAluno negAluno = new NegAluno();
	private static final String dataFormato = "dd-MM-yyyy";
	public void abreTelaAlunoMenu() {

		try {
			final var stage = new Stage();

			final var loader = new FXMLLoader();
			stage.initModality(Modality.APPLICATION_MODAL);

			loader.setLocation(getClass().getResource("/apresentacao/Alunos.fxml"));
			final Pane root = loader.load();
			 root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));
			final ControladorMenuAlunos controlador = loader.getController();
			final var negObj = new NegObjetivos();
			final var obj = negObj.pesquisaObjeto("", 0, 0);

			final List<String> objj = new ArrayList<>();
			for (final var objetivos : obj) {
				objj.add(objetivos.getDescricao());
			}
			controlador.cbObjetivos.setItems(FXCollections.observableList(objj));

			final var negServ = new NegServicos();
			final var serv = negServ.pesquisarServico("");
			final List<String> servvv = new ArrayList<>();
			for (final var servicos : serv) {
				servvv.add(servicos.getServico());
			}
			controlador.cbServicos.setItems(FXCollections.observableList(servvv));

			final List<String> datas = List.of(
			LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth(), 8).plusMonths(1)
			.format(DateTimeFormatter.ofPattern(dataFormato)),
			LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth(), 15).plusMonths(1)
			.format(DateTimeFormatter.ofPattern(dataFormato)),
			LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth(), 21).plusMonths(1)
			.format(DateTimeFormatter.ofPattern(dataFormato)),
			LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth(), 28).plusMonths(1)
			.format(DateTimeFormatter.ofPattern(dataFormato)));
			controlador.cbVencimento.getItems().addAll(datas);
			controlador.cbVencimento.getSelectionModel().select(3);
			stage.setMinHeight(root.minHeight(-1));
			stage.setMinWidth(root.minWidth(-1));

			stage.setTitle("Menu de Aluno");
			stage.setMaximized(true);
			final var scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (final IOException | SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void btnAlterar(final ActionEvent event) {

	}



	@FXML
	void btnCancelar(final ActionEvent event) {
		limpaCampos();
	}

	 private void limpaCampos() {
		txtCPF.clear();
		txtEndereco.clear();
		txtDescricao.clear();
		txtId.clear();
		txtLesLim.clear();
		txtMatricula.clear();
		txtMensalidade.clear();
		txtProfissao.clear();
		txtRG.clear();
		txtTelefone.clear();
		dateAniversario.setValue(null);
		dateAniversario.getEditor().clear();
		cbObjetivos.getSelectionModel().clearSelection();
		cbServicos.getSelectionModel().clearSelection();
		cbVencimento.getSelectionModel().clearSelection();
	}

	@FXML
	void btnPesquisar(final ActionEvent event) {
		try {
			final var alunos = negAluno.pesquisaAluno(txtPesquisar.getText().trim());
			tblViewAlunos.setItems(FXCollections.observableList(alunos));
			tcCPF.setCellValueFactory(new PropertyValueFactory<Aluno, String>("cpf"));
			tcId.setCellValueFactory(new PropertyValueFactory<Aluno, Integer>("codigo"));
			tcNome.setCellValueFactory(new PropertyValueFactory<Aluno, String>("nome"));

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void btnSalvar(final ActionEvent event) {

	}

	@FXML
	void pegaInformacoesDeCliente(final MouseEvent event) {
		final var id = tblViewAlunos.getSelectionModel().getSelectedItem().getCodigo();
		final var negAluno = new NegAluno();
		try {
			final var aluno = negAluno.pesquisaTudoAluno(id);
			txtCPF.setText(aluno.getCpf());
			txtEndereco.setText(aluno.getEndereco());
			txtDescricao.setText(aluno.getNome());
			txtId.setText(String.valueOf(aluno.getCodigo()));
			txtLesLim.setText(aluno.getLesa_limitacao());
			txtMatricula.setText(String.valueOf(aluno.getValor_matricula()));
			txtMensalidade.setText(String.valueOf(aluno.getValor_mensalidade()));
			txtProfissao.setText(aluno.getProfissao());
			txtRG.setText(aluno.getRg());
			txtTelefone.setText(String.valueOf(aluno.getTelefone()));
			dateAniversario.setValue(aluno.getData_aniversario());
			cbObjetivos.getSelectionModel().select(aluno.getObjetivo());
			cbServicos.getSelectionModel().select(aluno.getServico());
			cbVencimento.setValue(aluno.getData_vencimento().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}


	}

}
