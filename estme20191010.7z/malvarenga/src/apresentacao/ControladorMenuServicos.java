package apresentacao;

import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import negocio.NegServicos;
import objeto.Servicos;
import utilidade.Alerta;

public final class ControladorMenuServicos {

	@FXML
	private Button btnSalvar;

	@FXML
	private Button btnCancelar;

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtDescricao;

	@FXML
	private TextField txtPesquisar;

	@FXML
	private TableView<Servicos> tblViewServico;

	@FXML
	private TableColumn<Servicos, Integer> tcId;

	@FXML
	private TableColumn<Servicos, String> tcDescricao;

	@FXML
	private TableColumn<Servicos, Boolean> tcAtivo;

	@FXML
	private Button btnPesquisar;

	@FXML
	private Button btnAlterar;

	@FXML
	private CheckBox chkAtivo;

	@FXML
	private TextField txtHorario;

	@FXML
	void btnAlterar(final ActionEvent event) {
		final var negServico = new NegServicos();
		try {
			if(negServico.aletrarServico(pegaServicoDeTexto()))
			{
				Alerta.alertaSucesso();
			}

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void btnCancelar(final ActionEvent event) {
		limpaTela();
	}

	private Servicos pegaServicoDeTexto() {
		final var servico = new Servicos();
		servico.setAtivo(chkAtivo.isSelected());
		servico.setHorario(txtHorario.getText().trim());
		servico.setServico(txtDescricao.getText().trim());

		if (!txtId.getText().trim().isBlank()) {
			servico.setCodigo(Integer.parseInt(txtId.getText().trim()));
		}
		return servico;
	}

	private void limpaTela() {
		txtDescricao.clear();
		txtHorario.clear();
		txtId.clear();
		txtPesquisar.clear();
		chkAtivo.setSelected(false);
	}

	@FXML
	void pegaServicosTabela(final MouseEvent event) {
		final var servico = tblViewServico.getSelectionModel().getSelectedItem();

		txtDescricao.setText(servico.getServico());
		txtHorario.setText(servico.getHorario());
		txtId.setText(String.valueOf(servico.getCodigo()));
		chkAtivo.setSelected(servico.isAtivo());

	}

	@FXML
	void btnPesquisar(final ActionEvent event) {
		final var negServico = new NegServicos();

		try {
			final var servico = negServico.pesquisarServico(txtPesquisar.getText().trim());
			final var data = FXCollections.observableList(servico);
			tblViewServico.setItems(data);

			tcAtivo.setCellValueFactory(new PropertyValueFactory<Servicos, Boolean>("ativo"));
			tcDescricao.setCellValueFactory(new PropertyValueFactory<Servicos, String>("servico"));
			tcId.setCellValueFactory(new PropertyValueFactory<Servicos, Integer>("codigo"));
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void btnSalvar(final ActionEvent event) {
		final var negServico = new NegServicos();

		try {
			if (negServico.inserirServico(pegaServicoDeTexto())) {
				Alerta.alertaSucesso();
			}

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

}
