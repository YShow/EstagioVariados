package apresentacao;

public final class NewMain {

	public static void main(final String[] args) {
		// TODO Auto-generated method stub
		Main.main(args);
	}

}
