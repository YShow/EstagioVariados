package apresentacao;

import java.io.IOException;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import negocio.NegFuncionario;
import objeto.Funcionario;
import utilidade.Alerta;
import utilidade.Imagem;
import utilidade.Imagem.IMAGEM;

public final class ControladorMenuFuncionario {

	@FXML
	private ImageView image;

	@FXML
	private TableView<Funcionario> tblView;

	@FXML
	private TableColumn<Funcionario, Integer> tcId;

	@FXML
	private TableColumn<Funcionario, String> tcNome;

	@FXML
	private TableColumn<Funcionario, Boolean> tcAtivo;

	@FXML
	private TableColumn<Funcionario, Boolean> tcSup;

	@FXML
	private TableColumn<Funcionario, String> tcCpf;

	@FXML
	private TableColumn<Funcionario, String> tcRg;

	@FXML
	private TableColumn<Funcionario, String> tcFuncao;

	@FXML
	private TableColumn<Funcionario, Boolean> tcEstagiario;

	@FXML
	private CheckBox chkAtivo;

	@FXML
	private TextField txtFuncao;

	@FXML
	private TextField txtId;

	@FXML
	private TextField txtNome;

	@FXML
	private TextField txtSenhaSup;

	@FXML
	private TextField txtSenha;

	@FXML
	private TextField txtCpf;

	@FXML
	private TextField txtRg;

	@FXML
	private TextField txtPesquisar;

	@FXML
	private Button btnCadastrar;

	@FXML
	private Button btnDesativar;

	@FXML
	private Button btnAlterar;

	@FXML
	private Button btnPesquisar;

	@FXML
	private CheckBox chkEstagiario;

	@FXML
	private CheckBox chkSupervisor;

	@FXML
	private Button btnCancelar;

	public void abreTelaFuncionarioMenu() {
		final var stage = new Stage();
		Pane root;
		// var loader = new FXMLLoader();
		stage.initModality(Modality.APPLICATION_MODAL);
		try {
			root = FXMLLoader.load(getClass().getResource("Funcionario.fxml"));
			root.setBackground(Imagem.colocaImagemFundo(IMAGEM.FUNDO_CADASTROS));
			stage.setTitle("Menu de Funcionario");
			stage.setMaximized(true);
			final var scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (final IOException e) {
			Alerta.alertaErro(e.getMessage());
		}

	}

	@FXML
	void btnAlterar(final ActionEvent event) {
		final var negFuncionario = new NegFuncionario();

		try {
			if (negFuncionario.alteraFuncionario(pegaFuncionario())) {
				Alerta.alertaSucesso();
			}
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void btnCadastrar(final ActionEvent event) {

		final var negFuncionario = new NegFuncionario();
		try {

			final var inserir = negFuncionario.inserirFuncionario(pegaFuncionario());
			if (inserir) {
				Alerta.alertaSucesso();
			}
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	private Funcionario pegaFuncionario() {
		final var funcionario = new Funcionario();
		if (!txtId.getText().isEmpty()) {
			funcionario.setCodigo(Integer.parseInt(txtId.getText()));
		}
		funcionario.setAtivo(chkAtivo.isSelected());
		funcionario.setCpf(txtCpf.getText());// string, est� ok
		funcionario.setEstagiario(chkEstagiario.isSelected());
		funcionario.setFuncao(txtFuncao.getText());
		funcionario.setNome(txtNome.getText());
		funcionario.setRg(txtRg.getText());
		funcionario.setSenha(txtSenha.getText());
		funcionario.setSupervisor(chkSupervisor.isSelected());
		return funcionario;
	}

	@FXML
	void btnCancelar(final ActionEvent event) {
		// fazer isso para cada txt que voce tiver
		limpaCampos();
	}

	private void limpaCampos() {
		txtCpf.clear();
		txtId.clear();
		txtNome.clear();
		txtPesquisar.clear();
		txtRg.clear();
		txtSenha.clear();
		txtSenhaSup.clear();
		chkAtivo.setSelected(false);
		chkEstagiario.setSelected(false);
		chkSupervisor.setSelected(false);
	}

	@FXML
	void btnPesquisar(final ActionEvent event) {
		final var negFuncionario = new NegFuncionario();
		try {
			final var funcionarios = negFuncionario.pesquisaFuncionario(txtPesquisar.getText().trim());

			final var data = FXCollections.observableArrayList(funcionarios);

			tblView.setItems(data);

			tcAtivo.setCellValueFactory(new PropertyValueFactory<Funcionario, Boolean>("ativo"));
			tcCpf.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("cpf"));
			tcEstagiario.setCellValueFactory(new PropertyValueFactory<Funcionario, Boolean>("Estagiario"));
			tcFuncao.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("funcao"));
			tcId.setCellValueFactory(new PropertyValueFactory<Funcionario, Integer>("codigo"));
			tcNome.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("nome"));
			tcRg.setCellValueFactory(new PropertyValueFactory<Funcionario, String>("rg"));
			tcSup.setCellValueFactory(new PropertyValueFactory<Funcionario, Boolean>("supervisor"));

		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void btnDesativar(final ActionEvent event) {
		final var funcionario = tblView.getSelectionModel().getSelectedItem();
		final var negFuncionario = new NegFuncionario();
		try {
			if (negFuncionario.desativaFuncionario(funcionario.getCodigo())) {
				Alerta.alertaSucesso();
				tblView.getItems().remove(funcionario);
				limpaCampos();
			}
		} catch (final SQLException e) {
			Alerta.alertaErro(e.getMessage());
		}
	}

	@FXML
	void selecionaFuncionario(final MouseEvent event) {
		final var funcionario = tblView.getSelectionModel().getSelectedItem();

		txtCpf.setText(funcionario.getCpf());
		txtFuncao.setText(funcionario.getFuncao());
		txtId.setText(String.valueOf(funcionario.getCodigo()));
		txtNome.setText(funcionario.getNome());
		txtRg.setText(funcionario.getRg());
		chkAtivo.setSelected(funcionario.isAtivo());
		chkEstagiario.setSelected(funcionario.isEstagiario());
		chkSupervisor.setSelected(funcionario.isSupervisor());
	}

}
