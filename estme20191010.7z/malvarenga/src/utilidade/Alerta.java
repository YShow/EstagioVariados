package utilidade;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;
import javafx.stage.StageStyle;

public final class Alerta {

	public static void alertaSucesso() {
		final Alert alerta = new Alert(Alert.AlertType.NONE);
		alerta.initStyle(StageStyle.TRANSPARENT);
		alerta.initModality(Modality.APPLICATION_MODAL);
		alerta.setAlertType(AlertType.INFORMATION);
		alerta.setHeaderText("Função realizada com sucesso");
		alerta.setHeight(300);
		alerta.setWidth(300);
		alerta.show();

	}

	public static void alertaErro(final String erro) {
		final Alert alerta = new Alert(Alert.AlertType.NONE);
		alerta.initStyle(StageStyle.TRANSPARENT);
		alerta.initModality(Modality.APPLICATION_MODAL);
		alerta.setAlertType(AlertType.WARNING);
		alerta.setTitle("Ocorreu um problema");
		alerta.setHeaderText("Verifique os campos e informe o erro ao desenvolvedor");
		alerta.setContentText("Erro: " + erro);
		alerta.setResult(ButtonType.OK);
		alerta.setHeight(300);
		alerta.setWidth(300);
		alerta.show();
	}

	public static void alertaCampoNulo() {
		final Alert alerta = new Alert(Alert.AlertType.WARNING);

		alerta.setHeaderText("Verifique os campos");
		alerta.setContentText("Por favor verifique se todos os campos foram preenchidos");
		alerta.setHeight(300);
		alerta.setWidth(300);
		alerta.show();
	}

	public static void alertaCampoNulo(final String header,final String content)
	{
		final Alert alerta = new Alert(Alert.AlertType.WARNING);
		alerta.setHeaderText(header);
		alerta.setContentText(content);
		alerta.setHeight(300);
		alerta.setWidth(300);
		alerta.show();
	}


}
