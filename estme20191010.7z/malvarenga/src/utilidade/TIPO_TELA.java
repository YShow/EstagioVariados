package utilidade;

public enum TIPO_TELA {
	INSERE, ALTERA, EXCLUI, CONSULTA
}
