package objeto;

public final class Servicos {
	private String servico;

	public final String getServico() {
		return servico;
	}

	public final void setServico(final String servico) {
		this.servico = servico;
	}

	public final String getHorario() {
		return horario;
	}

	public final void setHorario(final String horario) {
		this.horario = horario;
	}

	public final int getCodigo() {
		return codigo;
	}

	public final void setCodigo(final int codigo) {
		this.codigo = codigo;
	}

	public final boolean isAtivo() {
		return ativo;
	}

	public final void setAtivo(final boolean ativo) {
		this.ativo = ativo;
	}

	private String horario;
	private int codigo;
	private boolean ativo;
}
