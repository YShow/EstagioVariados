package objeto;

public final class Aparelhos {
	private int codigo;

	public final int getCodigo() {
		return codigo;
	}

	public final void setCodigo(final int codigo) {
		this.codigo = codigo;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(final String descricao) {
		this.descricao = descricao;
	}

	public final boolean isAtivo() {
		return ativo;
	}

	public final void setAtivo(final boolean ativo) {
		this.ativo = ativo;
	}

	private String descricao;
	private boolean ativo;
}
