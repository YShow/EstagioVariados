package objeto;

public final class Cliente {

}
