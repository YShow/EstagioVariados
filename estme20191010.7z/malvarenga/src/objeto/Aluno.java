package objeto;

import java.time.LocalDate;

public final class Aluno {
	private int codigo;

	public final int getCodigo() {
		return codigo;
	}

	public final void setCodigo(final int codigo) {
		this.codigo = codigo;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(final String nome) {
		this.nome = nome;
	}

	public final String getProfissao() {
		return profissao;
	}

	public final void setProfissao(final String profissao) {
		this.profissao = profissao;
	}

	public final String getCpf() {
		return cpf;
	}

	public final void setCpf(final String cpf) {
		this.cpf = cpf;
	}

	public final String getRg() {
		return rg;
	}

	public final void setRg(final String rg) {
		this.rg = rg;
	}

	public final double getValor_mensalidade() {
		return valor_mensalidade;
	}

	public final void setValor_mensalidade(final double valor_mensalidade) {
		this.valor_mensalidade = valor_mensalidade;
	}

	public final LocalDate getData_aniversario() {
		return data_aniversario;
	}

	public final void setData_aniversario(final LocalDate data_aniversario) {
		this.data_aniversario = data_aniversario;
	}

	public final LocalDate getData_vencimento() {
		return data_vencimento;
	}

	public final void setData_vencimento(final LocalDate data_vencimento) {
		this.data_vencimento = data_vencimento;
	}

	public final String getLesa_limitacao() {
		return lesa_limitacao;
	}

	public final void setLesa_limitacao(final String lesa_limitacao) {
		this.lesa_limitacao = lesa_limitacao;
	}

	public final String getEndereco() {
		return endereco;
	}

	public final void setEndereco(final String endereco) {
		this.endereco = endereco;
	}

	public final int getTelefone() {
		return telefone;
	}

	public final void setTelefone(final int telefone) {
		this.telefone = telefone;
	}

	public final int getValor_matricula() {
		return valor_matricula;
	}

	public final void setValor_matricula(final int valor_matricula) {
		this.valor_matricula = valor_matricula;
	}

	public final LocalDate getData_matricula() {
		return data_matricula;
	}

	public final void setData_matricula(final LocalDate data_matricula) {
		this.data_matricula = data_matricula;
	}

	public final boolean isAtivo() {
		return ativo;
	}

	public final void setAtivo(final boolean ativo) {
		this.ativo = ativo;
	}

	public final int getCodigo_servico() {
		return codigo_servico;
	}

	public final void setCodigo_servico(final int codigo_servico) {
		this.codigo_servico = codigo_servico;
	}

	public final int getCod_objetivo() {
		return cod_objetivo;
	}

	public final void setCod_objetivo(final int cod_objetivo) {
		this.cod_objetivo = cod_objetivo;
	}

	private String nome;
	private String profissao;
	private String cpf;
	private String rg;
	private double valor_mensalidade;
	private LocalDate data_aniversario;
	private LocalDate data_vencimento;
	private String lesa_limitacao;
	private String endereco;
	private int telefone;
	private int valor_matricula;
	private LocalDate data_matricula;
	private boolean ativo;
	private int codigo_servico;
	private int cod_objetivo;

	private String servico;
	public final String getServico() {
		return servico;
	}

	public final void setServico(final String servico) {
		this.servico = servico;
	}

	public final String getObjetivo() {
		return objetivo;
	}

	public final void setObjetivo(final String objetivo) {
		this.objetivo = objetivo;
	}

	private String objetivo;

}
