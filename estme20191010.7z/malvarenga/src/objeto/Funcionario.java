package objeto;

public final class Funcionario {
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(final int codigo) {
		this.codigo = codigo;
	}

	public boolean isSupervisor() {
		return supervisor;
	}

	public void setSupervisor(final boolean supervisor) {
		this.supervisor = supervisor;
	}

	public boolean isEstagiario() {
		return estagiario;
	}

	public void setEstagiario(final boolean estagiario) {
		this.estagiario = estagiario;
	}

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(final String funcao) {
		this.funcao = funcao;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(final String senha) {
		this.senha = senha;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(final String cpf) {
		this.cpf = cpf;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(final String rg) {
		this.rg = rg;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(final String nome) {
		this.nome = nome;
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(final boolean ativo) {
		this.ativo = ativo;
	}

	private int codigo;
	private boolean supervisor;
	private boolean estagiario;
	private String funcao;
	private String senha;
	private String cpf;
	private String rg;
	private String nome;
	private boolean ativo;
}
