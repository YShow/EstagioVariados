-- MySQL dump 10.16  Distrib 10.2.25-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: estagio
-- ------------------------------------------------------
-- Server version	10.2.25-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alunos`
--

DROP TABLE IF EXISTS `alunos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alunos` (
  `codigo` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `profissao` varchar(100) DEFAULT NULL,
  `cpf` char(11) DEFAULT NULL,
  `rg` varchar(15) DEFAULT NULL,
  `valor_mensalidade` double(2,2) DEFAULT NULL,
  `data_aniversario` date DEFAULT NULL,
  `data_vencimento` date DEFAULT NULL,
  `lesao_limitacao` varchar(255) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `valor_matricula` int(11) DEFAULT NULL,
  `data_matricula` date DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  `codigo_servico` int(11) NOT NULL,
  `cod_objetivo` int(11) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `codigo_servico_idx` (`codigo_servico`),
  KEY `alunos_fk` (`cod_objetivo`),
  CONSTRAINT `alunos_fk` FOREIGN KEY (`cod_objetivo`) REFERENCES `objetivos` (`codigo`),
  CONSTRAINT `codigo_servico` FOREIGN KEY (`codigo_servico`) REFERENCES `servico` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alunos`
--

LOCK TABLES `alunos` WRITE;
/*!40000 ALTER TABLE `alunos` DISABLE KEYS */;
INSERT INTO `alunos` VALUES (126,'matias','in voluptate velit es','0987654321','m',NULL,'1981-04-21','1982-12-26','cupidatat non proident, sunt in c','dolore eu fugiat nulla par',8660,11,'1990-02-27',1,29,55),(6121,'quis nostrud exercitati','cupidatat non proident, sunt in culpa qui officia deserunt mollit an','tempo','consectetur a',NULL,'2015-01-27','2002-04-03','amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut l','non proident, s',21582,20,'1981-01-15',1,10,89),(9478,'Excepteur sint occ','Excepteur sint occaecat cupidatat non proident, sun','elit, sed d','v',NULL,'2010-11-05','2011-04-24','eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad mini','n',10020,5,'2006-01-24',1,11,71),(12518,'nul','Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea ','veli','nostrud exer',NULL,'2004-02-11','1998-12-17','veniam, qu','laboris nisi ut aliquip ex ea c',26431,34,'1990-08-13',1,29,52),(13832,'do eiusmod tempor incididunt ut labore et dolore magna aliqu','veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis au','pari','qu',NULL,'1994-06-27','1990-02-20','voluptate veli','aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat n',23698,14,'2018-03-29',1,42,52),(18875,'irure dolor in reprehen','est labo','e','sit amet, cons',NULL,'1984-02-12','2006-06-10','conse','ea commodo consequat.',24143,3,'1986-05-24',1,24,38),(25374,'ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo conseq','ad minim veniam, quis nostrud exercitation ','cillum dol','velit ess',NULL,'2002-01-14','2013-08-23','dolor in reprehen','Duis a',21333,18,'1990-01-19',1,10,86),(26316,'ipsum dolor sit amet, consectetur adipiscing el','ullamco laboris nisi ut aliquip ex','in culpa','Excepteur',NULL,'1991-02-09','2000-01-20','sunt in cul','incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitatio',17466,15,'2012-07-18',1,36,5),(31003,'sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim a','dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariat','magna','des',NULL,'2019-07-29','2004-03-27','ex ea commodo consequat. Duis aute irure dolor in reprehe','adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut',21571,16,'1993-03-18',1,37,100);
/*!40000 ALTER TABLE `alunos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alunosxservicos`
--

DROP TABLE IF EXISTS `alunosxservicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alunosxservicos` (
  `codigo_aluno` int(11) NOT NULL,
  `codigo_servico` int(11) NOT NULL,
  PRIMARY KEY (`codigo_aluno`,`codigo_servico`),
  KEY `fk_AlunosXServicos3` (`codigo_servico`),
  CONSTRAINT `fk_AlunosXServicos2` FOREIGN KEY (`codigo_aluno`) REFERENCES `alunos` (`codigo`),
  CONSTRAINT `fk_AlunosXServicos3` FOREIGN KEY (`codigo_servico`) REFERENCES `servico` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alunosxservicos`
--

LOCK TABLES `alunosxservicos` WRITE;
/*!40000 ALTER TABLE `alunosxservicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `alunosxservicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alunosxtreino`
--

DROP TABLE IF EXISTS `alunosxtreino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alunosxtreino` (
  `codigo_aluno` int(11) NOT NULL,
  `codigo_treino` int(11) NOT NULL,
  PRIMARY KEY (`codigo_aluno`,`codigo_treino`),
  KEY `fk_AlunosXTreino3` (`codigo_treino`),
  CONSTRAINT `fk_AlunosXTreino2` FOREIGN KEY (`codigo_aluno`) REFERENCES `alunos` (`codigo`),
  CONSTRAINT `fk_AlunosXTreino3` FOREIGN KEY (`codigo_treino`) REFERENCES `treino` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alunosxtreino`
--

LOCK TABLES `alunosxtreino` WRITE;
/*!40000 ALTER TABLE `alunosxtreino` DISABLE KEYS */;
INSERT INTO `alunosxtreino` VALUES (126,418),(126,528),(6121,559),(9478,435),(12518,449),(13832,11),(18875,423),(25374,533),(26316,494),(31003,352);
/*!40000 ALTER TABLE `alunosxtreino` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aparelhos`
--

DROP TABLE IF EXISTS `aparelhos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aparelhos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(50) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aparelhos`
--

LOCK TABLES `aparelhos` WRITE;
/*!40000 ALTER TABLE `aparelhos` DISABLE KEYS */;
INSERT INTO `aparelhos` VALUES (1,'consectetur ',1),(2,'aaaaaa',1),(3,'in voluptate velit esse cillum dolore eu fugiat',1),(4,'nisi u',1),(5,'ullam',1),(6,'qui officia deserunt mollit anim id est l',1),(7,'dolor sit amet, consectetur adipiscing ',1),(8,'Excepteur sint o',1),(9,'veniam, quis nostrud ex',1),(10,'proident, sunt in culpa qui offici',1),(11,'laboris nisi ut al',1),(12,'occaecat cupidatat no',1),(13,'nu',1),(14,'nisi ut aliquip ex ea',1),(15,'ullamco laboris nisi ut aliqu',1),(16,'est ',1),(17,'Lorem ipsum dolor sit amet, con',1),(18,'ad minim ',1),(19,'adipiscing elit, sed do eius',1),(20,'sit amet, consectetur adipisc',1),(21,'aliqua. Ut enim ad',1),(22,'quis nostrud',1),(23,'sit amet, consectetu',1),(24,'laborum.Lorem ipsum dolor sit amet, consectetur a',1),(25,'et dolo',1),(26,'reprehenderit',1),(27,'Excepteur sint ',1),(28,'aute irure dolor in reprehenderit ',1),(29,'adipiscing elit, sed do eius',1),(30,'in reprehenderit in voluptate velit esse cillu',1),(31,'eu fugiat nulla pariatur. Excepteur ',1),(32,'minim veniam, quis nostrud exercitation ullam',1),(33,'in voluptate velit esse cillum',1),(34,'cillum dolore eu fugiat nulla pariatur. ',1),(35,'dolore eu fugiat nulla pariatur. Exce',1),(36,'dolor in rep',1),(37,'sunt in culpa qui officia deserunt mollit a',1),(38,'sint occaecat cupidatat non proident, sunt',1),(39,'consectetur adipis',1),(40,'cupidatat non proident, sunt in culpa ',1),(41,'velit esse cillum dolore eu fugiat nulla pa',1),(42,'anim id e',1),(43,'ex ea commodo consequat',1),(44,'non proident, sunt in culpa qui officia deserunt',1),(45,'ut aliquip ex ea commo',1),(46,'sunt in culpa qui officia deserunt mollit anim id ',1),(47,'ex ea commodo con',1),(48,'ullamco laboris n',1),(49,'cillum dolor',1),(50,'in reprehenderit in volupta',1),(51,'pack deck',1),(52,'',NULL),(53,'',NULL),(54,'',NULL),(55,'',NULL),(56,'',NULL),(57,'',NULL),(58,'',NULL),(59,'a',NULL),(60,'a',NULL),(61,'t',NULL),(62,'t',NULL),(63,'t',NULL),(64,'t',NULL),(65,'t',NULL),(66,'t',NULL),(67,'t',NULL),(68,'',NULL),(69,'',NULL),(70,'',NULL),(71,'',NULL),(72,'asdasdasd',NULL),(73,'asdasdasd',NULL),(74,'asdasdasd',NULL),(75,'con',NULL),(76,'',NULL),(77,'',NULL),(78,'',NULL),(79,'',NULL),(80,'',NULL),(81,'teste',1);
/*!40000 ALTER TABLE `aparelhos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionario` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor` tinyint(1) DEFAULT NULL,
  `estagiario` tinyint(1) DEFAULT NULL,
  `funcao` varchar(50) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `cpf` varchar(11) DEFAULT NULL,
  `rg` varchar(15) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (3,1,1,'1','1234','1','1','matheus',1),(4,1,1,'tester','2','1','2','teste',1),(5,1,0,'maestro','1','99','99','leonardo',1),(6,1,1,'plugpharma','1','1','1','kleber',1),(7,1,0,'toptop','0','6','6','bernal',1),(8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objetivos`
--

DROP TABLE IF EXISTS `objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objetivos` (
  `descricao` varchar(50) DEFAULT NULL,
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `ativo` tinyint(4) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objetivos`
--

LOCK TABLES `objetivos` WRITE;
/*!40000 ALTER TABLE `objetivos` DISABLE KEYS */;
INSERT INTO `objetivos` VALUES ('velit esse cillum dolore eu fugiat nulla pariatur.',3,1),('veliiii',4,1),('elit, sed do eiusmod tempor incididunt ut labor',5,1),('nisi ut aliquip ex ea commodo conseq',6,1),('id est laborum.Lorem ipsum dolo',7,1),('velit esse cillum dolore eu fugiat ',8,1),('dolor sit amet, consectetur adipisc',9,1),('anim id est laborum.Lorem',10,1),('sunt in c',11,1),('laboris nisi ut ',12,1),('Duis aute irure do',13,1),('velit esse cillum dolore eu fugiat ',14,1),('mollit a',15,1),('qui offic',16,1),('nulla pariatur. Excepteur sint occ',17,1),('ullamco laboris nisi ut aliqui',18,1),('elit, sed',19,1),('elit, sed do eiusmod tempor ',20,1),('ullamco laboris nisi ut aliquip ',21,1),('et dolore magna aliqua. Ut enim ad minim ve',22,1),('or',23,1),('aliqua. Ut enim ad minim ve',24,1),('incididunt ut labore et dol',25,1),('cillum dolore eu fugiat nulla p',26,1),('in vol',27,1),('dolor in reprehenderit in voluptate veli',28,1),('id est laborum.Lorem ipsum dolor sit amet, cons',29,1),('sint occ',30,1),('sed do eiusmod tempor',31,1),('quis nostrud exercitation ullamco laboris nisi',32,1),('cu',33,1),('officia',34,1),('nostru',35,1),('anim id est laborum.Lorem i',36,1),('ut labor',37,1),('Duis aute irure dolor in reprehenderi',38,1),('cillum dolo',39,1),('est laborum.Lorem ipsum dolor sit am',40,1),('in volupt',41,1),('ex',42,1),('sit amet, consectetur adipiscing elit, sed do eiu',43,1),('consequat. Duis aute irure dolor in ',44,1),('ex ea commodo consequat. D',45,1),('nisi ut aliquip ex ',46,1),('pariatur. Ex',47,1),('sunt in culpa qui officia ',48,1),('aborum.Lorem ipsum dolor sit amet',49,1),('dolore eu fugiat nulla ',50,1),('mollit anim id est laborum.Lorem ipsum dolor si',51,1),('cupidatat non',52,1),('proident, sunt in culpa qui officia des',53,1),('ut labore et dolore magna aliqua. Ut enim ad m',54,1),('in repre',55,1),('elit, sed do eius',56,1),('laboris nisi ut aliqui',57,1),('ea commodo conse',58,1),('ut labore et dolore magna aliqua. Ut enim ad ',59,0),('ipsum dolor sit amet, consectetur adipiscing elit,',60,1),('esse cillum dolore eu fugiat nulla pariatur. Excep',61,1),('adipiscing elit, sed do',62,1),('est laborum',63,1),('adipisci',64,1),('vel',65,1),('quis nostrud exerc',66,1),('sint occaecat cupidatat non',67,1),('nulla pariatur. Excepteur sint',68,1),('ipsum dolor sit amet, co',69,1),('dolore magn',70,1),('ut labore et dol',71,1),('ullamco laboris nisi',72,1),('Duis aute irure do',73,1),('dolor in reprehe',74,1),('dolor sit amet, consectetur adipiscing',75,1),('occaecat cupidatat non proident, sunt in culpa q',76,1),('et dolore magna aliqua. Ut enim ad mi',77,1),('pariatur.',78,1),('in voluptat',79,1),('laboris nisi ut aliquip ex ea commodo consequ',80,1),('adipiscing elit, sed do eiusmod tempor i',81,1),('et dolore magna aliqua. Ut enim ad minim ven',82,1),('sint occaecat cupidatat non proiden',83,1),('ex ea commodo consequat. Du',84,1),('velit esse cillum dolore eu fugiat nulla pa',85,1),('ullamco laboris nis',86,1),('laborum.Lorem ipsum dolor sit amet, consec',87,1),('ea commodo conseq',88,1),('pariatur. Excepteur si',89,1),('laborum.Lorem ipsum dolor sit amet, consectetur ad',90,1),('nisi ut aliquip ex ea commodo consequat. Duis a',91,1),('sint occaec',92,1),('occaecat cupidat',93,1),('ullamco lab',94,1),('non proident, sunt in culpa qui officia deserunt',95,1),('l',96,1),('elit, sed do eiusmod tempor incidi',97,1),('Duis aute irure dolor in reprehenderit in volupt',98,1),('dolor sit amet, consectetur adipiscing',99,1),('ut aliquip e',100,1),('emagrecer',101,1),('hipertrofia',102,1),(NULL,103,1),(NULL,104,1),('ganho de massa',105,1),('testeste',106,1),('dfaasd',107,1),('HADDAD',108,1),('testefunçãoalerta',109,1),('testefunçãolimpatela',110,1),('213',111,1),('',112,0);
/*!40000 ALTER TABLE `objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servico`
--

DROP TABLE IF EXISTS `servico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servico` (
  `servico` varchar(50) DEFAULT NULL,
  `horario` varchar(50) DEFAULT NULL,
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `ativo` tinyint(4) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servico`
--

LOCK TABLES `servico` WRITE;
/*!40000 ALTER TABLE `servico` DISABLE KEYS */;
INSERT INTO `servico` VALUES ('musculação','5 às 21',1,0),('sunt in culpa qui officia deseru','sit amet, co',2,0),('in culpa qui officia deser','pariatur. Excepteur sint occaeca',3,0),('consectetur a','in repre',4,0),('Lorem ipsum dolor sit ame','officia de',5,0),('in voluptate v','deserunt mollit anim id est laborum.Lore',6,0),('ut labore et dolore magna aliqua. Ut enim a','incididunt ut labore et dolore magna ',7,0),('in voluptate ','dolor in reprehenderit in vol',8,0),('quis nostrud exercitation ul','in voluptate velit ess',9,0),('ut labore et dolore magna aliqua. Ut ','tempor incidi',10,0),('nisi ut aliquip ex ea commodo ','ex ea commodo consequat. Duis ',11,0),('nulla pariatur. Excep','minim veniam, quis nos',12,0),('in voluptate velit esse cillum dolore','aliqua. Ut enim ad minim veni',13,0),('elit, sed ','adipiscin',14,0),('pariatur. Excepteur sint occaecat cupidatat non ','ipsum dolor sit amet, consectetur a',15,0),('eu fugiat nulla pariatur. Excepteu','adipiscing elit, sed ',16,0),('sunt in culpa qui officia deserunt mollit anim','esse cillum dolore eu fugiat nulla pariatur.',17,0),('nostrud exercitation ullamco laboris nisi ut aliqu','pariatur. Ex',18,0),('dolor in reprehenderit in voluptate','ullamco laboris nisi ut al',19,0),('Duis aute irure dolor in','d',20,0),('laboris nisi ut','sed do ',21,0),('consequat. Duis aute irure dolor in reprehenderit','in',22,0),('sit amet, consectetur adipiscing elit, sed do eiu','dolor',23,0),('ad minim veniam, quis nostrud exercitation ul','consequat. Duis aute irure dol',24,0),('ipsum dolor sit amet, consectetur adipiscing eli','in voluptate velit esse cillum dolor',25,0),('do eiusmod tempor incididunt u','laboris ni',26,0),('ipsum dolor sit amet, consectetur adipis','nulla pariatur. Ex',27,0),('proident, sunt in culpa qui officia ','in reprehenderit in voluptate velit esse cillum do',28,0),('do eiusmod tempor incididunt ut labore et d','fugiat nulla pariatur. Excepteur ',29,0),('Ut enim ad minim veniam, q','tempor incididunt ut labore et dol',30,0),('consequat. Duis aute irure dolor','cupidatat non proi',31,0),('dolor sit ','Duis aute irure dolo',32,0),('sunt in culpa qui officia ','tempor incididunt ut labore et dolore ',33,0),('incididunt ut labore et dolo','q',34,0),('exercitation ullamco laboris nisi ut ali','ipsu',35,0),('laborum.Lorem ipsum dolor sit','minim veniam, quis nostrud exercitation u',36,0),('commodo consequat. Duis aute','amet, consectetur adipiscing elit, sed do ',37,0),('deserunt mol','proident, sunt in culpa qui ',38,0),('sint oc','eu fugiat nulla p',39,0),('sint occaecat cupidatat non proident, sun','mo',40,0),('ea commodo consequat. Duis aut','non proident, sunt ',41,0),('occaecat cupidatat non proident, sunt in cul','in reprehenderit ',42,0),('adipisc','et dolore magna ali',43,0),('culpa qui officia deserunt mollit an','laboris nisi ut aliquip ex ea commodo consequat.',44,0),('ul','nisi ut aliquip ex ea commodo consequat. Duis',45,0),('dolore eu fugiat nulla pariatur','adipiscing elit,',46,0),('sint occaecat ','Duis aut',47,0),('sit amet, consec','ipsum dolor sit amet',48,0),('quis nostru','adipiscing elit, sed do eiusmod ',49,0),('in reprehenderit in volu','deserunt mollit anim i',50,0),('sint occaecat cupidatat','ipsum dolor sit a',51,0),('zumba','manhã das 7 às 7:40',52,0),('testeeee','testeeee',53,1),('teste','testeeee',54,1);
/*!40000 ALTER TABLE `servico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treino`
--

DROP TABLE IF EXISTS `treino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treino` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `serie` char(2) DEFAULT NULL,
  `grupo_muscular` varchar(50) DEFAULT NULL,
  `ativo` tinyint(4) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=603 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treino`
--

LOCK TABLES `treino` WRITE;
/*!40000 ALTER TABLE `treino` DISABLE KEYS */;
INSERT INTO `treino` VALUES (1,'20','peitoral maior',0),(2,'n','quis nostrud exerc',0),(3,'e','non proident, sun',0),(4,'te','exercitation ullamco la',0),(5,'n','commod',0),(6,'m','sit amet, consectetur adip',0),(7,'ve','in voluptate velit esse cillum dolore eu ',0),(8,'el','do eiusmod tempor incididunt ut la',0),(9,'i','in voluptate velit esse cillu',0),(10,'mo','Ut eni',0),(11,'d','Excepteur sint oc',0),(12,'am','nisi ut aliquip ex ea commodo consequat',0),(13,'cu','tempor incididunt ut labore et ',0),(14,'i','deserunt mollit anim id est laborum.Lorem ipsum d',0),(15,'do','aborum.',0),(16,'m','nostrud exercitation ullamco laboris nisi ',0),(17,'co','nulla pariatur. Excepteur sint occaec',0),(18,'ni','nisi ut aliquip ex ea commodo cons',0),(19,'co','aliquip ex ',0),(20,'eu','deserunt mollit anim id est laborum.Lorem ipsum do',0),(21,'pr','esse c',0),(22,'E','eni',0),(23,'e','ea commodo consequat. Duis aute irure dolor in ',0),(24,'la','dolore eu fugiat n',0),(25,'ma','ex ea commodo conseq',0),(26,'d','amet, consect',0),(27,'Du','consequat. Duis aute ',0),(28,'c','aute irure dolor in reprehenderit in voluptate',0),(29,'te','incid',0),(30,'d','deserunt mollit anim id est lab',0),(31,'s','in reprehenderit in voluptate velit ',0),(32,'ei','dolore eu ',0),(33,'ad','deserunt moll',0),(34,'c','in reprehenderit in voluptate velit ess',0),(35,'n','aliqua. Ut enim ad minim',0),(36,'s','consectetur adipiscing elit, sed do eius',0),(37,'fu','occaecat cupidatat non proident, sun',0),(38,'do','et dolore',0),(39,'a','irure dolor in reprehenderit in voluptate velit e',0),(40,'u','ut aliquip ex ea commodo co',0),(41,'d','proident, sunt in culpa qui officia deserun',0),(42,'es','in culpa qui officia deserunt mollit anim id est ',0),(43,'v','qui officia deseru',0),(44,'c','officia deserunt mollit anim',0),(45,'en','p',0),(46,'c','dolore magna al',0),(47,'u','cu',0),(48,'in','mollit anim id est laborum.Lorem i',0),(49,'bo','consequat.',0),(50,'q','nulla pariatur. E',0),(51,'a','occaecat cupidatat non proiden',0),(52,'Ex','s',0),(53,'e','Duis au',0),(54,'mo','qui officia d',0),(55,'e','adipiscing elit, sed do eiusmod tempor incididu',0),(56,'a','occaecat cupidata',0),(57,'m','in reprehenderit in volu',0),(58,'ve','velit esse cillum dolore eu fugiat',0),(59,'an','laboris nisi ut aliquip ex ea commodo consequ',0),(60,'qu','sint occaecat cupidatat non proident, ',0),(61,'ad','magna aliqua. Ut enim ad minim',0),(62,'u','non proident, sunt in culpa qu',0),(63,'id','mollit anim id est lab',0),(64,'pr','amet, c',0),(65,'si','aliqua. Ut en',0),(66,'e','incididunt ut labore et dolore magna aliqua. ',0),(67,'c','nostrud exercitation',0),(68,'a','nisi ut aliquip ex ea commodo consequat',0),(69,'an','eu fugiat nulla pariatur. Except',0),(70,'oc','minim veniam, quis nostrud ex',0),(71,'ex','non proident,',0),(72,'c','aliqua. Ut enim ad minim veniam, quis nostrud ex',0),(73,'co','aute irure dolor in reprehenderit in voluptate v',0),(74,'q','ad minim veniam, quis nostrud',0),(75,'n','eu fugiat nulla pariatur. Excepteur sin',0),(76,'q','dolor sit amet, consectetur ',0),(77,'i','dolore magna al',0),(78,'u','aliqua. Ut enim ad minim veniam, quis nostrud',0),(79,'l','labo',0),(80,'e','anim id est labor',0),(81,'a','mollit anim id est laborum.Lorem ipsum dolor si',0),(82,'nu','ullamco',0),(83,'el','anim id est la',0),(84,'e','id est laborum.Lorem ip',0),(85,'c','esse c',0),(86,'U','esse cillum ',0),(87,'in','Ut enim ad minim veniam, quis nostrud ',0),(88,'es','id est laborum.Lorem ipsum dolor sit amet, conse',0),(89,'cu','ad minim veniam,',0),(90,'oc','culpa qui officia deserunt mollit anim id est lab',0),(91,'la','velit esse cillum do',0),(92,'d','velit esse cillum dolore eu fug',0),(93,'in','dolore eu fugiat nulla pariatu',0),(94,'cu','adip',0),(95,'su','anim id est ',0),(96,'s','consequat. Duis aute irure dolor in ',0),(97,'a','occae',0),(98,'ex','c',0),(99,'e','adipiscing elit, sed do eiusmod temp',0),(100,'a','sit am',0),(101,'u','labo',0),(102,'n','ipsum dolor sit amet, consecte',0),(103,'nu','do eiusmod tempor inc',0),(104,'su','mollit anim id est \nlaborum.Lorem ip',0),(105,'ul','nisi ut aliquip ex ea c',0),(106,'Ex','occaecat cupidatat non proident, sunt in culpa',0),(107,'c','nostrud exercitation ullamco laboris nisi',0),(108,'oc','tempor incididunt ut labore et ',0),(109,'a','elit, sed do eiusmod tempor i',0),(110,'in','sunt in culpa qui officia deserunt mollit a',0),(111,'pr','tempor incididunt ut labore et dolor',0),(112,'i','consequat. Duis aute irure dolor in repreh',0),(113,'c','adipiscing elit, sed do eiusmod tempor incididunt',0),(114,'el','fugiat nulla par',0),(115,'s','esse cillum dolore eu fugiat nulla pariatu',0),(116,'d','cupidat',0),(117,'a','exercitation ullamco laboris ',0),(118,'d','officia deserunt mollit anim id est lab',0),(119,'c','adipiscing elit, sed do eiusm',0),(120,'q','sit amet, conse',0),(121,'c','magna',0),(122,'i','mollit',0),(123,'se','m',0),(124,'en','velit ess',0),(125,'in','ex ea',0),(126,'Ut','est laborum.Lorem',0),(127,'of','se',0),(128,'pa','anim id est laborum',0),(129,'m','sunt in culpa qui officia deserunt',0),(130,'id','adipi',0),(131,'su','deserunt mollit anim id ',0),(132,'i','incid',0),(133,'m','do eiusmod tempor incid',0),(134,'a','dolore eu fugiat nulla pariatur.',0),(135,'es','velit esse cillum dolore eu fugiat nulla pariatur',0),(136,'E','sint occaecat cupidatat non p',0),(137,'su','do eiusmod tempor incididunt ut ',0),(138,'U','incididunt ut labore et dolo',0),(139,'ex','Excepteur sint occae',0),(140,'in','anim id est laborum.Lorem ipsum dolor sit ame',0),(141,'ip','aute ir',0),(142,'s','aliqua. Ut enim ad minim veniam, quis ',0),(143,'ve','quis nostrud exercitation ull',0),(144,'E','sit amet, consectetur adipiscing elit, sed do eiu',0),(145,'en','anim id est laborum.Lorem ipsum dolor sit amet,',0),(146,'e','Duis aute iru',0),(147,'s','adipisc',0),(148,'E','proident, sunt in culpa qui officia de',0),(149,'s','ipsum dolor sit a',0),(150,'pa','in voluptate velit esse cillum',0),(151,'ex','magna aliqua. Ut enim a',0),(152,'an','et dolore magna aliqua. Ut enim ad m',0),(153,'si','dolore eu fugiat nulla ',0),(154,'ut','ut ',0),(155,'se','Duis aute irure dolor in reprehe',0),(156,'u','sint occaeca',0),(157,'ad','commodo consequat. Duis aute irure dolor in ',0),(158,'q','reprehenderit in voluptate vel',0),(159,'e','consequat. Duis aute i',0),(160,'si','adipisc',0),(161,'m','commodo consequat. Duis aute irure dolor i',0),(162,'i','incididunt ut labore et dolor',0),(163,'q','tempo',0),(164,'am','anim id est la',0),(165,'m','lab',0),(166,'oc','Excepteur s',0),(167,'ut','occaecat cu',0),(168,'D','adipiscing elit, sed do eiusmod tempor incididu',0),(169,'e','do eiusmod tempor',0),(170,'c','ut labore et dolore magna aliqu',0),(171,'qu','non proident, sunt in culpa qui offic',0),(172,'of','nostrud exercitation ullamc',0),(173,'e','pariatur. Excepteur s',0),(174,'nu','dolor in reprehenderit in ',0),(175,'d','elit, sed do eiusmod tempor incidid',0),(176,'qu','in reprehenderi',0),(177,'l','laboris nisi ut aliqui',0),(178,'ve','fugiat nulla par',0),(179,'se','eu fugiat nulla pariat',0),(180,'m','anim id est laborum.Lorem ips',0),(181,'m','adi',0),(182,'s','sunt in culpa qui officia deser',0),(183,'mo','cupidatat non proident, sunt in cul',0),(184,'f','ad minim veniam, quis nostru',0),(185,'pr','esse c',0),(186,'no','reprehenderit in voluptate velit esse cillum',0),(187,'Du','mollit anim id est laborum.Lorem ip',0),(188,'a','laboris nisi ut aliquip ex ea ',0),(189,'s','quis nostrud exercitation ullamco lab',0),(190,'s','sit amet, consectetur adipisc',0),(191,'n','in vol',0),(192,'ut','quis nostrud exercitation ullamco la',0),(193,'ex','cup',0),(194,'et','ut labore et dolore magna aliqu',0),(195,'si','enim',0),(196,'de','sed do e',0),(197,'es','magna aliqua. Ut enim ad minim veniam,',0),(198,'ul','irure dolor in reprehenderi',0),(199,'in','Duis aute irure dolo',0),(200,'fu','eiusmod tempor incididunt',0),(201,'no','culpa qui officia deserunt mollit anim i',0),(202,'do','id e',0),(203,'i','aliquip ex ea commodo consequat. D',0),(204,'e','qui officia deserunt mollit anim',0),(205,'el','in reprehende',0),(206,'te','ullamco laboris nisi \nut aliquip ex ea commodo con',0),(207,'q','quis nostrud exercitation ullamco laboris',0),(208,'i','et dolore magna aliqua. Ut enim ad minim ve',0),(209,'el','ipsum dolor sit amet,',0),(210,'et','labore et dolore ma',0),(211,'eu','ni',0),(212,'do','ut labore et dolore magna ',0),(213,'E','ad minim',0),(214,'o','in volu',0),(215,'an','nulla pariatur. Excepteur sint occaecat cupidat',0),(216,'e','sed do eiusmod tempor incididunt ut labore et dolo',0),(217,'eu','consequat. Dui',0),(218,'n','tempor inc',0),(219,'pa','adipiscing elit, sed do eius',0),(220,'et','laboris nisi ut aliquip ex ea commodo conse',0),(221,'ea','Exc',0),(222,'o','tempor incididunt ut lab',0),(223,'n','com',0),(224,'d','dolore magna aliqu',0),(225,'no','qui officia deserunt mollit anim i',0),(226,'mo','proident, sunt in culpa qui off',0),(227,'c','qui officia deserunt molli',0),(228,'Du','nulla pariatur. Excepteu',0),(229,'se','proident, sunt in culpa qui officia des',0),(230,'in','adipiscing elit, sed do eius',0),(231,'do','mollit anim id e',0),(232,'a','ullamco laboris nisi ut aliqui',0),(233,'se','occaeca',0),(234,'Ex','tem',0),(235,'p','esse cillum dolore eu fugiat nulla',0),(236,'e','anim id est',0),(237,'p','velit esse cillum dolore ',0),(238,'s','u',0),(239,'e','et dolore magna aliqua. Ut enim ad minim ven',0),(240,'s','voluptate velit esse ci',0),(241,'u','borum.Lorem ipsum',0),(242,'a','esse c',0),(243,'of','ex ea ',0),(244,'la','ulla',0),(245,'el','qu',0),(246,'ci','id est laborum.Lorem ipsum dol',0),(247,'cu','dolo',0),(248,'a','non proident, sunt in culpa ',0),(249,'t','esse cillum dolore eu fugiat nulla pariatu',0),(250,'c','mollit anim id est laborum.Lorem ipsum',0),(251,'c','nisi ut aliquip ex ea commodo consequ',0),(252,'do','ipsum dolor sit amet, consectetur adipiscing ',0),(253,'do','mollit a',0),(254,'ni','aliquip ',0),(255,'n','deserunt mollit anim id est ',0),(256,'t','veniam, qui',0),(257,'v','veniam, quis no',0),(258,'m','in culpa qui officia deserunt mollit',0),(259,'e','quis nostrud',0),(260,'do','Ut enim ad m',0),(261,'ve','dolore eu fugiat n',0),(262,'co','in voluptat',0),(263,'Ex','n',0),(264,'ni','ut labore et dolore m',0),(265,'d','dolore magna aliqua. Ut enim ad minim',0),(266,'pr','esse cillum dolore eu fugiat nulla pariatu',0),(267,'v','qui officia deserunt ',0),(268,'ex','adipiscing elit, sed do eiusmod tempor incid',0),(269,'u','Duis aute irure dolor in reprehenderit in ',0),(270,'qu','dolor sit amet, consectetur adipisci',0),(271,'Ut','rum.Lorem ipsum dolor sit amet, consectetu',0),(272,'d','u',0),(273,'Du','et dolore magna aliqua. Ut enim ad minim veni',0),(274,'mo','magn',0),(275,'ni','in reprehenderit in voluptate velit esse cillum ',0),(276,'u','culpa qui officia deserunt mollit anim id est labo',0),(277,'a','ut ali',0),(278,'no','aliqui',0),(279,'ei','sint occaecat cupidatat non proident, sunt ',0),(280,'e','elit, sed d',0),(281,'vo','eu ',0),(282,'id','in reprehenderit ',0),(283,'no','magna aliqua. Ut enim ad minim ',0),(284,'m','non proident, s',0),(285,'c','labore et dolore magna a',0),(286,'ma','reprehenderit in',0),(287,'o','laboris nisi ut aliquip ex ea co',0),(288,'d','esse cillum dolore eu fugiat nulla pariatur. E',0),(289,'su','sunt in culpa qui officia deserunt mol',0),(290,'v','irure dolor in reprehenderit in volupt',0),(291,'i','eu fugiat nulla pariatur. Excepteur sint occaec',0),(292,'p','exercitation ullamco labor',0),(293,'nu','id est laborum.Lorem ipsum dolor sit am',0),(294,'ex','aute irure dolor in reprehenderit in ',0),(295,'d','Ut enim ad minim veniam, quis nostrud exer',0),(296,'q','ullamco laboris nisi ut aliqui',0),(297,'u','veli',0),(298,'su','sunt in culpa qui officia deserunt',0),(299,'of','aborum.Lorem ipsum dolor sit amet, co',0),(300,'co','cons',0),(301,'n','deserunt mollit anim id est laborum.',0),(302,'co','cupidatat non proident, sunt in culpa qui officia',0),(303,'s','mollit anim id est laborum.Lorem ipsum dolor si',0),(304,'f','ut aliquip e',0),(305,'ma','culpa qui officia deserunt mollit',0),(306,'an','minim veniam, quis nostrud exerc',0),(307,'qu','Excep',0),(308,'n','\nadipiscing elit, sed do eiusmod tempor inc',0),(309,'s','tempor incididunt ut labore et dolore magn',0),(310,'u','sun',0),(311,'ul','ipsum d',0),(312,'f','cillum dolore eu fugiat null',0),(313,'a','occaecat cupidatat non proide',0),(314,'in','deserunt mollit anim id est laborum.L',0),(315,'c','Duis aute irure dolo',0),(316,'c','p',0),(317,'s','ullamco laboris nisi ut aliquip e',0),(318,'ut','velit esse cillum dolore e',0),(319,'do','elit, sed do eiusmod tempor incididunt ut labore ',0),(320,'a','in voluptat',0),(321,'a','elit, sed do eiusmod tempor i',0),(322,'i','aliqua. Ut enim ad minim veniam',0),(323,'e','ut labore et dolore magna aliqua.',0),(324,'au','occaeca',0),(325,'no','deserunt mollit anim',0),(326,'r','sint occaecat cupidatat n',0),(327,'e','ad minim veniam, quis nostrud ',0),(328,'si','officia',0),(329,'ex','Duis aute irure dolor in reprehe',0),(330,'au','adipisc',0),(331,'do','exercitation ullamco l',0),(332,'ab','Ut enim ad mini',0),(333,'a','et dolore magna aliqua. Ut enim ad minim veni',0),(334,'su','aliqua. Ut enim ',0),(335,'e','mollit anim id est laborum',0),(336,'ut','aute irure dolor in reprehen',0),(337,'ex','velit esse cillum do',0),(338,'ir','nostrud exe',0),(339,'mo','in reprehenderit in voluptate velit esse cillum do',0),(340,'c','consectetur adipiscing elit, sed do eiusmod tempo',0),(341,'c','sint occaeca',0),(342,'et','nisi ut aliquip ex ea commodo consequat. Du',0),(343,'c','nostrud exercitati',0),(344,'vo','et dolore m',0),(345,'ul','nulla pariatur. Ex',0),(346,'m','adipiscing elit',0),(347,'c','cupidatat ',0),(348,'et','ex ea commodo consequat. Du',0),(349,'id','eli',0),(350,'vo','nulla pariatur. Excepteur sint occaeca',0),(351,'d','aliqua. Ut enim ad minim v',0),(352,'si','ut aliquip e',0),(353,'te','ullamco laboris nisi ut aliquip ex ea co',0),(354,'e','elit, sed do eiusmod temp',0),(355,'.','veniam, quis nostrud exercit',0),(356,'ut','do eiusmod tempor incididunt ut labore et dol',0),(357,'i','dolore magna aliqua. Ut eni',0),(358,'su','mollit anim id est laborum.Lorem ipsum dolor si',0),(359,'d','conse',0),(360,'i','sunt in culpa qui offic',0),(361,'am','aute irure dol',0),(362,'ad','Excepteur sint occaecat c',0),(363,'e','incididunt ut labore et dolore magna ali',0),(364,'ad','offici',0),(365,'m','aliqua. Ut enim ad minim veniam, q',0),(366,'ni','magna aliqua. Ut enim ad minim veniam, ',0),(367,'a','nulla pariatu',0),(368,'es','voluptate vel',0),(369,'i','ulla',0),(370,'Du','esse cillum dolore eu fugiat nulla pariatur. Exc',0),(371,'m','Excepteur sint occaecat cupidatat non proident, ',0),(372,'co','elit, sed do eiusmod tempor incididunt ut la',0),(373,'e','dolor sit a',0),(374,'ni','e',0),(375,'el','sed do eiusmod tempor incididunt ut labore et d',0),(376,'s','incididunt ut labore et dolore magn',0),(377,'e','Duis aute irure d',0),(378,'d','in voluptate velit esse cil',0),(379,'q','incididunt ut labore e',0),(380,'E','la',0),(381,'te','sunt in culpa',0),(382,'in','sint occaecat cupidatat non proi',0),(383,'mo','occaecat cupidatat non proident, sunt in culp',0),(384,'ul','tempor incididunt ut labore e',0),(385,'m','qui officia deserunt mollit anim id est l',0),(386,'U','tempor incididunt ut labore et do',0),(387,'ex','veniam, quis nostrud exercitation ullamco l',0),(388,'do','non proident, sunt in culpa qui ',0),(389,'do','Ut enim ad minim veniam, quis nostr',0),(390,'e','velit esse cillum dolore eu fugiat nul',0),(391,'si','a',0),(392,'a','mollit anim id est laborum.Lorem ipsum d',0),(393,'ve','laboris nisi ut aliquip ex ea commodo ',0),(394,'et','minim veniam, quis nostrud exe',0),(395,'cu','quis nostrud exercitation ullamco laboris nisi',0),(396,'r','aliqua. Ut enim ad mi',0),(397,'D','non proident, sunt in culpa qui officia deser',0),(398,'id','velit esse cill',0),(399,'in','adipiscing elit, sed',0),(400,'ni','laboris nisi ut aliquip ex ea commodo consequat. D',0),(401,'s','laboris nisi ut aliquip ex ea commodo co',0),(402,'la','sed do eiusmod tempor i',0),(403,'in','fugia',0),(404,'oc','in voluptate velit',0),(405,'pa','quis nostrud exercitation ullamco lab',0),(406,'al','Duis \naute irure dolor in ',0),(407,'oc','cupidatat non proident,',0),(408,'U','velit esse cillum dolor',0),(409,'et','laboris nisi ut aliquip ex ea commod',0),(410,'do','velit esse cillum dolore eu fugiat nulla',0),(411,'e','anim id est laborum.Lorem ipsu',0),(412,'au','proident, sunt in culpa qui officia deserunt mol',0),(413,'Ex','vel',0),(414,'no','d',0),(415,'a','pariatur. Excepteur sint occaecat cupidata',0),(416,'co','mollit anim id est laborum.Lorem ipsum dolor sit a',0),(417,'e','um.Lorem ipsum dolor sit amet, co',0),(418,'se','exercitation ulla',0),(419,'e','adipiscing elit, sed do eiusmod tempor incidid',0),(420,'et','qui offi',0),(421,'Ut','in vol',0),(422,'v','nisi ut aliquip ex ea ',0),(423,'do','exercitation ullamco laboris nis',0),(424,'Du','ipsum dolor sit amet, consectetur adip',0),(425,'u','ut labore et dolore ma',0),(426,'u','laborum.Lorem ipsum dolor sit amet',0),(427,'t','Excepteur sint occaecat cupi',0),(428,'Du','Excepteur sint o',0),(429,'m','Excepteur sint occaecat cupidatat non proident',0),(430,'ni','culpa qui',0),(431,'al','enim ad mi',0),(432,'de','ea commodo ',0),(433,'no','sunt in culpa qui o',0),(434,'e','in culpa qui officia deserunt mollit anim id ',0),(435,'s','consectetur adipiscing elit, sed do eiusmo',0),(436,'co','eiusmod tempor incidid',0),(437,'ci','tempor incididunt ut labore et dolor',0),(438,'do','minim veniam, quis no',0),(439,'e','fugiat nulla paria',0),(440,'c','non proident, sunt in culpa qui of',0),(441,'e','ut aliquip ',0),(442,'eu','ipsum dolor sit amet, consectet',0),(443,'m.','sint occaecat cupidatat non proident, sunt in culp',0),(444,'of','tempor incididunt ut labore et do',0),(445,'no','eiusmod tempor incididunt ut labore e',0),(446,'a','nostrud exercitation ullam',0),(447,'in','aliqua. Ut enim ad minim veniam, q',0),(448,'q','cons',0),(449,'do','exercitation ulla',0),(450,'an','voluptate velit esse cillum dolore eu fugiat nu',0),(451,'n','sunt in culpa qui officia deserunt mollit anim id',0),(452,'D','id est laborum.Lorem ipsum dolor sit',0),(453,'id','adipiscing elit, sed d',0),(454,'ul','quis nostrud exercitation ullamco laboris ',0),(455,'u','officia deserunt ',0),(456,'s','in volu',0),(457,'mo','ipsum dolor si',0),(458,'i','esse cillum dolore eu fugiat nulla pariatur. E',0),(459,'f','consequat.',0),(460,'s','in reprehenderit in voluptate velit ess',0),(461,'a','quis nostrud exercitation ullamco laboris nisi ut',0),(462,'es','dolore eu fugiat nulla pariatur. Excepteur sint ',0),(463,'se','irure dolor in reprehenderit in voluptate velit e',0),(464,'la','ut labore et dolore ',0),(465,'Ex','amet, consectetur adipiscing e',0),(466,'ut','nostrud exercit',0),(467,'co','adipiscing eli',0),(468,'a','cupidatat no',0),(469,'q','qui officia deserunt mollit',0),(470,'c','eu fugiat nulla pariatur. Excepteur si',0),(471,'do','cillum dolore eu fugiat nulla pariatur.',0),(472,'ad','ex ea commodo con',0),(473,'do','ullamco laboris nisi ut aliquip ex ea commodo cons',0),(474,'et','dolor in reprehenderit in voluptate velit esse cil',0),(475,'s','aliqua. ',0),(476,'i','ut labore et dolore magna ali',0),(477,'i','Excepteur sint occa',0),(478,'el','non proiden',0),(479,'mo','consequat. Duis aute irure ',0),(480,'en','exercitation ulla',0),(481,'n','officia deserunt mollit anim id est ',0),(482,'e','nulla pariatur. Excep',0),(483,'s','dolor sit amet, consectetur adip',0),(484,'i','est laborum.Lo',0),(485,'c','Duis aute irure dolor in reprehend',0),(486,'q','sint occaecat cu',0),(487,'m','Lor',0),(488,'Ut','consequat. D',0),(489,'i','ullamco labo',0),(490,'si','sit amet, consectetur ad',0),(491,'a','proident, sunt i',0),(492,'e','aliquip ex ea commodo consequat. Duis aute irure d',0),(493,'n','quis nostrud exercitation ullamco ',0),(494,'ve','ullamco laboris',0),(495,'am','sunt in culpa qui officia deserunt mollit an',0),(496,'q','reprehenderit in voluptate velit esse cillum dolo',0),(497,'do','magna aliqua.',0),(498,'e','sint occaecat cupidatat non proident, sunt in c',0),(499,'c','Ut enim ad minim ',0),(500,'co','do eius',0),(501,'m','exercitation ullamco',0),(502,'Ex','Duis aute irure \ndolor ',0),(503,'s','cupidatat non proident, sunt in culpa qui o',0),(504,'u','sunt in culpa qui offici',0),(505,'qu','aute i',0),(506,'co','sunt in culpa qui officia deserunt mollit anim',0),(507,'e','elit, sed do eiusmod tempor incididunt ut la',0),(508,'ir','ipsum dolor sit am',0),(509,'i','ut aliquip ex ea commodo c',0),(510,'co','m.Lorem ip',0),(511,'l','mollit anim id est la',0),(512,'in','adipiscing elit, sed do eius',0),(513,'es','quis nostrud exe',0),(514,'en','irure',0),(515,'ei','cu',0),(516,'d','sed do eiusmod tempor incididunt ut labo',0),(517,'au','non proident, sunt in culp',0),(518,'s','elit, sed do eiusmod tempor incididun',0),(519,'or','cupidatat non proident, sunt in culpa qui offici',0),(520,'ad','magna aliqua. Ut enim ad minim veniam, quis',0),(521,'d','anim id est laborum.Lorem ipsum d',0),(522,'c','elit, sed do eiusmod tempor incidi',0),(523,'u','ullamco laboris nisi ut aliquip ex ea commodo c',0),(524,'ve','Ut enim ad minim venia',0),(525,'v','quis nostrud exercitation ullamco labo',0),(526,'v','dolore eu fugiat nu',0),(527,'in','id est laborum.Lorem ipsum d',0),(528,'pa','labore et dolore magna aliqua. Ut enim ad mi',0),(529,'e','in volup',0),(530,'no','incididunt ut labore et do',0),(531,'a','velit esse cillum dolore e',0),(532,'t','et dolore magna ',0),(533,'no','quis nostrud exercitation ullamco',0),(534,'id','cupidatat non proident, sunt in culpa',0),(535,'.','amet, consectetur adipiscing elit, sed ',0),(536,'ad','laboris nisi ut aliquip ex',0),(537,'ul','magna',0),(538,'in','anim id est laborum.Lore',0),(539,'e','non proident,',0),(540,'Ex','elit, sed do eiusmod te',0),(541,'Ex','sint occ',0),(542,'ei','sint occaecat cupidatat non pr',0),(543,'c','tempor incididunt ut labore ',0),(544,'q','ullamco',0),(545,'c','dolor sit amet, consectetur ',0),(546,'e','cupidatat non proi',0),(547,'bo','sit amet, consectetur adipiscing elit, se',0),(548,'su','Excepteur sint occaecat cupidatat non p',0),(549,'pa','aliquip ex ea commodo consequat. Duis aute',0),(550,'q','exercita',0),(551,'es','orum.Lorem ipsum dolor',0),(552,'s','proident, su',0),(553,'in','d',0),(554,'in','dolor in reprehenderit in voluptate veli',0),(555,'n','et dolore magna',0),(556,'Ut','elit, sed do eiusmod tempor incididunt ut lab',0),(557,'p','deserunt mollit',0),(558,'se','Ut enim ad min',0),(559,'n','tempor incididunt ',0),(560,'t','quis nos',0),(561,'do','in culpa qui officia dese',0),(562,'ma','sint occaecat cupidatat non proident, sunt in',0),(563,'te','esse cillum dolore eu fugiat n',0),(564,'nu','adipiscing elit',0),(565,'E','et dolore magn',0),(566,'u','laboris nisi ut aliquip ex ea commodo con',0),(567,'eu','elit, sed do eiusmod tempor incididunt',0),(568,'Ex','non proide',0),(569,'su','i',0),(570,'eu','id est laborum.Lorem ipsum dol',0),(571,'no','sint occaecat cup',0),(572,'a','do eiusmod tempor incididunt ut labore ',0),(573,'m','non proident, sunt in culpa qui officia deserun',0),(574,'a','adipiscing elit, sed do',0),(575,'e','magna aliqua',0),(576,'q','ad minim ve',0),(577,'c','dolore magna ali',0),(578,'i','ni',0),(579,'i','mollit anim id est laborum.Lorem ipsum do',0),(580,'u','inci',0),(581,'s','irure dolor in',0),(582,'su','adipiscing elit, sed d',0),(583,'in','deserunt mollit anim id es',0),(584,'Ut','eiusmod tempor incididunt ut labore et',0),(585,'pr','sunt in ',0),(586,'el','incididunt u',0),(587,'ul','cons',0),(588,'o','aut',0),(589,'c','anim id est laborum.Lorem ipsum dolor s',0),(590,'in','ullamco laboris nisi ut aliquip ex ea commodo con',0),(591,'re','cupidatat non proident',0),(592,'of','in reprehenderit in voluptate velit ess',0),(593,'de','dolore eu fugiat nul',0),(594,'fu','nostrud exercitation ',0),(595,'e','Ut enim ad minim veniam, quis nostrud exercitat',0),(596,'c','q',0),(597,'n','pariatur. Excepteur sint occaecat cupidatat non',0),(598,'Ex','et dolore magna aliqua. Ut enim ad',0),(599,'q','in culpa qui officia deserunt ',0);
/*!40000 ALTER TABLE `treino` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treinoxaparelhos`
--

DROP TABLE IF EXISTS `treinoxaparelhos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treinoxaparelhos` (
  `codigo_treino` int(11) NOT NULL,
  `codigo_aparelhos` int(11) NOT NULL,
  PRIMARY KEY (`codigo_treino`,`codigo_aparelhos`),
  KEY `fk_TreinoXAparelhos3` (`codigo_aparelhos`),
  CONSTRAINT `fk_TreinoXAparelhos2` FOREIGN KEY (`codigo_treino`) REFERENCES `treino` (`codigo`),
  CONSTRAINT `fk_TreinoXAparelhos3` FOREIGN KEY (`codigo_aparelhos`) REFERENCES `aparelhos` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treinoxaparelhos`
--

LOCK TABLES `treinoxaparelhos` WRITE;
/*!40000 ALTER TABLE `treinoxaparelhos` DISABLE KEYS */;
INSERT INTO `treinoxaparelhos` VALUES (44,16),(53,10),(92,19),(106,44),(158,40),(219,40),(260,7),(272,39),(297,23),(306,48);
/*!40000 ALTER TABLE `treinoxaparelhos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'estagio'
--
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarAlunos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarAlunos`(

in

codigo				INT,

nome				VARCHAR(100),

profissao			VARCHAR(1),

cpf					VARCHAR(11),

rg					VARCHAR(15),

data_aniversario	date,

data_vencimento		date,

lesao_limitacao		VARCHAR(100),

endereco 			VARCHAR(100),

telefone			INT,

valor_matricula		INT,

data_matricula		date,

ativo				VARCHAR(1),

codigo_servico		INT,

cod_objetivo		INT

)
BEGIN

UPDATE alunos as a set a.nome = nome, a.profissao = profissao, a.cpf = cpf, a.rg = rg, a.data_aniversario = data_aniversario,

			a.data_vencimento = data_vencimento, a.lesao_limitacao = lesao_limitacao, a.endereco = endereco,

			a.telefone = telefone, a.valor_matricula = valor_matricula, a.data_matricula = data_matricula,

			a.ativo = ativo, a.codigo_servico = codigo_servico, a.cod_objetivo = cod_objetivo

            where a.codigo = codigo;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarAlunoxServico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarAlunoxServico`(in cod_aluno INT, in cod_servico INT)
begin

	update alunosxservicos set codigo_servico = cod_servico where codigo_aluno = cod_aluno;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarAlunoxTreino` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarAlunoxTreino`(

in

cod_aluno	INT,

cod_treino	INT

)
begin

	

	update alunosxtreino set codigo_treino = cod_treino where codigo_aluno = cod_aluno;



end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarAparelhos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarAparelhos`(

in

codigo					INT,

descricao				VARCHAR(50),

ativo					VARCHAR(1)

)
BEGIN

UPDATE aparelhos as ap set ap.descricao = descricao, ap.ativo = ativo

           where ap.codigo = codigo;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarFuncionario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarFuncionario`(

in

codigo				INT,

supervisor			boolean,

estagiario			boolean,

funcao				VARCHAR(50),

senha				VARCHAR(50),

cpf					VARCHAR(11),

rg					VARCHAR(15),

nome				VARCHAR(100),

ativo				boolean

)
BEGIN

UPDATE funcionario as f set f.supervisor = supervisor, f.estagiario = estagiario, f.funcao = funcao,

			f.senha = senha, f.cpf = cpf, f.rg = rg, f.nome = nome, f.ativo = ativo

            where f.codigo = codigo;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarObjetivo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarObjetivo`(

in

codigo					INT,

descricao				VARCHAR(50),

ativo 					boolean

)
BEGIN

UPDATE objetivos as o set o.descricao = descricao, o.ativo = ativo

           where o.codigo = codigo;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarServico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarServico`(

in

codigo				INT,

horario				VARCHAR(50),

servico				VARCHAR(50),

ativo boolean

)
BEGIN

UPDATE servico as s set s.horario = horario, s.servico = servico, s.ativo = ativo

           where s.codigo = codigo;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarTreino` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarTreino`(

in

codigo				INT,

serie				CHAR(2),

grupo_muscular		VARCHAR(50)

)
BEGIN

UPDATE treino as t set t.serie = serie, t.grupo_muscular = grupo_muscular

           where t.codigo = codigo;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spAlterarTreinoxAparelho` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spAlterarTreinoxAparelho`(in cod_treino INT, in cod_aparelho INT)
begin

	update treinoxaparelhos set codigo_aparelhos = cod_aparelho where codigo_treino = cod_treino;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaAluno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaAluno`(in nomeAluno varchar(50))
begin

		select * from alunos where nome like concat (nomealuno,'%') and ativo = true;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaAlunoxServicos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaAlunoxServicos`(in nomeAluno varchar(50), in opt int, in id int,in cpf varchar(50))
begin

	if (opt = 0) then

			select al.nome,al.codigo, al.cpf,s.servico,axs.codigo_aluno as cod_aluno, axs.codigo_servico as cod_servico

			from alunos al

				join alunosxservicos axs on axs.codigo_aluno = al.codigo

				join servico s on s.codigo = axs.codigo_servico

			where al.nome like concat('%',nomealuno,'%') and al.ativo = true;

	elseif (opt = 1) then

			select al.nome,al.codigo, al.cpf,s.servico,axs.codigo_aluno as cod_aluno, axs.codigo_servico as cod_servico

			from alunos al

				join alunosxservicos axs on axs.codigo_aluno = al.codigo

				join servico s on s.codigo = axs.codigo_servico

			where al.codigo = id and al.ativo = true;

		elseif (opt = 2) then

		select al.nome,al.codigo, al.cpf, s.servico,axs.codigo_aluno as cod_aluno, axs.codigo_servico as cod_servico

			from alunos al

				join alunosxservicos axs on axs.codigo_aluno = al.codigo

				join servico s on s.codigo = axs.codigo_servico

			where al.cpf like concat ('%',cpf,'%') and al.ativo = true;

	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaAlunoxTreino` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaAlunoxTreino`(in nomeAluno varchar(50), in opt int, in id int,in grupo_muscular varchar(50))
begin

	if (opt = 0) then

			select al.nome,al.codigo, al.cpf, t.codigo, t.grupo_muscular,axt.codigo_aluno as cod_aluno, axt.codigo_treino as cod_treino

			from alunos al

				join alunosxtreino axt on axt.codigo_aluno = al.codigo

				join treino t on t.codigo = axt.codigo_treino

			where al.nome like concat('%',nomeAluno,'%') and al.ativo = true;

	elseif (opt = 1) then

			select al.nome,al.codigo, al.cpf,t.codigo ,axt.codigo_aluno as cod_aluno, axt.codigo_treino as cod_treino

			from alunos al

				join alunosxtreino axt on axt.codigo_aluno = al.codigo

				join treino t on t.codigo = axt.codigo_treino

			where al.codigo = id and al.ativo = true;

		elseif (opt = 2) then

		select al.nome,al.codigo as cod_aluno, al.cpf, t.codigo as cod_treino

			from alunos al

				join alunosxtreino axt on axt.codigo_aluno = al.codigo

				join treino t on t.codigo = axt.codigo_treino

			where t.grupo_muscular like concat ('%',grupo_muscular,'%') and al.ativo = true;

	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaAparelho` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaAparelho`(in descricaoo varchar(50))
begin

		select * from aparelhos where descricao like concat (descricaoo,'%') and ativo = true;

	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaFuncionario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaFuncionario`(in nomee varchar(50))
begin
		select * from funcionario where nome like concat ('%',nomee,'%') and ativo = true;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaObjetivo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaObjetivo`(in nomeObjetivo varchar(50), in opt int, in id int)
begin

	if (opt = 0) then

		select * from objetivos where descricao like concat ('%',nomeObjetivo,'%') and ativo = true;

	elseif (opt = 1) then

		select * from objetivos where codigo = id and ativo = true;

	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaServico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaServico`(in nomeServico varchar(50))
begin
		select * from servico where servico like concat ('%',nomeServico,'%')  and ativo = true;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaTreino` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaTreino`(in grupo varchar(50),in opt int,in id int)
begin

   	if (opt = 0) then

       select * from treino where grupo_muscular like concat('%',grupo,'%') and ativo = true;

    elseif (opt = 1) then

    	select * from treino where codigo = id and ativo = true;

    end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaTreinoxAparelhos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaTreinoxAparelhos`(in grupoMuscular varchar(50), in opt int, in id int, in descricaoAparelhos varchar(50))
begin

	if (opt = 0) then

			select tr.grupo_muscular , ap.codigo , tr.codigo, ap.codigo, txa.codigo_aparelhos, txa.codigo_treino

			from aparelhos ap

				join treinoxaparelhos txa on txa.codigo_aparelhos = ap.codigo

				join treino tr on tr.codigo = txa.codigo_treino

			where ap.descricao like concat('%',descricaoAparelhos,'%') and ap.ativo = true;

		elseif (opt = 1) then

			select ap.codigo as aparelho_codigo,ap.descricao as aparelho_descricao,

			tr.codigo as treino_codigo,tr.grupo_muscular as treino_grupoMuscular

			from aparelhos ap

				join treinoxaparelhos txa on txa.codigo_aparelhos = ap.codigo 

			join treino tr on txa.codigo_treino = tr.codigo

				where tr.grupo_muscular like concat('%',grupo_muscular,'%') and ap.ativo = true;

		elseif (opt = 2) then

		select txa.codigo_aparelhos as txaCodAparelho, txa.codigo_treino as txaCodTreino from aparelhos ap

			join treinoxaparelhos txa on txa.codigo_aparelhos = ap.codigo

			join treino tr on tr.codigo = txa.codigo_treino

		where ap.codigo = id and ap.ativo = true;

	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spConsultaTudoAluno` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spConsultaTudoAluno`(in codigoo int)
BEGIN
SELECT a.codigo,a.nome,a.profissao,a.cpf,a.rg,a.valor_mensalidade,
a.valor_matricula,a.data_vencimento,a.ativo,a.telefone,a.endereco,a.lesao_limitacao,a.data_aniversario
,obj.descricao,serv.servico
from estagio.alunos as a
join estagio.objetivos obj on obj.codigo = a.cod_objetivo
join estagio.servico serv on serv.codigo = a.codigo_servico
WHERE a.codigo = codigoo;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDeleteAlunos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spDeleteAlunos`(IN idaluno INT)
BEGIN

 update alunos set ativo = false where codigo = idaluno;

    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDeleteAparelhos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spDeleteAparelhos`(IN idAparelhos INT)
BEGIN

 

update aparelhos as ap set ativo = false WHERE ap.codigo = idAparelhos;

   

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDeleteFuncionario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spDeleteFuncionario`(IN idFuncionario INT)
BEGIN

 

update funcionario set ativo = false where codigo = idFuncionario;

   

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDeleteObjetivos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spDeleteObjetivos`(IN idObjetivos INT)
BEGIN

 

update objetivos set ativo = false WHERE codigo = idObjetivos;

   

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDeleteServico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spDeleteServico`(IN idServico INT)
BEGIN

 

update servico set ativo = false where codigo = idServico;

   

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spDeleteTreino` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spDeleteTreino`(IN idTreino INT)
BEGIN

 

update treino set ativo = false where codigo = idTreino;

	

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spInserirAlunoCompleto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spInserirAlunoCompleto`(

in

	descricao_nome				VARCHAR(100),

	descricao_profissao 		VARCHAR(100),

	cpf							VARCHAR(11),

	rg							VARCHAR(15),

	valor_mensalidade			DOUBLE,

	data_aniversario			DATE,

	data_vencimento				DATE,

	lesao_limitacao				VARCHAR(100),

	endereco 					VARCHAR(100),

	telefone					INT,

	valor_matricula				INT,

	data_matricula				DATE,

	ativo						VARCHAR(1),

	codigo_servico				INT,

	cod_objetivo				INT

)
BEGIN

INSERT INTO alunos (nome, profissao, cpf, rg, valor_mensalidade, data_aniversario, data_vencimento, 

			lesao_limitacao, endereco, telefone, valor_matricula, data_matricula, ativo, 

			codigo_servico, cod_objetivo)

	VALUES   (nome, descricao_profissao, cpf, rg, valor_mensalidade, data_aniversario, data_vencimento, 

			lesao_limitacao, endereco, telefone, valor_matricula, data_matricula, ativo, 

			codigo_servico ,cod_objetivo);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spInserirAparelhos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spInserirAparelhos`(

in

	descricao_aparelhos		VARCHAR(50),

	ativo	           		boolean

)
BEGIN

INSERT INTO aparelhos (descricao, ativo)

	VALUES   (descricao_aparelhos, ativo);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spInserirFuncionarioCompleto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spInserirFuncionarioCompleto`(

in

	supervisor					CHAR(1),

	estagiario    			    CHAR(1),

	descricao_funcao 			VARCHAR(50),

	senha						VARCHAR(50),

	cpf							VARCHAR(11),

	rg							VARCHAR(15),

	descricao_nome				VARCHAR(100),

	ativo						VARCHAR(1)

	

)
BEGIN

INSERT INTO funcionario (supervisor, estagiario, funcao, senha, cpf, rg, nome, ativo)

	VALUES   (supervisor, estagiario, descricao_funcao, senha, cpf, rg, descricao_nome, ativo);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spInserirObjetivos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spInserirObjetivos`(

in

ativoo						 BOOL,

descricao_objetivo           VARCHAR(50)

)
BEGIN

 

INSERT INTO objetivos (ativo,descricao)

                VALUES   (ativoo, descricao_objetivo);



          

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spInserirServico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spInserirServico`(

in

	descricao_servico           VARCHAR(50),

	horario_servico				VARCHAR(50),
	
	ativo_servico boolean

)
BEGIN

INSERT INTO servico (servico, horario, ativo)

	VALUES   (descricao_servico, horario_servico, ativo_servico);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spInserirTreino` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `spInserirTreino`(

in

	serie					 CHAR(2),

	grupo_muscular           VARCHAR(50)

)
BEGIN

INSERT INTO treino (serie, grupo_muscular)

	VALUES   (serie, grupo_muscular);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-04 17:33:41
